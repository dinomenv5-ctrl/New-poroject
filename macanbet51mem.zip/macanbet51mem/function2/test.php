<?php
require_once 'session.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $amount = $_GET['amount'];
    $promo = $_GET['promo'];
    $paymentMethod = 'qris';
    $gameid = $promo ?? 0;
    $catatan = 'QR Auto';
    $sid = session_id();
    $image = $qrLink;
    $userID = $u['cuid'];
    $rand = rand(100,999);
    $totalBal = $amount + $rand ;
    $nmid = rand(1000,9999);
    $expDate = date('Y-m-d H:i:s', strtotime('+15 minutes'));
    

 
        // Simpan ke database transaksi QR
        $status = "0";
        $stmt = $conn->prepare("INSERT INTO qr_transaksi (userID, nmid, content_qr, checkout_qr, url_qr, amount, exp_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssisi", $userID, $nmid, $image, $image, $image, $totalBal, $expDate, $status);
        $insertTransaksi = mysqli_query($conn, "INSERT INTO `tb_transaksi` (`kd_transaksi`, `date`, `transaksi`, `total`, `saldo`, `note`, `gameid`, `providerID`, `jenis`, `metode`, `pay_from`, `userID`, `status`) VALUES ('$nmid', NOW(), 'Auto Payment', '$totalBal', 0, '$catatan', '$gameid', '0', '1', '$paymentMethod', '$paymentMethod', '$userID',0)") or die(mysqli_error($conn));

        if ($stmt->execute()) {
            // Jika gameid ada, lakukan perhitungan bonus
            if ($gameid != '0') {
                $sql_transaksi = mysqli_query($conn, "SELECT * FROM `tb_post` WHERE cuid = '$gameid'") or die(mysqli_error($conn));
                $st = mysqli_fetch_array($sql_transaksi);

                $jml_to = $st['min_to'];
                $persen = $st['persen'] / 100;

                $bonusnya = $amount * $persen;
                $bonuse = round($bonusnya);

                if ($bonuse > 200000) {
                    $bonusDepo = $bonuse;
                } else {
                    $bonusDepo = $bonuse;
                }

                $totalTO = ($amount + $bonusDepo) * $jml_to;
                $sisaTO = ($amount + $bonusDepo) * $jml_to;
                date_default_timezone_set('Asia/Jakarta');

                $expiredAt = date('Y-m-d H:i:s', strtotime('+1 day'));
                $insertTO = mysqli_query($conn, "INSERT INTO `tb_turnover` 
                    (`userID`, `trxID`, `depo`, `bonus`, `jmlh_to`, `total_to`, `sisa_to`, `status`, `created_at`, `expired_at`) 
                    VALUES 
                    ('$userID', '$nmid', '$amount', '$bonusDepo', '$jml_to', '$totalTO', '$sisaTO', 1, NOW(), '$expiredAt')") 
                    or die(mysqli_error($conn));
                $insert_tr_bonus = mysqli_query($conn, "INSERT INTO `tb_transaksi` 
                (`kd_transaksi`, `date`, `transaksi`, `total`, `saldo`, `note`, `gameid`, `providerID`, `jenis`, `metode`, `pay_from`, `userID`, `status`) 
                VALUES 
                ('$nmid',NOW(),'Promosi','$bonusDepo',0, '$catatan', '$gameid', '0','7','$paymentMethod','$paymentMethod','$userID',0)") 
                or die(mysqli_error($conn));
            }

            echo json_encode([
                'status' => 'success',
                'message' => 'QR Code berhasil dibuat.',
                'data' => [
                    'amount' => $totalBal,
                    'url_qr' => $image,
                    'checkout_qr' => $checkoutQr,
                    'exp_date' => $expDate
                ]
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan data ke database: ' . $stmt->error]);
        }
        $stmt->close();
    } else {
        echo json_encode(['status' => 'error']);
    }

?>
