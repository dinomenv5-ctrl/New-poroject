<?php
require_once('session.php');

$result = mysqli_query($conn, "SELECT mindepo, urlweb FROM tb_seo LIMIT 1");
$seo = mysqli_fetch_assoc($result);
$minDeposit = (int)str_replace(',', '', $seo['mindepo']);
$urlweb = rtrim($seo['urlweb'], '/') . '/webhook/notify_deposit.php';

$metode = $_POST['metode'];
$nominal = preg_replace('/[^A-Za-z0-9\-]/', '', $_POST['nominal']);
$pay_from = $_POST['pay_from'];
$catatan = $_POST['catatan'];
$gameid = $_POST['gameid'];
$postID = $_POST['postID'];

$unik = date('Hs');
$kode_unik = substr(str_shuffle(1234567890), 0, 2);
$kd_transaksi = date('Ymds') . $kode_unik;
$created_date = date('Y-m-d H:i:s');

// Ambil persentase fee admin dari tb_seo
$fee_result = mysqli_query($conn, "SELECT feepulsa FROM tb_seo LIMIT 1");
$fee_data = mysqli_fetch_assoc($fee_result);

// Kurangi totalBayar dengan fee admin
$totalBayar = $nominal;

if (isset($_POST['submit'])) {
    if ($nominal < $minDeposit) {
        header('Location:../m/account/deposit/?notif=1&msg=Nominal deposit yang anda masukan kurang dari nominal batas minimum deposit');
        exit();
    } else {
        $insert_transaksi = mysqli_query($conn, "INSERT INTO `tb_transaksi` 
            (`kd_transaksi`, `date`, `transaksi`, `total`, `saldo`, `note`, `gameid`, `providerID`, `jenis`, `metode`, `pay_from`, `userID`, `status`) 
            VALUES 
            ('$kd_transaksi','$created_date','Top Up','$totalBayar',0, '$catatan', '$gameid', '0','1','$metode','$pay_from','$postID',0)") 
            or die(mysqli_error($conn));
        
        // Panggil webhook setelah insert transaksi
       // file_get_contents($urlweb);

        if ($gameid != '') {
            $sql_transaksi = mysqli_query($conn, "SELECT * FROM `tb_post` WHERE cuid = '$gameid'") or die(mysqli_error($conn));
            $st = mysqli_fetch_array($sql_transaksi);

            $jml_to = $st['min_to'];
            $persen = $st['persen'] / 100;

            $bonusnya = $nominal * $persen;
            $bonuse = round($bonusnya);

            if ($bonuse > 200000) {
                $bonusDepo = 200000;
            } else {
                $bonusDepo = $bonuse;
            }

            $totalTO = ($nominal + $bonusDepo) * $jml_to;
            $sisaTO = ($nominal + $bonusDepo) * $jml_to;
            date_default_timezone_set('Asia/Jakarta');

            $expiredAt = date('Y-m-d H:i:s', strtotime('+1 day'));
            $insertTO = mysqli_query($conn, "INSERT INTO `tb_turnover` 
                (`userID`, `trxID`, `depo`, `bonus`, `jmlh_to`, `total_to`, `sisa_to`, `status`, `created_at`, `expired_at`) 
                VALUES 
                ('$postID', '$kd_transaksi', '$nominal', '$bonusDepo', '$jml_to', '$totalTO', '$sisaTO', 1, NOW(), '$expiredAt')") 
                or die(mysqli_error($conn));

            // Panggil webhook setelah insert turnover
           // file_get_contents($urlweb);

            $insert_tr_bonus = mysqli_query($conn, "INSERT INTO `tb_transaksi` 
                (`kd_transaksi`, `date`, `transaksi`, `total`, `saldo`, `note`, `gameid`, `providerID`, `jenis`, `metode`, `pay_from`, `userID`, `status`) 
                VALUES 
                ('$kd_transaksi','$created_date','Promosi','$bonusDepo',0, '$catatan', '$gameid', '0','7','$metode','$pay_from','$postID',0)") 
                or die(mysqli_error($conn));

            // Panggil webhook setelah insert promosi
            //file_get_contents($urlweb);
        }

        header('Location:../m/?notif=8');
        exit();
    }
}
?>
