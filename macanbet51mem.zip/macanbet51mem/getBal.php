<?php
ob_start();
session_start();
include('config/koneksi.php');
include('config/class_softgaming.php');

/**
 * getBal.php — FIXED VERSION (BUG FATAL: saldo member "hilang" setelah deposit QRIS)
 *
 * ============ BUG LAMA (FATAL) ============
 *  Versi lama SELALU menimpa tb_balance.active dengan saldo dari API game
 *  NexusGGR setiap kali halaman member dibuka (header memanggil file ini).
 *  Akibatnya: deposit QRIS yang sudah dikredit ke tb_balance lokal, tetapi
 *  deposit ke game API gagal (best-effort / API down), akan DINOALKAN saat
 *  member membuka halaman lain -> "saya sudah bayar tapi saldo tidak masuk".
 *
 * ============ PERBAIKAN ============
 *  1. Saldo lokal TIDAK PERNAH ditimpa turun saat ada deposit yang belum
 *     sinkron ke game API (note GAME-API-FAIL). tb_balance = source of truth.
 *  2. Auto-retry deposit ke game API untuk transaksi GAME-API-FAIL milik
 *     user ini, dengan dedup transferStatus(agent_sign) agar tidak double.
 *  3. Saldo API hanya diikuti jika LEBIH BESAR dari lokal (kemenangan game),
 *     atau jika turunnya karena withdraw/transfer yang sah.
 *  4. API down -> tampilkan saldo lokal terakhir (bukan 0).
 */

function write_bal_log($message) {
    $log_file = 'api_balance.log';
    $current_time = date('Y-m-d H:i:s');
    @file_put_contents($log_file, "[$current_time] $message" . PHP_EOL, FILE_APPEND);
}

if (!isset($_SESSION['user'])) {
    echo "0,00";
    exit();
}

$userQuery = "SELECT cuid, username FROM `tb_user` WHERE username = ?";
$userStmt = $conn->prepare($userQuery);
$userStmt->bind_param("s", $_SESSION['user']);
$userStmt->execute();
$u = $userStmt->get_result()->fetch_assoc();

if (!$u) {
    echo "0,00";
    exit();
}

$users = $u['username'];
$id_user = $u['cuid'];

// ============================================================
// 1. Ambil saldo lokal (source of truth saat API down / pending sync)
// ============================================================
$localBalance = 0;
$checkLocal = mysqli_query($conn, "SELECT active FROM `tb_balance` WHERE userID = '$id_user'");
if ($row = mysqli_fetch_assoc($checkLocal)) {
    $localBalance = floatval($row['active']);
}

// ============================================================
// 2. Cek deposit user ini yang belum masuk ke game API (GAME-API-FAIL)
// ============================================================
$pendingGameSync = false;
$pendingGameAmount = 0;
$syncQ = mysqli_query($conn, "SELECT cuid, total, kd_transaksi
    FROM `tb_transaksi`
    WHERE userID = '$id_user' AND jenis = 1 AND status = 1
      AND note LIKE '%GAME-API-FAIL%'
    ORDER BY cuid ASC");
if ($syncQ && ($n = mysqli_num_rows($syncQ)) > 0) {
    $pendingGameSync = true;
    while ($r = mysqli_fetch_assoc($syncQ)) {
        $pendingGameAmount += (float)$r['total'];
    }
    write_bal_log("PENDING-GAME-SYNC: User $users | $n trx belum masuk game | total=" . $pendingGameAmount);
}

// ============================================================
// 3. Panggil API NexusGGR untuk saldo game
// ============================================================
$apiBalance = null;
$api_connected = false;
$WL = null;
try {
    $WL = new fiver();
    $balance = $WL->userbalance($users);
    if (isset($balance['status']) && $balance['status'] == 1 && isset($balance['user']['balance'])) {
        $apiBalance = floatval($balance['user']['balance']);
        $api_connected = true;
        write_bal_log("SUCCESS: User $users | API Bal: $apiBalance | Local: $localBalance" . ($pendingGameSync ? " | PENDING-GAME-SYNC" : ""));
    } else {
        $error_msg = isset($balance['msg']) ? $balance['msg'] : 'Unknown Error';
        write_bal_log("ERROR: API Failed for $users | Msg: $error_msg");
    }
} catch (Exception $e) {
    write_bal_log("ERROR: Exception for $users | " . $e->getMessage());
}

// ============================================================
// 4. AUTO-RETRY deposit ke game API (recovery mandiri, tanpa cron)
//    Dedup transferStatus(agent_sign) supaya tidak double-deposit.
// ============================================================
if ($pendingGameSync && $api_connected && $WL !== null) {
    $retryQ = mysqli_query($conn, "SELECT cuid, total, kd_transaksi
        FROM `tb_transaksi`
        WHERE userID = '$id_user' AND jenis = 1 AND status = 1
          AND note LIKE '%GAME-API-FAIL%'
        ORDER BY cuid ASC");
    if ($retryQ) {
        while ($trx = mysqli_fetch_assoc($retryQ)) {
            $kd = (string)$trx['kd_transaksi'];
            $amount = (float)$trx['total'];
            if ($amount <= 0) continue;

            $agentSign = 'DEPO_' . $kd;
            $alreadyInGame = false;

            // Dedup: cek apakah deposit ini sudah pernah masuk ke game
            try {
                $ts = $WL->transferStatus($users, $agentSign);
                if (isset($ts['status']) && $ts['status'] == 1) {
                    $alreadyInGame = true;
                }
            } catch (Exception $e) { /* anggap belum, lanjut deposit */ }

            if ($alreadyInGame) {
                mysqli_query($conn, "UPDATE `tb_transaksi`
                    SET note = REPLACE(note, '[GAME-API-FAIL', '[GAME-API-RECOVERED')
                    WHERE cuid = '" . (int)$trx['cuid'] . "'");
                write_bal_log("RETRY-RECOVERED: $kd ternyata sudah masuk game -> flag dihapus");
                continue;
            }

            $res = $WL->deposit($users, (int)$amount, $agentSign);
            if (isset($res['status']) && $res['status'] == 1) {
                mysqli_query($conn, "UPDATE `tb_transaksi`
                    SET note = REPLACE(note, '[GAME-API-FAIL', '[GAME-API-RECOVERED')
                    WHERE cuid = '" . (int)$trx['cuid'] . "'");
                $pendingGameAmount -= $amount;
                write_bal_log("RETRY-OK: deposit ulang ke game sukses $kd +$amount");
            } else {
                $m = isset($res['msg']) ? $res['msg'] : '?';
                write_bal_log("RETRY-FAIL: $kd : $m");
            }
        }
    }
}

// ============================================================
// 5. Saldo final: prioritas saldo lokal saat ada pending game sync
// ============================================================
$final_balance = $localBalance;

if ($api_connected && $apiBalance !== null) {
    if ($pendingGameSync) {
        // Ada deposit belum masuk game -> lokal pasti >= seharusnya.
        // Saldo tampil = max(api, local)
        $final_balance = max($apiBalance, $localBalance);
    } elseif ($apiBalance > $localBalance) {
        $final_balance = $apiBalance;
    } elseif ($apiBalance < $localBalance) {
        // Turun HANYA jika tidak ada pending sync: kemungkinan member pindah
        // saldo ke game (transfer) atau withdraw sah -> ikuti API
        $final_balance = $apiBalance;
    }
}

// ============================================================
// 6. Sinkronisasi satu-arah-aman ke tb_balance
// ============================================================
$checkExist = mysqli_query($conn, "SELECT userID FROM `tb_balance` WHERE userID = '$id_user'");
if (mysqli_num_rows($checkExist) > 0) {
    $checkSaved = mysqli_query($conn, "SELECT active FROM `tb_balance` WHERE userID = '$id_user'");
    $savedRow = mysqli_fetch_assoc($checkSaved);
    $saved = floatval($savedRow['active']);
    if (abs($final_balance - $saved) > 0.001) {
        $updateStmt = $conn->prepare("UPDATE tb_balance SET active = ? WHERE userID = ?");
        $updateStmt->bind_param("di", $final_balance, $id_user);
        $updateStmt->execute();
        $updateStmt->close();
        write_bal_log("SYNC: User $users | $saved -> $final_balance" . ($pendingGameSync ? " (pending-game-sync dipertahankan)" : ""));
    }
} else {
    $insertStmt = $conn->prepare("INSERT INTO tb_balance (userID, active, pending, transfer, payout, created_date) VALUES (?, ?, 0, 0, 0, NOW())");
    $insertStmt->bind_param("id", $id_user, $final_balance);
    $insertStmt->execute();
    $insertStmt->close();
}

// Output untuk header member
echo number_format($final_balance, 2, ',', '.');
exit();
