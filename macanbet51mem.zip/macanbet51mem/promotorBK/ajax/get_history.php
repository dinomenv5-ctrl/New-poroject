<?php
// promotorBK/ajax/get_history.php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['promotor_authenticated']) || $_SESSION['promotor_authenticated'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Sesi tidak valid.']);
    exit;
}

include '../../config/koneksi.php'; 

// Fungsi helper
function format_rupiah($nominal) {
    return 'Rp ' . number_format($nominal, 0, ',', '.');
}

function translateJenis($code) {
    $map = ['1' => 'Deposit', '2' => 'Withdraw', '3' => 'Refferal', '4' => 'Rabate', '5' => 'Transfer', '6' => 'TransferBack', '7' => 'Promosi'];
    return $map[$code] ?? $code;
}

function translateStatus($code) {
    $map = [0 => 'Pending', 1 => 'Sukses', 2 => 'Batal/Gagal'];
    return $map[$code] ?? $code;
}

$response = ['status' => 'error', 'message' => 'Invalid request.', 'html' => ''];

if (isset($_POST['user_id']) && is_numeric($_POST['user_id'])) {
    $user_id = (int)$_POST['user_id'];
    
    // 1. Ambil Data User (untuk judul)
    $stmt_user = $conn->prepare("SELECT full_name, username FROM tb_user WHERE cuid = ?");
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $user = $stmt_user->get_result()->fetch_assoc();
    $stmt_user->close();
    
    if (!$user) {
        $response['message'] = 'User tidak ditemukan.';
        echo json_encode($response);
        mysqli_close($conn);
        exit;
    }

    // 2. Ambil Transaksi dengan bk_pay = 1
    $stmt_trans = $conn->prepare("
        SELECT kd_transaksi, date, transaksi, total, jenis, status 
        FROM tb_transaksi 
        WHERE userID = ? AND bk_pay = 1 
        ORDER BY date DESC
    ");
    $stmt_trans->bind_param("i", $user_id);
    $stmt_trans->execute();
    $result_trans = $stmt_trans->get_result();
    $total_trans = mysqli_num_rows($result_trans);
    $stmt_trans->close();

    $html = '<h5 class="text-light mb-3 border-bottom border-warning pb-2">History Payout Selesai: ' . htmlspecialchars($user['full_name']) . '</h5>';

    if ($total_trans > 0) {
        $html .= '<div class="alert alert-primary text-center fw-bold small py-2">Total ' . $total_trans . ' transaksi Selesai ditemukan.</div>';
        $html .= '<div class="table-responsive">';
        // Tambahkan ID unik untuk Datatables
        $html .= '<table id="historyTableAll" class="table table-dark table-striped table-hover table-bordered border-primary align-middle small w-100">';
        $html .= '<thead class="table-primary">';
        $html .= '<tr><th>Kode Transaksi</th><th>Tanggal</th><th>Jenis</th><th>Nominal</th><th>Status Transaksi</th></tr>';
        $html .= '</thead><tbody>';
        
        while($row = mysqli_fetch_assoc($result_trans)) {
            $date_formatted = date('d/m/Y H:i', strtotime($row['date']));
            $jenis_text = translateJenis($row['jenis']);
            $status_text = translateStatus($row['status']);
            $total_formatted = format_rupiah($row['total']);
            
            $html .= '<tr>';
            $html .= '<td>' . htmlspecialchars($row['kd_transaksi']) . '</td>';
            $html .= '<td>' . $date_formatted . '</td>';
            $html .= '<td>' . $jenis_text . '</td>';
            $html .= '<td class="fw-bold text-success">' . $total_formatted . '</td>';
            $html .= '<td>' . $status_text . '</td>';
            $html .= '</tr>';
        }
        
        $html .= '</tbody></table></div>';
    } else {
        $html .= '<div class="alert alert-warning text-center">Tidak ada history transaksi dengan Status Payout Selesai.</div>';
    }

    $response['status'] = 'success';
    $response['html'] = $html;
}

mysqli_close($conn);
echo json_encode($response);