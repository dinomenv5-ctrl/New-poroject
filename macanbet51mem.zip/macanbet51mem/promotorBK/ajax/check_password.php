<?php
session_start();
header('Content-Type: application/json');
$passwords = [
    'BK2025'     => 'viewer',
    'adminBK2025' => 'admin'
];
// ------------------------------------------

$response = ['status' => 'error', 'message' => ''];

if (isset($_POST['password'])) {
    $input_password = trim($_POST['password']);    
    if (isset($passwords[$input_password])) {
        $user_level = $passwords[$input_password];        
        $_SESSION['promotor_authenticated'] = true;
        $_SESSION['user_level'] = $user_level;
        
        $response['status'] = 'success';
        $response['message'] = 'Akses ' . ucfirst($user_level) . ' diberikan.';
        $response['level'] = $user_level;
    } else {
        $response['message'] = 'Password salah. Akses ditolak.';
    }
} else {
    $response['message'] = 'Permintaan tidak valid.';
}

echo json_encode($response);
?>