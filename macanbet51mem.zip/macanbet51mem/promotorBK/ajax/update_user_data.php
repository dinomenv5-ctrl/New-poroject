<?php
// promotorBK/ajax/update_user_data.php
session_start();
header('Content-Type: application/json');

// Memastikan hanya Admin yang dapat mengakses skrip ini
if (!isset($_SESSION['promotor_authenticated']) || $_SESSION['promotor_authenticated'] !== true || $_SESSION['user_level'] !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Akses ditolak. Hanya Admin yang dapat melakukan update.']);
    exit;
}

include '../../config/koneksi.php'; 

$response = ['status' => 'error', 'message' => 'Permintaan tidak valid.'];

// Pastikan semua data yang diperlukan diterima
if (
    isset($_POST['cuid']) && is_numeric($_POST['cuid']) &&
    isset($_POST['full_name']) &&
    isset($_POST['email']) &&
    isset($_POST['phone_number'])
) {
    $cuid = (int)$_POST['cuid'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone_number = trim($_POST['phone_number']);

    // Mulai proses update
    $stmt = $conn->prepare("UPDATE tb_user SET full_name = ?, email = ?, phone_number = ? WHERE cuid = ?");
    $stmt->bind_param("sssi", $full_name, $email, $phone_number, $cuid);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $response['status'] = 'success';
            $response['message'] = 'Data user ID ' . $cuid . ' berhasil diperbarui.';
        } else {
            $response['status'] = 'success';
            $response['message'] = 'Data user tidak berubah atau CUID tidak ditemukan.';
        }
    } else {
        $response['message'] = 'Kesalahan database saat eksekusi: ' . $conn->error;
    }

    $stmt->close();

} else {
    $response['message'] = 'Data input tidak lengkap.';
}

mysqli_close($conn);
echo json_encode($response);
?>