<?php
/**
 * ============================================================
 *  SCRIPT DIAGNOSTIK KONEKSI DATABASE
 *  Upload file ini ke root domain Anda, lalu akses via browser:
 *  https://one.macanbet51.ink/diagnosa.php
 *  https://admin-panel.macanbet51.org/diagnosa.php
 *
 *  HAPUS file ini setelah selesai debugging (jangan biarkan online)
 * ============================================================
 */
header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html><html><head><meta charset='utf-8'>";
echo "<title>Diagnosa Koneksi Database</title>";
echo "<style>
body{font-family:Segoe UI,sans-serif;background:#1e293b;color:#e2e8f0;padding:30px;line-height:1.6}
.box{background:#334155;border-radius:10px;padding:20px;margin:15px 0}
.ok{background:#052e16;border:2px solid #22c55e}
.fail{background:#450a0a;border:2px solid #ef4444}
.warn{background:#422006;border:2px solid #f59e0b}
h1{color:#818cf8}h2{color:#a5b4fc;margin-top:25px}
code{background:#0f172a;padding:3px 8px;border-radius:4px;color:#93c5fd}
pre{background:#0f172a;padding:12px;border-radius:6px;overflow-x:auto;color:#cbd5e1}
table{width:100%;border-collapse:collapse;margin:10px 0}
td,th{border:1px solid #475569;padding:8px;text-align:left}
th{background:#475569}
</style></head><body>";

echo "<h1>🔧 Diagnosa Koneksi Database</h1>";
echo "<p>Waktu: " . date('Y-m-d H:i:s') . " | Server: " . php_uname() . "</p>";

// --- 1. Info PHP ---
echo "<div class='box'><h2>1. Info PHP</h2>";
echo "<table>";
echo "<tr><td>Versi PHP</td><td>" . PHP_VERSION . "</td></tr>";
echo "<tr><td>Ekstensi mysqli</td><td>" . (extension_loaded('mysqli') ? '✅ Aktif' : '❌ TIDAK ADA') . "</td></tr>";
echo "<tr><td>Ekstensi curl</td><td>" . (extension_loaded('curl') ? '✅ Aktif' : '❌ TIDAK ADA') . "</td></tr>";
echo "<tr><td>Ekstensi json</td><td>" . (extension_loaded('json') ? '✅ Aktif' : '❌ TIDAK ADA') . "</td></tr>";
echo "<tr><td>Display Errors</td><td>" . (ini_get('display_errors') ? 'ON' : 'OFF') . "</td></tr>";
echo "<tr><td>Document Root</td><td>" . $_SERVER['DOCUMENT_ROOT'] . "</td></tr>";
echo "<tr><td>Script Path</td><td>" . __DIR__ . "</td></tr>";
echo "</table></div>";

// --- 2. Cek file koneksi ---
echo "<div class='box'><h2>2. Cek File Koneksi Database</h2>";

$koneksi_paths = [
    'config/koneksi.php (member)' => __DIR__ . '/config/koneksi.php',
    'assets/config/koneksi.php (admin)' => __DIR__ . '/assets/config/koneksi.php',
    'assets/config.php (admin entry)' => __DIR__ . '/assets/config.php',
];

foreach ($koneksi_paths as $label => $path) {
    echo "<p><strong>$label</strong><br>";
    echo "Path: <code>$path</code><br>";
    if (file_exists($path)) {
        echo "Status: ✅ File ADA<br>";
        $content = file_get_contents($path);
        // Extract DB config values
        if (preg_match('/\$host\s*=\s*"([^"]*)"/', $content, $h))
            echo "→ host = <code>" . htmlspecialchars($h[1]) . "</code><br>";
        if (preg_match('/\$user\s*=\s*"([^"]*)"/', $content, $u))
            echo "→ user = <code>" . htmlspecialchars($u[1]) . "</code><br>";
        if (preg_match('/\$database\s*=\s*"([^"]*)"/', $content, $d))
            echo "→ database = <code>" . htmlspecialchars($d[1]) . "</code><br>";
        echo "→ password = <code>" . (preg_match('/\$password\s*=\s*"([^"]*)"/', $content, $p) && $p[1] !== '' ? '(terisi, ' . strlen($p[1]) . ' karakter)' : '(kosong)') . "</code></p>";
    } else {
        echo "Status: ❌ FILE TIDAK ADA — ini penyebab error!</p>";
    }
}
echo "</div>";

// --- 3. Coba koneksi database ---
echo "<div class='box'><h2>3. Test Koneksi Database</h2>";

$configs_to_test = [];
if (file_exists(__DIR__ . '/config/koneksi.php')) {
    $c = file_get_contents(__DIR__ . '/config/koneksi.php');
    $cfg = [];
    if (preg_match('/\$host\s*=\s*"([^"]*)"/', $c, $m)) $cfg['host'] = $m[1];
    if (preg_match('/\$user\s*=\s*"([^"]*)"/', $c, $m)) $cfg['user'] = $m[1];
    if (preg_match('/\$password\s*=\s*"([^"]*)"/', $c, $m)) $cfg['password'] = $m[1];
    if (preg_match('/\$database\s*=\s*"([^"]*)"/', $c, $m)) $cfg['database'] = $m[1];
    $configs_to_test['config/koneksi.php'] = $cfg;
}
if (file_exists(__DIR__ . '/assets/config/koneksi.php')) {
    $c = file_get_contents(__DIR__ . '/assets/config/koneksi.php');
    $cfg = [];
    if (preg_match('/\$host\s*=\s*"([^"]*)"/', $c, $m)) $cfg['host'] = $m[1];
    if (preg_match('/\$user\s*=\s*"([^"]*)"/', $c, $m)) $cfg['user'] = $m[1];
    if (preg_match('/\$password\s*=\s*"([^"]*)"/', $c, $m)) $cfg['password'] = $m[1];
    if (preg_match('/\$database\s*=\s*"([^"]*)"/', $c, $m)) $cfg['database'] = $m[1];
    $configs_to_test['assets/config/koneksi.php'] = $cfg;
}

if (empty($configs_to_test)) {
    echo "<p class='fail'>❌ Tidak ada file koneksi.php ditemukan. Upload file website dengan benar dulu.</p>";
} else {
    foreach ($configs_to_test as $label => $cfg) {
        echo "<h3>$label</h3>";
        echo "<p>Mencoba connect: host=<code>{$cfg['host']}</code> user=<code>{$cfg['user']}</code> db=<code>{$cfg['database']}</code></p>";
        $conn = @mysqli_connect($cfg['host'], $cfg['user'], $cfg['password'], $cfg['database']);
        if ($conn) {
            echo "<p class='ok'>✅ KONEKSI BERHASIL ke database <code>{$cfg['database']}</code></p>";
            // Cek tabel tb_seo
            $r = mysqli_query($conn, "SHOW TABLES LIKE 'tb_seo'");
            if (mysqli_num_rows($r) > 0) {
                echo "<p class='ok'>✅ Tabel <code>tb_seo</code> ADA</p>";
                $r2 = mysqli_query($conn, "SELECT cuid, pga_provider, autogopay_apikey, urlweb, urlweb2 FROM tb_seo WHERE cuid=1");
                if ($row = mysqli_fetch_assoc($r2)) {
                    echo "<pre>" . print_r($row, true) . "</pre>";
                }
                // Cek kolom autogopay
                $r3 = mysqli_query($conn, "SHOW COLUMNS FROM tb_seo LIKE 'autogopay%'");
                echo "<p>Kolom AutoGopay: " . mysqli_num_rows($r3) . " ditemukan</p>";
            } else {
                echo "<p class='fail'>❌ Tabel <code>tb_seo</code> TIDAK ADA — database belum di-import! Import <code>database_ugrzavpi_firmansyah.sql</code></p>";
            }
            mysqli_close($conn);
        } else {
            echo "<p class='fail'>❌ KONEKSI GAGAL: " . mysqli_connect_error() . " (error " . mysqli_connect_errno() . ")</p>";
            echo "<p class='warn'>→ Penyebab: Database <code>{$cfg['database']}</code> belum dibuat di aaPanel, ATAU user/password salah.</p>";
            echo "<p class='warn'>→ SOLUSI: Buat database di aaPanel → Database → Add Database, lalu edit <code>$label</code> dengan kredensial baru.</p>";
        }
    }
}
echo "</div>";

// --- 4. Cek file penting ---
echo "<div class='box'><h2>4. Cek File Penting Website</h2>";
$important_files = [
    'index.php' => __DIR__ . '/index.php',
    'config/koneksi.php' => __DIR__ . '/config/koneksi.php',
    'config/class.autogopay.php' => __DIR__ . '/config/class.autogopay.php',
    'callback_autogopay.php' => __DIR__ . '/callback_autogopay.php',
    'function/generate_qris_autogopay.php' => __DIR__ . '/function/generate_qris_autogopay.php',
    'm/account/qris_deposit.php' => __DIR__ . '/m/account/qris_deposit.php',
    'assets/index.php' => __DIR__ . '/assets/index.php',
    'assets/config.php' => __DIR__ . '/assets/config.php',
    'assets/config/koneksi.php' => __DIR__ . '/assets/config/koneksi.php',
    'assets/general.php' => __DIR__ . '/assets/general.php',
    'database_ugrzavpi_firmansyah.sql' => __DIR__ . '/database_ugrzavpi_firmansyah.sql',
];
echo "<table><tr><th>File</th><th>Status</th></tr>";
foreach ($important_files as $label => $path) {
    $exists = file_exists($path);
    echo "<tr><td><code>$label</code></td><td>" . ($exists ? "✅ ADA" : "❌ TIDAK ADA") . "</td></tr>";
}
echo "</table></div>";

// --- 5. Cek folder writable ---
echo "<div class='box'><h2>5. Cek Permission Folder</h2>";
$folders = ['logs', 'uploads', 'config', 'assets/config', 'function'];
echo "<table><tr><th>Folder</th><th>Ada?</th><th>Writable?</th><th>Permission</th></tr>";
foreach ($folders as $f) {
    $path = __DIR__ . '/' . $f;
    $exists = is_dir($path);
    $writable = $exists && is_writable($path);
    $perm = $exists ? substr(sprintf('%o', fileperms($path)), -4) : '-';
    echo "<tr><td><code>$f/</code></td><td>" . ($exists ? "✅" : "❌") . "</td><td>" . ($writable ? "✅" : "❌") . "</td><td>$perm</td></tr>";
}
echo "</table></div>";

// --- 6. Kesimpulan ---
echo "<div class='box'><h2>📋 Kesimpulan & Langkah Selanjutnya</h2>";
echo "<p>Berdasarkan hasil di atas, lakukan hal berikut:</p>";
echo "<ol>";
echo "<li><strong>Jika koneksi GAGAL (langkah 3):</strong> Buat database baru di aaPanel → Database → Add Database. Catat nama DB, user, password.</li>";
echo "<li>Edit file <code>config/koneksi.php</code> DAN <code>assets/config/koneksi.php</code> — isi dengan kredensial database baru. <strong>Gunakan database yang SAMA untuk keduanya.</strong></li>";
echo "<li>Import <code>database_ugrzavpi_firmansyah.sql</code> via phpMyAdmin (aaPanel → Database → phpMyAdmin → Import).</li>";
echo "<li>Jika ada file TIDAK ADA (langkah 4): Upload ulang file website — pastikan isi folder <code>merged/</code> langsung ke root domain, bukan folder merged-nya.</li>";
echo "<li>Hapus file <code>index.html</code> default aaPanel (di domain member) supaya <code>index.php</code> yang jalan.</li>";
echo "<li>Refresh halaman ini untuk cek ulang. Jika langkah 3 = BERHASIL, website harusnya jalan.</li>";
echo "</ol>";
echo "<p class='warn'><strong>⚠️ JANGAN LUPA:</strong> Hapus file <code>diagnosa.php</code> ini setelah selesai, karena file ini menampilkan info sensitif database.</p>";
echo "</div>";

echo "</body></html>";
