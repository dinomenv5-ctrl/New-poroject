<?php
// referral_detail.php
include 'config/koneksi.php'; // Path ke file koneksi

// Cek apakah parameter promotor_id ada di URL
if (!isset($_GET['promotor_id']) || !is_numeric($_GET['promotor_id'])) {
    // Redirect atau tampilkan pesan error jika ID tidak valid
    header("Location: index.php");
    exit;
}

$promotor_id = (int)$_GET['promotor_id'];

// 1. Ambil detail Promotor
// Menggunakan prepared statement untuk keamanan
$stmt_promotor = $conn->prepare("SELECT username, full_name FROM tb_user WHERE cuid = ?");
$stmt_promotor->bind_param("i", $promotor_id);
$stmt_promotor->execute();
$result_promotor = $stmt_promotor->get_result();
$promotor = $result_promotor->fetch_assoc();
$stmt_promotor->close();

if (!$promotor) {
    // Jika Promotor tidak ditemukan
    die("Promotor tidak ditemukan.");
}

// 2. Ambil daftar User yang dirujuk oleh Promotor ini
$stmt_referrals = $conn->prepare("SELECT username, full_name, join_date FROM tb_user WHERE referral_user_id = ? ORDER BY join_date DESC");
$stmt_referrals->bind_param("i", $promotor_id);
$stmt_referrals->execute();
$result_referrals = $stmt_referrals->get_result();
$stmt_referrals->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Rujukan: <?php echo htmlspecialchars($promotor['full_name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            padding-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-3">User Rujukan</h1>
        <h2 class="text-primary mb-4"><?php echo htmlspecialchars($promotor['full_name']); ?> (<?php echo htmlspecialchars($promotor['username']); ?>)</h2>

        <a href="index.php" class="btn btn-secondary mb-3">
            &larr; Kembali ke Daftar Promotor
        </a>

        <?php if (mysqli_num_rows($result_referrals) > 0): ?>
            <div class="alert alert-success">
                Total **<?php echo mysqli_num_rows($result_referrals); ?>** pengguna dirujuk.
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered">
                    <thead class="table-success">
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Nama Lengkap</th>
                            <th>Tanggal Gabung</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while($row = mysqli_fetch_assoc($result_referrals)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                <td><?php echo date('d-m-Y H:i:s', strtotime($row['join_date'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                Pengguna ini belum memiliki rujukan.
            </div>
        <?php endif; ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
// Tutup koneksi
mysqli_close($conn);
?>