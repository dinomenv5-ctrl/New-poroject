<?php
require_once('session.php');
include('../config/class_softgaming.php');

date_default_timezone_set("Asia/Jakarta");

/* ===============================
   DATA USER & GAME
=================================*/
$useridnya = $u['username'];
$gameID = isset($_GET['gamecode']) ? trim($_GET['gamecode']) : '';
$gameProvider = isset($_GET['providercode']) ? trim($_GET['providercode']) : '';
$lang = isset($_GET['lang']) ? trim($_GET['lang']) : 'en';

/* ===============================
   DEBUG INFO
=================================*/
$debugInfo = [
    'username' => $useridnya,
    'game_code' => $gameID,
    'provider_code' => $gameProvider,
    'lang' => $lang,
    'timestamp' => date('Y-m-d H:i:s')
];

/* ===============================
   REQUEST API GAME
=================================*/
$WL = new fiver();
$response = $WL->opengame($useridnya, $gameID, $gameProvider, $lang);

/* ===============================
   JIKA SUCCESS
=================================*/
if (isset($response['status']) && $response['status'] == 1) {

    // PRIORITAS URL
    $gameUrl = null;

    if (!empty($response['launch_url'])) {
        $gameUrl = $response['launch_url'];
    } elseif (!empty($response['game_url'])) {
        $gameUrl = $response['game_url'];
    } elseif (!empty($response['url'])) {
        $gameUrl = $response['url'];
    }

    if ($gameUrl && filter_var($gameUrl, FILTER_VALIDATE_URL)) {
        header("Location: " . $gameUrl);
        exit();
    } else {
        $errorMessage = "Status SUCCESS tapi URL tidak valid.";
    }
}

/* ===============================
   HANDLE ERROR
=================================*/
$errorMessage = 'Game sedang dalam perbaikan atau tidak ditemukan. Silakan coba lagi nanti.';

if (!empty($response['msg'])) {
    $errorMessage = $response['msg'];
} elseif (!empty($response['error'])) {
    $errorMessage = $response['error'];
} elseif (!empty($response['message'])) {
    $errorMessage = $response['message'];
}

$fullResponse = json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$fullResponse = htmlspecialchars($fullResponse, ENT_QUOTES, 'UTF-8');

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Error Launch Game</title>
<style>
body {
    font-family: Arial, sans-serif;
    padding: 20px;
    background-color: #f5f5f5;
}
.error-container {
    max-width: 800px;
    margin: 50px auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
.error-message {
    background: #fee;
    border-left: 4px solid #f00;
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 4px;
}
.response-container {
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 15px;
    margin-bottom: 20px;
}
.response-title {
    font-weight: bold;
    margin-bottom: 10px;
    color: #333;
}
pre {
    background: #2d2d2d;
    color: #f8f8f2;
    padding: 15px;
    border-radius: 4px;
    overflow-x: auto;
    font-size: 12px;
    line-height: 1.5;
}
.btn-back {
    background: #007bff;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
}
.btn-back:hover {
    background: #0056b3;
}
</style>
</head>
<body>

<div class='error-container'>
    <div class='error-message'>
        <strong>Error:</strong> <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8'); ?>
    </div>

    <div class='response-container'>
        <div class='response-title'>Request Info:</div>
        <pre style='background: #e8f4f8; color: #333; margin-bottom: 15px;'>
<?= htmlspecialchars(json_encode($debugInfo, JSON_PRETTY_PRINT), ENT_QUOTES, 'UTF-8'); ?>
        </pre>

        <div class='response-title'>Seluruh Response API:</div>
        <pre><?= $fullResponse; ?></pre>
    </div>

    <button class='btn-back' onclick='window.history.back()'>Kembali</button>
</div>

</body>
</html>