<?php
//error_reporting(E_ALL);
$host = "localhost";
$user = "macaaajk_on";
$password = "macaaajk_on";
$database = "macaaajk_on";
// [DAEMON-SAFE RECONNECT] Mode biasa: die() bila koneksi gagal (perilaku
// asli tetap sama untuk semua halaman web). Mode daemon cron auto-credit
// (flag $GLOBALS['AG_KONEKSI_NO_DIE'] dipasang oleh cron_autocredit_qris.php):
// kembalikan false supaya cron bisa retry reconnect tanpa mematikan daemon.
try {
    $conn = @mysqli_connect($host, $user, $password, $database);
} catch (Throwable $e) {
    $conn = false;
}
if ($conn === false || $conn === null) {
    if (!empty($GLOBALS['AG_KONEKSI_NO_DIE'])) {
        $conn = false; // biarkan pemanggil (daemon) yang menangani retry
    } else {
        die('Database connection failed');
    }
}
//cek koneksi 
if ($conn) {
    //echo "berhasil koneksi"; 
} else {
    echo "gagal koneksi";
}
