<?php

class fiver
{
    public $agen    =   "firmandong";
    public $token = "f8122cdb9b2f157b038a89c35efa71ed";
    public $url = "https://api.nexusggr.com";

    public function provider_list()
    {
        $param = [
            'method' => 'provider_list',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
        ];
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }

    public function create($username)
    {
        $param = [
            'method' => 'user_create',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'user_code' => $username,
        ];
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }

    public function userbalance($username = null)
    {
        $param = [
            'method' => 'money_info',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
        ];
        if ($username) {
            $param['user_code'] = $username;
        }
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }

    public function agentbalance()
    {
        $param = [
            'method' => 'money_info',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
        ];
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }

    public function deposit($username, $amount, $agent_sign = null)
    {
        $param = [
            'method' => 'user_deposit',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'user_code' => $username,
            'amount' => $amount,
        ];
        if ($agent_sign) {
            $param['agent_sign'] = $agent_sign;
        }
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }

    public function withdraw($username, $amount, $agent_sign = null)
    {
        $param = [
            'method' => 'user_withdraw',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'user_code' => $username,
            'amount' => $amount,
        ];
        if ($agent_sign) {
            $param['agent_sign'] = $agent_sign;
        }
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }

    public function resetBalance($username = null)
    {
        $param = [
            'method' => 'user_withdraw_reset',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
        ];
        if ($username) {
            $param['user_code'] = $username;
        } else {
            $param['all_users'] = true;
        }
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }

    public function gamelist($provider)
    {
        $param = [
            'method' => 'game_list',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'provider_code' => $provider,
        ];
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        if (is_string($result)) {
            $decoded = json_decode($result, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
            return ['status' => 0, 'msg' => 'JSON_DECODE_ERROR: ' . json_last_error_msg(), 'raw' => $result];
        }
        return $result;
    }

    public function gamelist_v2($provider)
    {
        $param = [
            'method' => 'game_list_v2',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'provider_code' => $provider,
        ];
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        if (is_string($result)) {
            $decoded = json_decode($result, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
            return ['status' => 0, 'msg' => 'JSON_DECODE_ERROR: ' . json_last_error_msg(), 'raw' => $result];
        }
        return $result;
    }

    public function callPlayer()
    {
        $param = [
            'method' => 'call_players',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
        ];

        $url = $this->url;
        return $this->sg_connect($url, $param);
    }

    public function callList($provider, $gamecode, $username)
    {
        $param = [
            'method' => 'call_list',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'provider_code' => $provider,
            'game_code' => $gamecode,
            'user_code' => $username,
        ];

        $url = $this->url;
        return $this->sg_connect($url, $param);
    }

    public function callApply($provider, $gamecode, $username, $rtp, $type)
    {
        $param = [
            'method' => 'call_apply',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'provider_code' => $provider,
            'game_code' => $gamecode,
            'user_code' => $username,
            'call_rtp' => $rtp,
            'call_type' => $type,
        ];

        $url = $this->url;
        return $this->sg_connect($url, $param);
    }

    public function opengame($username, $gamecode, $game_provider, $lang = 'en')
    {
        $param = [
            'method' => 'game_launch',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'user_code' => $username,
            'game_code' => $gamecode,
            'provider_code' => $game_provider,
            'lang' => $lang,
        ];
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }

    public function historyPlay($username, $type, $start, $end, $page, $perpage)
    {
        $param = [
            'method' => 'get_game_log',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'user_code' => $username,
            'game_type' => $type,
            'start' => $start,
            'end' => $end,
            'page' => $page,
            'perPage' => $perpage,
        ];

        $url = $this->url;
        return $this->sg_connect($url, $param);
    }

    public function transferStatus($username, $agent_sign)
    {
        $param = [
            'method' => 'transfer_status',
            'agent_code' => $this->agen,
            'agent_token' => $this->token,
            'user_code' => $username,
            'agent_sign' => $agent_sign,
        ];
        $url = $this->url;
        $result = $this->sg_connect($url, $param);
        return json_decode($result, true);
    }


    private function sg_connect($url, $postArray)
    {
        $jsonData = json_encode($postArray);
        $headerArray = ['Content-Type: application/json'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.47 Safari/537.36');
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headerArray);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $res = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return json_encode(['status' => 0, 'msg' => 'CURL_ERROR: ' . $curlError]);
        }

        if ($httpCode !== 200) {
            $errorMsg = 'HTTP_ERROR_' . $httpCode;
            if ($httpCode == 403) {
                $errorMsg .= ' - Akses ditolak. Periksa agent_code dan agent_token Anda.';
            } elseif ($httpCode == 401) {
                $errorMsg .= ' - Unauthorized. Token tidak valid.';
            }
            return json_encode(['status' => 0, 'msg' => $errorMsg, 'http_code' => $httpCode, 'response' => $res]);
        }

        return $res;
    }
}

$WL = new fiver();
