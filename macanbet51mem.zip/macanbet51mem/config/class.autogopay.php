<?php
/**
 * AutoGopay Payment Gateway Client
 * Platform: https://autogopay.net
 * Docs:    https://autogopay.net/documentation
 *
 * Menghubungkan sistem ke akun GoPay Merchant pribadi via AutoGopay.
 *  - createPayment()  : POST /api/v1/payment/create  -> QRIS dinamis
 *  - getStatus()      : GET  /api/v1/payment/status/{reference}
 *  - cancelPayment()  : POST /api/v1/payment/cancel
 *  - verifyWebhook()  : HMAC-SHA256 signature verification
 *
 * Tidak ada potongan fee per transaksi (0%), dana langsung ke saldo GoPay Merchant.
 */
class AutoGopay
{
    /** @var string Base URL AutoGopay */
    private $baseUrl = 'https://autogopay.net';

    /** @var string API Key (format: iak_xxxxxx) */
    private $apiKey;

    /** @var string Webhook Secret Key untuk verifikasi signature */
    private $webhookSecret;

    /** @var string Mode verifikasi webhook: 'legacy' (default) | 'strict' */
    private $webhookMode;

    public function __construct($apiKey, $webhookSecret = '', $webhookMode = 'legacy')
    {
        $this->apiKey        = trim((string)$apiKey);
        $this->webhookSecret = trim((string)$webhookSecret);
        $this->webhookMode   = ($webhookMode === 'strict') ? 'strict' : 'legacy';
    }

    /**
     * Buat invoice / QRIS dinamis baru
     *
     * @param array $params [
     *      'amount'        => int,    // wajib, min 1000
     *      'reference'     => string, // ID unik dari sistem Anda
     *      'description'   => string,
     *      'customer_name' => string,
     *      'callback_url'  => string, // URL webhook untuk transaksi ini
     * ]
     * @return array decoded JSON response dari AutoGopay
     */
    public function createPayment(array $params)
    {
        $payload = [
            'amount' => (int)($params['amount'] ?? 0),
        ];

        if (!empty($params['reference'])) {
            $payload['reference'] = (string)$params['reference'];
        }
        if (!empty($params['description'])) {
            $payload['description'] = (string)$params['description'];
        }
        if (!empty($params['customer_name'])) {
            $payload['customer_name'] = (string)$params['customer_name'];
        }
        if (!empty($params['callback_url'])) {
            $payload['callback_url'] = (string)$params['callback_url'];
        }

        return $this->request('POST', '/api/v1/payment/create', $payload);
    }

    /**
     * Cek status pembayaran by reference (ID dari sistem Anda)
     *
     * @param string $reference
     * @return array
     */
    public function getStatus($reference)
    {
        $reference = rawurlencode((string)$reference);
        return $this->request('GET', '/api/v1/payment/status/' . $reference);
    }

    /**
     * Batalkan transaksi pending
     *
     * @param string $reference ID sistem Anda
     * @param string $invoice   ID invoice AutoGopay (INV-xxxx)
     * @return array
     */
    public function cancelPayment($reference = '', $invoice = '')
    {
        $payload = [];
        if (!empty($reference)) {
            $payload['reference'] = (string)$reference;
        }
        if (!empty($invoice)) {
            $payload['invoice'] = (string)$invoice;
        }
        return $this->request('POST', '/api/v1/payment/cancel', $payload);
    }

    /**
     * Verifikasi signature webhook AutoGopay (HMAC-SHA256)
     *
     * Signature = HMAC-SHA256( json_encode(payload tanpa 'signature'), webhookSecret )
     *
     * [HARDENING] Jika webhookSecret KOSONG:
     *   - Mode default 'legacy' (kompatibilitas ke belakang): return true
     *     -> untuk instalasi yang belum mengisi wh_secret di panel admin.
     *        JANGAN lupa isi autogopay_wh_secret di Setting admin agar
     *        webhook terverifikasi penuh (lihat LAPORAN_PERBAIKAN_QRIS.md).
     *   - Mode 'strict' (disarankan produksi): return FALSE — webhook tanpa
     *     secret terkonfigurasi akan ditolak.
     *     Cara aktifkan strict: new AutoGopay($key, $secret, 'strict')
     *
     * @param array $payload decoded JSON body dari webhook
     * @return bool
     */
    public function verifyWebhook(array $payload)
    {
        if ($this->webhookSecret === '') {
            if ($this->webhookMode === 'strict') {
                // Strict: tanpa secret terpasang, semua webhook DITOLAK
                return false;
            }
            // Legacy: secret belum dikonfigurasi -> lewati verifikasi
            // (tidak disarankan di produksi). Callback_autogopay.php tetap
            // memvalidasi transaksi & nominal sebelum kredit.
            return true;
        }

        if (!isset($payload['signature']) || $payload['signature'] === '') {
            return false;
        }

        $signature = (string)$payload['signature'];
        unset($payload['signature']);

        $expected = hash_hmac('sha256', json_encode($payload), $this->webhookSecret);

        return hash_equals($expected, $signature);
    }

    /**
     * Cek apakah status pembayaran termasuk sukses
     *
     * @param string $status
     * @return bool
     */
    public function isPaymentSuccess($status)
    {
        return strtolower((string)$status) === 'success';
    }

    /**
     * Cek apakah status transaksi final (tidak perlu diproses lagi)
     *
     * @param string $status
     * @return bool
     */
    public function isFinalStatus($status)
    {
        $s = strtolower((string)$status);
        return in_array($s, ['success', 'failed', 'expired'], true);
    }

    /**
     * HTTP request wrapper ke API AutoGopay
     *
     * @param string $method POST|GET
     * @param string $path
     * @param array|null $payload
     * @return array
     */
    private function request($method, $path, $payload = null)
    {
        if ($this->apiKey === '') {
            return [
                'success' => false,
                'message' => 'API Key AutoGopay belum dikonfigurasi',
            ];
        }

        $url = rtrim($this->baseUrl, '/') . $path;
        $ch  = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);

        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'X-API-Key: ' . $this->apiKey,
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        if (strtoupper($method) === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        } elseif (strtoupper($method) === 'GET') {
            curl_setopt($ch, CURLOPT_HTTPGET, true);
        }

        $response  = curl_exec($ch);
        $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return [
                'success' => false,
                'message' => 'CURL Error: ' . $curlError,
                '_http_code' => (int)$httpCode,
            ];
        }

        $decoded = json_decode($response, true);
        if (!is_array($decoded)) {
            return [
                'success' => false,
                'message' => 'Invalid JSON response dari AutoGopay',
                'raw' => $response,
                '_http_code' => (int)$httpCode,
            ];
        }

        $decoded['_http_code'] = (int)$httpCode;
        return $decoded;
    }
}
