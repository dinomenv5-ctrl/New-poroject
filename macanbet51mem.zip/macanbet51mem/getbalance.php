<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('config/koneksi.php');
include('config/class_softgaming.php');
$sid = session_id();

/**
 * getbalance.php — FIXED VERSION
 * BUG LAMA: menimpa tb_balance.active dengan saldo API game tanpa proteksi,
 * sehingga deposit QRIS yang sudah dikredit lokal tapi gagal masuk ke game
 * API akan DINOALKAN saat member membuka halaman -> "saldo tidak masuk".
 * PERBAIKAN: sama dengan getBal.php (proteksi pending-game-sync + retry).
 */

// Jika tidak ada session user, kembalikan 0,00 (jangan fatal error)
if (!isset($_SESSION['user']) || $_SESSION['user'] === '') {
    echo "0,00";
    exit();
}

$user = mysqli_query($conn, "SELECT * FROM tb_user WHERE username = '" . mysqli_real_escape_string($conn, $_SESSION['user']) . "'");
if (!$user || mysqli_num_rows($user) == 0) {
    echo "0,00";
    exit();
}
$u = mysqli_fetch_array($user);

$users = $u['username'];
$id_user = $u['cuid'];
$userID = $u['cuid'];

// 1. Saldo lokal (source of truth saat API down / pending sync)
$localBalance = 0;
$checkLocal = mysqli_query($conn, "SELECT active FROM `tb_balance` WHERE userID = '$userID'");
if ($row = mysqli_fetch_assoc($checkLocal)) {
    $localBalance = floatval($row['active']);
}

// 2. Cek deposit belum masuk game API (GAME-API-FAIL)
$pendingGameSync = false;
$syncQ = mysqli_query($conn, "SELECT cuid FROM `tb_transaksi`
    WHERE userID = '$userID' AND jenis = 1 AND status = 1
      AND note LIKE '%GAME-API-FAIL%' LIMIT 1");
if ($syncQ && mysqli_num_rows($syncQ) > 0) {
    $pendingGameSync = true;
}

// 3. Saldo dari API game
$apiBalance = null;
$api_connected = false;
$WL = new fiver();
try {
    $balance = $WL->userbalance($users);
    if (isset($balance['status']) && $balance['status'] == 1 && isset($balance['user']['balance'])) {
        $apiBalance = floatval($balance['user']['balance']);
        $api_connected = true;
    }
} catch (Exception $e) {
    // API down -> pakai lokal
}

// 4. Auto-retry deposit game untuk GAME-API-FAIL (dedup transferStatus)
if ($pendingGameSync && $api_connected) {
    $retryQ = mysqli_query($conn, "SELECT cuid, total, kd_transaksi FROM `tb_transaksi`
        WHERE userID = '$userID' AND jenis = 1 AND status = 1
          AND note LIKE '%GAME-API-FAIL%' ORDER BY cuid ASC");
    if ($retryQ) {
        while ($trx = mysqli_fetch_assoc($retryQ)) {
            $kd = (string)$trx['kd_transaksi'];
            $amount = (float)$trx['total'];
            if ($amount <= 0) continue;
            $agentSign = 'DEPO_' . $kd;

            $alreadyInGame = false;
            try {
                $ts = $WL->transferStatus($users, $agentSign);
                if (isset($ts['status']) && $ts['status'] == 1) {
                    $alreadyInGame = true;
                }
            } catch (Exception $e) { /* anggap belum */ }

            if ($alreadyInGame) {
                mysqli_query($conn, "UPDATE `tb_transaksi`
                    SET note = REPLACE(note, '[GAME-API-FAIL', '[GAME-API-RECOVERED')
                    WHERE cuid = '" . (int)$trx['cuid'] . "'");
                continue;
            }

            $res = $WL->deposit($users, (int)$amount, $agentSign);
            if (isset($res['status']) && $res['status'] == 1) {
                mysqli_query($conn, "UPDATE `tb_transaksi`
                    SET note = REPLACE(note, '[GAME-API-FAIL', '[GAME-API-RECOVERED')
                    WHERE cuid = '" . (int)$trx['cuid'] . "'");
            }
        }
    }
}

// 5. Saldo final
$final_balance = $localBalance;
if ($api_connected && $apiBalance !== null) {
    if ($pendingGameSync) {
        $final_balance = max($apiBalance, $localBalance);
    } else {
        $final_balance = $apiBalance; // sinkron penuh aman (naik/turun sah)
    }
}

// 6. Sinkronisasi ke tb_balance
$checkExist = mysqli_query($conn, "SELECT userID FROM `tb_balance` WHERE userID = '$userID'");
if (mysqli_num_rows($checkExist) > 0) {
    mysqli_query($conn, "UPDATE tb_balance SET active = '$final_balance' WHERE userID = '$userID'");
} else {
    mysqli_query($conn, "INSERT INTO `tb_balance` (`userID`, `active`, `pending`, `transfer`, `payout`, `created_date`) VALUES ('$userID', '$final_balance', 0, 0, 0, NOW())");
}

echo number_format($final_balance, 0, ',', '.');
exit();
