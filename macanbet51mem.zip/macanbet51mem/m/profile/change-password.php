<?php
session_start();
include('../../config/koneksi.php');

if (!isset($_SESSION['user'])) {
    header("Location: ../");
    exit;
}

include "../header.php";
?>

<div class="container mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            Ubah Kata Sandi
        </div>
        <div class="card-body">
            <form action="password.php" method="POST">
                <input type="hidden" name="user_id" value="<?php echo $_SESSION['user']; ?>">

                <div class="form-group">
                    <label>Kata Sandi Saat Ini</label>
                    <input type="password" class="form-control" name="current_password" required>
                </div>

                <div class="form-group">
                    <label>Kata Sandi Baru</label>
                    <input type="password" class="form-control" name="new_password" required>
                </div>

                <div class="form-group">
                    <label>Konfirmasi Kata Sandi Baru</label>
                    <input type="password" class="form-control" name="confirm_password" required>
                </div>

                <button type="submit" class="btn btn-success btn-block">
                    Ubah Kata Sandi
                </button>
            </form>
        </div>
    </div>
</div>

<?php include "../footer.php"; ?>