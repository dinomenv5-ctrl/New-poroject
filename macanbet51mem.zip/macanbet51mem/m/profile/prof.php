<?php
header("Location: profile/change-password.php");
exit;