<?php
ob_start();
session_start();
date_default_timezone_set('Asia/Jakarta');
require_once '../../config/koneksi.php';

if (empty($_SESSION['user'])) { header('Location: ../index'); exit; }

$username = (string)$_SESSION['user'];
$stmt = $conn->prepare('SELECT cuid, username, email, full_name, status_kyc FROM tb_user WHERE username=? LIMIT 1');
$stmt->bind_param('s',$username); $stmt->execute();
$stmt->bind_result($userID,$users,$emailDb,$fullNameDb,$statusKyc);
if (!$stmt->fetch()) { $stmt->close(); session_destroy(); header('Location: ../index'); exit; }
$stmt->close();

$sbs = ['no_rek'=>'','pemilik'=>'','akun'=>''];
$stmt = $conn->prepare('SELECT no_rek,pemilik,akun FROM tb_bank WHERE userID=? LIMIT 1');
if ($stmt) { $stmt->bind_param('i',$userID); $stmt->execute(); $stmt->bind_result($nr,$pm,$ak); if($stmt->fetch()){$sbs=['no_rek'=>$nr,'pemilik'=>$pm,'akun'=>$ak];} $stmt->close(); }

if (empty($_SESSION['kyc_csrf'])) { $_SESSION['kyc_csrf']=bin2hex(random_bytes(24)); }
$notification=''; $notificationType='info'; $form_display=true;
$stmt=$conn->prepare('SELECT status FROM tb_kyc WHERE user_id=? ORDER BY id DESC LIMIT 1');
if($stmt){$stmt->bind_param('i',$userID);$stmt->execute();$stmt->bind_result($kycStatus);if($stmt->fetch()){$form_display=false;$notification=$kycStatus==='approved'?'KYC Anda sudah disetujui.':'Data KYC sudah dikirim dan sedang diperiksa.';}$stmt->close();}

if($_SERVER['REQUEST_METHOD']==='POST' && $form_display){
 $csrf=(string)($_POST['csrf_token']??''); $email=trim((string)($_POST['email']??'')); $bankName=trim((string)($_POST['bank_name']??'')); $name=trim((string)($_POST['name']??'')); $terms=isset($_POST['terms'])?1:0; $file=$_FILES['user_identification']??null;
 if(!hash_equals($_SESSION['kyc_csrf'],$csrf)){$notification='Sesi formulir berakhir. Muat ulang halaman.';$notificationType='danger';}
 elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)||$bankName===''||$name===''||!$terms||!$file){$notification='Semua kolom wajib diisi dengan benar.';$notificationType='danger';}
 elseif((int)$file['error']!==UPLOAD_ERR_OK || (int)$file['size']<1 || (int)$file['size']>2097152){$notification='Upload gagal atau ukuran file melebihi 2 MB.';$notificationType='danger';}
 else{
  $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($file['tmp_name']); $allowed=['image/jpeg'=>'jpg','image/png'=>'png','application/pdf'=>'pdf'];
  if(!isset($allowed[$mime])){$notification='File harus JPG, PNG, atau PDF.';$notificationType='danger';}
  else{
   $dir=dirname(__DIR__,2).'/uploads/kyc'; if(!is_dir($dir))@mkdir($dir,0755,true);
   $filename='kyc_'.$userID.'_'.date('YmdHis').'_'.bin2hex(random_bytes(4)).'.'.$allowed[$mime]; $dest=$dir.'/'.$filename;
   if(!is_dir($dir)||!is_writable($dir)||!move_uploaded_file($file['tmp_name'],$dest)){$notification='Folder upload tidak dapat ditulis. Pastikan uploads/kyc permission 755 atau 775.';$notificationType='danger';}
   else{
    $method=5; $status='pending';
    $stmt=$conn->prepare('INSERT INTO tb_kyc (user_id,username,email,bank_name,name,user_identification,method,terms,status) VALUES (?,?,?,?,?,?,?,?,?)');
    if($stmt){$stmt->bind_param('isssssiis',$userID,$users,$email,$bankName,$name,$filename,$method,$terms,$status); if($stmt->execute()){$notification='KYC berhasil dikirim. Silakan tunggu pemeriksaan admin.';$notificationType='success';$form_display=false;$up=$conn->prepare('UPDATE tb_user SET status_kyc=0 WHERE cuid=?');if($up){$up->bind_param('i',$userID);$up->execute();$up->close();}}else{$notification='Data gagal disimpan.';$notificationType='danger';@unlink($dest);} $stmt->close();}
    else{$notification='Struktur tabel KYC belum diperbarui. Import SQL perbaikan terlebih dahulu.';$notificationType='danger';@unlink($dest);}
   }
  }
 }
}
include '../header.php';
?>
<style>.kyc-wrap{padding:16px 14px 120px;color:#fff}.kyc-card{max-width:760px;margin:auto;background:#111;border:1px solid #3a3320;border-radius:14px;padding:18px}.kyc-card .form-control{background:#171717!important;color:#f1d765!important;-webkit-text-fill-color:#f1d765!important;border:1px solid #d4bd58!important}.kyc-card label{color:#e7d47b}.kyc-card h2{font-size:20px}.kyc-actions{display:flex;gap:10px;justify-content:flex-end}.kyc-step2{display:none}</style>
<div class="kyc-wrap"><div class="kyc-card"><h3>Formulir Aktivasi Kode Referral</h3>
<?php if($notification!==''):?><div class="alert alert-<?=htmlspecialchars($notificationType)?>"><?=htmlspecialchars($notification)?></div><?php endif;?>
<?php if($form_display):?><form method="post" enctype="multipart/form-data" id="kycForm"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['kyc_csrf'])?>">
<div id="step1"><div class="form-group"><label>Alamat email *</label><input class="form-control" type="email" name="email" id="email" value="<?=htmlspecialchars($emailDb)?>" required></div>
<div class="form-group"><label>Bank *</label><select class="form-control" name="bank_name" id="bank_name" required><option value="">- Silakan pilih -</option><?php if($sbs['no_rek']!==''):?><option value="<?=htmlspecialchars($sbs['no_rek'])?>"><?=htmlspecialchars($sbs['akun'])?> - XXXX<?=htmlspecialchars(substr($sbs['no_rek'],-4))?></option><?php endif;?></select></div>
<div class="form-group"><label>Nama Sesuai Rekening *</label><input class="form-control" name="name" id="name" value="<?=htmlspecialchars($fullNameDb)?>" readonly required></div>
<div class="form-group"><label>ID CARD (KTP / SIM / PASPOR) *</label><input class="form-control" type="file" name="user_identification" id="identity" accept=".jpg,.jpeg,.png,.pdf" required><small>Maksimal 2 MB.</small></div>
<div class="kyc-actions"><button type="button" class="btn btn-primary" id="nextBtn">Lanjut</button></div></div>
<div id="step2" class="kyc-step2"><h2>Syarat dan Ketentuan Referral</h2><ul><li>Data yang diberikan harus benar.</li><li>Dilarang melakukan phishing atau promosi yang merugikan pihak lain.</li><li>Pelanggaran dapat menyebabkan akun ditutup.</li></ul><label><input type="checkbox" name="terms" id="terms" value="1" required> Saya menyetujui ketentuan di atas.</label><div class="kyc-actions"><button type="button" class="btn btn-secondary" id="backBtn">Kembali</button><button type="submit" class="btn btn-primary">Kirimkan</button></div></div></form><?php endif;?></div></div>
<script>document.getElementById('nextBtn')?.addEventListener('click',function(){const ids=['email','bank_name','name','identity'];for(const id of ids){const e=document.getElementById(id);if(!e||!e.checkValidity()){e?.reportValidity();return;}}document.getElementById('step1').style.display='none';document.getElementById('step2').style.display='block';});document.getElementById('backBtn')?.addEventListener('click',function(){document.getElementById('step2').style.display='none';document.getElementById('step1').style.display='block';});</script>
<?php include '../footer.php'; ?>
