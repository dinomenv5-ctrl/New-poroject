<!DOCTYPE html>  <html lang="id-ID">  <head>  
<?php
      // SELALU include url_helper.php di awal supaya site_url() terdefinisi
      // (mencegah Fatal Error: Call to undefined function site_url() -> HTTP 500)
      if (!function_exists('site_url')) {
          include(__DIR__ . '/../config/url_helper.php');
      }
      // Pastikan data SEO (logo, dll) tersedia dari tb_seo
      if (!isset($s0) || empty($s0)) {
          $sql_seo_header = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1 LIMIT 1");
          if ($sql_seo_header) {
              $s0 = mysqli_fetch_array($sql_seo_header);
          }
      }
      // Selalu pastikan $urlweb terisi (pakai site_url/get_active_base_url bila kosong)
      if (!isset($urlweb) || empty($urlweb)) {
          $urlweb = function_exists('get_active_base_url') ? get_active_base_url() : (isset($s0['urlweb']) ? $s0['urlweb'] : '');
      }
      $sql_chat = mysqli_query($conn,"SELECT * FROM `tb_livechat` WHERE cuid = 1") or die(mysqli_error());
  $sc = mysqli_fetch_array($sql_chat);  
            $sql = "SELECT * FROM tb_social";  
            $result = $conn->query($sql);  

            // Menampilkan hasil query  
            if ($result->num_rows > 0) {  
                while($row = $result->fetch_assoc()) {  
                    $wa = $row['wa'];     
                    $tele = $row['tele'];   
                    $fb = $row['facebook'];  
                    $ig = $row['instagram'];  
                }  
            } else {  
                echo "Tidak ada data WhatsApp ditemukan";  
            }     
        ?>  
        <?php

$sql = "SELECT status FROM maintenance WHERE id = 3";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
$row = $result->fetch_assoc();
$status = $row["status"];

if ($status == 1) {  
    // Mengarahkan pengguna kembali ke halaman sebelumnya  
    header("Location: /mt.php");  
    exit();  
} else {  
    // Tindakan lain jika status bukan 1  
}

} else {
// Tindakan lain jika tidak ada hasil dari query
}
?>
<title><?php echo $s0['instansi']; ?></title>
<meta name="description" content="<?php echo $s0['deskripsi']; ?>">
<meta name="keywords" content="<?php echo $s0['keyword']; ?>">
<meta property="og:title" content="<?php echo $s0['instansi']; ?>" />
<meta property="og:description" content="<?php echo $s0['deskripsi']; ?>" />
<meta property="og:url" content="<?php echo $urlweb; ?>" />
<meta property="og:image" content="<?php echo $urlweb; ?>/upload/<?php echo $s0['image']; ?>" />
<meta name="resource-type" content="document" />
<meta http-equiv="content-type" content="text/html; charset=US-ASCII" />
<meta http-equiv="content-language" content="en-us" />
<meta name="author" content="<?php echo $urlweb; ?>" />
<meta name="contact" content="<?php echo $urlweb; ?>" />
<meta name="copyright" content="Copyright (c) <?php echo $urlweb; ?>. All Rights Reserved." />
<meta name="robots" content="index, follow">
<meta property="og:image" content="<?php echo $s0['image']; ?>">
<meta name="google-site-verification" content="<?php echo $s0['meta'];?>" />

<meta name="viewport" content="width=device-width,initial-scale=1, maximum-scale=1, user-scalable=no">  
    <meta name="author" content="<?php echo $s0['instansi']; ?>">  
<meta name="robots" content="index, no follow">  
<link rel="canonical" href="<?php echo $urlweb; ?>">  
<meta property="og:type" content="website">  
<meta name="revisit-after" content="1 days">  
<link rel="icon" type="image/png" href="https://lordgopal.xyz/img/fav-icon-upin33.png">  

<script>  
    ! function (f, b, e, v, n, t, s) {  
        if (f.fbq) return;  
        n = f.fbq = function () {  
            n.callMethod ?  
                n.callMethod.apply(n, arguments) : n.queue.push(arguments)  
        };  
        if (!f._fbq) f._fbq = n;  
        n.push = n;  
        n.loaded = !0;  
        n.version = '2.0';  
        n.queue = [];  
        t = b.createElement(e);  
        t.async = !0;  
        t.src = v;  
        s = b.getElementsByTagName(e)[0];  
        s.parentNode.insertBefore(t, s)  
    }(window, document, 'script',  
        'https://connect.facebook.net/en_US/fbevents.js');  
    fbq('init', '1008275913534968');  
    fbq('track', 'PageView');  
</script>  
<noscript><img height="1" width="1" style="display:none"  
        src="https://www.facebook.com/tr?id=1008275913534968&ev=PageView&noscript=1" /></noscript>  

<meta charset="utf-8">  

<meta name="csrf-token" content="Ohsf8q2CXEI97FMGjTPzKL6QKvW8nrMQiuOtxJui">  

<script src="https://cdn.sitestatic.net/assets/jquery/jquery.min.js"></script>  
<script src="https://cdn.sitestatic.net/assets/bootstrap/bootstrap.min.js"></script>  

<link rel="preload" href="/fonts/ugsports/icomoon/fonts/icomoon.woff2?fx18yi" as="font"  
    type="font/woff2" crossorigin="anonymous">  
<link rel="stylesheet" href="/fonts/ugsports/icomoon/style.min.css" media="print" onload="this.media='all'">  

<link rel="stylesheet" href="<?php echo $urlweb; ?>/css/ugsports/swiper.css" />  

<?php  
    $query = "SELECT * FROM tb_theme WHERE status = '1'";  
    $result = $conn->query($query);  

    if ($result->num_rows > 0) {  
        $row = $result->fetch_assoc();  
        $tema =$row['path'];              
    } else {  
        echo "No active theme found";  
    }  
?>  

<link type="text/css" rel="stylesheet" href="<?php echo $urlweb; ?>/css/ugsports/theme-20/m/<?php echo $tema; ?>">  
<script src="https://cdn.sitestatic.net/assets/jquery/sweet_alert2.min.js"></script>  


<link rel="stylesheet" href="https://cdn.sitestatic.net/assets/jquery/jquery-ui.min.css" media="print"  
    onload="this.media='all'">  
<script src="https://cdn.sitestatic.net/assets/jquery/jquery-ui.min.js" defer></script>  
<script type="text/javascript" src="https://cdn.sitestatic.net/assets/jquery/jquery.ui.touch-punch.min.js" defer>  
</script>

<script>  
    // Fungsi untuk menampilkan SweetAlert2  
    function registerPopup(options) {  
      Swal.fire({  
        title: 'Game Sedang Maintenance',  
        text: options.content,  
        icon: 'error',  
        confirmButtonText: 'Tutup'  
      });  
    }  
  </script>  <script>  
function callBackgroundPage() {  
    var url = "/getBal.php";  
    var xhr = new XMLHttpRequest();  
    xhr.open("GET", url, true);  
    xhr.onreadystatechange = function() {  
        if (xhr.readyState === 4 && xhr.status === 200) {  
             
        }  
    };  
    xhr.send();  
}  
callBackgroundPage();  
</script>  <body class="mobile">  
    <div class="full-container layout">  
        <div id="sideNav" class="side-nav">  
            <?php  
            if(isset($_SESSION['user'])){  
            $user =mysqli_query($conn,"SELECT * FROM `tb_user` WHERE username = '".$_SESSION['user']."'") or die (mysqli_error());  
            $u = mysqli_fetch_array($user);  
            $users = $u['username'];  
            $userid = $u['username'];  
            $id_user = $u['cuid'];  
            $userID = $u['cuid'];  
            $token_id = isset($u['token_id']) ? $u['token_id'] : false;  
            $level = isset($u['level']) ? $u['level'] : false;  
            $sql_balance = mysqli_query($conn,"SELECT * FROM `tb_balance` WHERE userID = '$userID'") or die(mysqli_error());  
            $sb = mysqli_fetch_array($sql_balance);  
            $sql_bank = mysqli_query($conn,"SELECT * FROM `tb_bank` WHERE userID = '$userID'") or die(mysqli_error());  
            $sbk = mysqli_fetch_array($sql_bank);  
        ?>  
            <nav class="nav-content">  
                <ul class="side-nav-items">  
                    <li class="nav-item">  
                        <a class="navlink" href="<?php echo site_url('m'); ?>" onclick="closeNav(-1);">  
                            <div><i class="icon-home"></i></div>  
                            <!--routerLinkActiveOptions for root URL-->  
                            <div class="nav-title" i18n="@HOME">HOME</div>  
                        </a>  
                    </li>  
                    <li class="nav-item">  
                        <a href="javascript:void(0);" class="navlink has-sub" onclick="openNavItem(0);"  
                            [ngclass]="{'active':isOpenNavContent[0], '':   !isOpenNavContent[0]}">  
                            <div><i class="icon-coins"></i></div>  
                            <div class="nav-title" i18n="@Funds">Dana</div>  
                        </a>  
                        <div class="nav-item-content" [ngclass]="{'open':isOpenNavContent[0], '':!isOpenNavContent[0]}">  
                            <ul class="submenu account">  
                                <li>  
                                    <a href="<?php echo site_url('m/account/deposit'); ?>" (click)="closeNav($event);">  
                                        <div><span class="circle"><i class="icon-pig"></i></span></div>  
                                        <div class="fs-sm mt-1" i18n="">Deposit</div>  
                                    </a>  
                                </li>  
                                <li>  
                                    <a href="<?php echo site_url('m/account/withdrawal'); ?>" (click)="closeNav($event);">  
                                        <div><span class="circle"><i class="icon-transfer"></i></span></div>  
                                        <div class="fs-sm mt-1" i18n="">Withdraw</div>  
                                    </a>  
                                </li>  
                                <li>  
                                    <a href="<?php echo site_url('m/account/history'); ?>" (click)="closeNav($event);">  
                                        <div><span class="circle"><i class="icon-history"></i></span></div>  
                                        <div class="fs-sm mt-1" i18n="@History">Pernyataan &nbsp;</div>  
                                    </a>  
                                </li>  
                                <li>  
                                    <a href="<?php echo site_url('m/referral-downline'); ?>" (click)="closeNav($event);">  
                                        <div><span class="circle"><i class="icon-users"></i></span></div>  
                                        <div class="fs-sm mt-1" i18n="">Referral &nbsp;</div>  
                                    </a>  
                                </li>  </ul>  
                    </div>  
                </li>  

                <li class="nav-item">  
                    <a href="javascript:void(0);" class="navlink has-sub" onclick="openNavItem(1);"  
                        [ngclass]="{'active':isOpenNavContent[1], '':   !isOpenNavContent[1]}">  
                        <div><i class="icon-videogame_asset"></i></div>  
                        <div class="nav-title" i18n="">PERMAINAN</div>  
                    </a>  
                    <div class="nav-item-content games"  
                        [ngclass]="{'open':isOpenNavContent[1], '':!isOpenNavContent[1]}">  
                        <ul class="submenu">  
                            <!-- <i class="icon-lottery"></i>  
              <i  class="icon-others"></i>    -->  

                            <li> <a href="<?php echo site_url('m/slots/'); ?>" (click)="closeNav(-1);">  
                                    <div class="">  
                                        <span class="circle">  
                                            <i class="icon-slot"></i>  

                                        </span>  
                                        <span class="hot sub" style="">HOT</span>  
                                    </div>  
                                    <div class="fs-sm mt-1">SLOTS</div>  
                                </a>  
                            </li>  
                            <li> <a href="<?php echo site_url('m/sports/'); ?>" (click)="closeNav(-1);">  
                                    <div class="">  
                                        <span class="circle">  
                                            <i class="icon-soccer"></i>  
                                        </span>  
                                    </div>  
                                    <div class="fs-sm mt-1">SPORTS</div>  
                                </a>  
                            </li>  
                            <li> <a href="<?php echo site_url('m/casino/'); ?>" (click)="closeNav(-1);">  
                                    <div class="">  
                                        <span class="circle">  
                                            <i class="icon-casino"></i>  
                                        </span>  
                                    </div>  
                                    <div class="fs-sm mt-1">CASINO</div>  
                                </a>  
                            </li>  
                            <li> <a href="<?php echo site_url('m/poker/'); ?>" (click)="closeNav(-1);">  
                                    <div class="">  
                                        <span class="circle">  
                                            <i class="icon-menu-poker-01"></i>  
                                        </span>  
                                    </div>  
                                    <div class="fs-sm mt-1">P2P</div>  
                                </a>  
                            </li>  
                            <li>  
                                <a href="<?php echo site_url('m/lottery/'); ?>" (click)="closeNav(-1);">  
                                    <div class="">  
                                        <span class="circle">  
                                            <i class="icon-lottery"></i>  

                                        </span>  
                                        <span class="hot sub new ">NEW</span>  
                                    </div>  
                                    <div class="fs-sm mt-1">LOTRE</div>  
                                </a>  
                            </li>  
                            <li>  
                                <a href="<?php echo site_url('m/fish-hunter/'); ?>">  
                                    <div class="">  
                                        <span class="circle">  
                                            <i class="icon-fish_hunter"></i>  
                                        </span>  
                                    </div>  
                                    <div class="fs-sm mt-1">TEMBAK IKAN</div>  
                                </a>  
                            </li>  
                            <li> <a href="<?php echo site_url('m/e-games/'); ?>" (click)="closeNav(-1);">  
                                    <div class="">  
                                        <span class="circle">  
                                            <i class="icon-others"></i>  
                                        </span>  
                                    </div>  
                                    <div class="fs-sm mt-1">E-GAMES</div>  
                                </a>  
                            </li>  
                            <li> <a href="<?php echo site_url('m/cockfight/'); ?>" (click)="closeNav(-1);">  
                                    <div class="">  
                                        <span class="circle">  
                                            <i class="icon-cockfight"></i>  
                                        </span>  
                                    </div>  
                                    <div class="fs-sm mt-1">SABUNG AYAM</div>  
                                </a>  
                            </li>  


                        </ul>  
                    </div>  
                </li>  

                <li class="nav-item">  

                    <a class="navlink" href="<?php echo site_url('m/promotion/'); ?>" onclick="closeNav(-1);">  
                        <div><i class="icon-gift"></i></div>  
                        <!--routerLinkActiveOptions for root URL-->  
                        <div class="nav-title" i18n="@PROMOS">PROMOSI</div>  
                    </a>  
                </li>  

                <li class="nav-item">  

                    <a class="navlink" href="<?php echo site_url('m/referral'); ?>" onclick="closeNav(-1);">  
                        <div><i class="icon-users"></i></div>  
                        <!--routerLinkActiveOptions for root URL-->  
                        <div class="nav-title" i18n="@REFERRAL">REFERRAL</div>  
                    </a>  

                </li>  



                <li class="nav-item">  

                    <a class="navlink" href="<?php echo site_url('m/info'); ?>" onclick="closeNav(-1);">  
                        <div><i class="icon-info"></i></div>  
                        <!--routerLinkActiveOptions for root URL-->  
                        <div class="nav-title" i18n="@INFO">INFO</div>  
                    </a>  

                </li>  
                <li class="nav-item">  
                    <a class="navlink" href="<?php echo site_url('m/contact-us'); ?>" onclick="closeNav(-1);">  
                        <div><i class="icon-address-book"></i></div>  
                        <!--routerLinkActiveOptions for root URL-->  
                        <div class="nav-title" i18n="">HUBUNGI KAMI</div>  
                    </a>  
                </li>  
                <li class="nav-item">  
                    <a href="javascript:void(0);" class="navlink" onclick="closeNav();" data-trigger="nifty"  
                        data-target="#langModal-mobile">  
                        <div><i class="icon-language"></i></div>  
                        Bahasa  
                    </a>  
                </li>  
                <li class="nav-item">  
                    <a class="navlink" href="<?php echo $urlweb; ?>desktop" onclick="closeNav(-1);">  
                        <div><i class="icon-display"></i></div>  
                        <!--routerLinkActiveOptions for root URL-->  
                        <div class="nav-title">Desktop View</div>  
                    </a>  
                </li>  
                <li class="nav-item"><a href="javascript:void(0);" class="navlink" onclick="closeNav();"> <i  
                            class="icon-double_arrow_l"></i></a></li>  
                <?php }else{ ?>  
                <nav class="nav-content">  
                    <ul class="side-nav-items">  
                        <li class="nav-item">  
                            <a class="navlink" href="<?php echo site_url(''); ?>" onclick="closeNav(-1);">  
                                <div><i class="icon-home"></i></div>  
                                <!--routerLinkActiveOptions for root URL-->  
                                <div class="nav-title" i18n="@HOME">HOME</div>  
                            </a>  
                        </li>  
                        <li class="nav-item">  
                            <a href="javascript:void(0);" class="navlink has-sub" onclick="openNavItem(0);"  
                                [ngClass]="{'active':isOpenNavContent[1], '':   !isOpenNavContent[1]}">  
                                <div><i class="icon-videogame_asset"></i></div>  
                                <div class="nav-title" i18n>PERMAINAN</div>  
                            </a>  
                            <div class="nav-item-content games"  
                                [ngClass]="{'open':isOpenNavContent[1], '':!isOpenNavContent[1]}">  
                                <ul class="submenu">  
                                    <li> <a href="<?php echo site_url('m/slots/'); ?>" (click)="closeNav(-1);">  
                                            <div class="">  
                                                <span class="circle">  
                                                    <i class="icon-slot"></i>  

                                                </span>  
                                                <span class='hot sub' style="">HOT</span>  
                                            </div>  
                                            <div class="fs-sm mt-1">SLOTS</div>  
                                        </a>  
                                    </li>  
                                    <li> <a href="<?php echo site_url('m/sports/'); ?>" (click)="closeNav(-1);">  
                                            <div class="">  
                                                <span class="circle">  
                                                    <i class="icon-soccer"></i>  
                                                </span>  
                                            </div>  
                                            <div class="fs-sm mt-1">SPORTS</div>  
                                        </a>  
                                    </li>  
                                    <li> <a href="<?php echo site_url('m/casino/'); ?>" (click)="closeNav(-1);">  
                                            <div class="">  
                                                <span class="circle">  
                                                    <i class="icon-casino"></i>  
                                                </span>  
                                            </div>  
                                            <div class="fs-sm mt-1">CASINO</div>  
                                        </a>  
                                    </li>  
                                    <li> <a href="<?php echo site_url('m/poker/'); ?>" (click)="closeNav(-1);">  
                                            <div class="">  
                                                <span class="circle">  
                                                    <i class="icon-menu-poker-01"></i>  
                                                </span>  
                                            </div>  
                                            <div class="fs-sm mt-1">P2P</div>  
                                        </a>  
                                    </li>  
                                    <li>  
                                        <a href="<?php echo site_url('m/lottery/'); ?>" (click)="closeNav(-1);">  
                                            <div class="">  
                                                <span class="circle">  
                                                    <i class="icon-lottery"></i>  

                                                </span>  
                                                <span class="hot sub new ">NEW</span>  
                                            </div>  
                                            <div class="fs-sm mt-1">LOTRE</div>  
                                        </a>  
                                    </li>  
                                    <li>  
                                        <a href="<?php echo site_url('m/fish-hunter/'); ?>" (click)="closeNav(-1);">  
                                            <div class="">  
                                                <span class="circle">  
                                                    <i class="icon-fish_hunter/"></i>  
                                                </span>  
                                            </div>  
                                            <div class="fs-sm mt-1">TEMBAK IKAN</div>  
                                        </a>  
                                    </li>  
                                    <li> <a href="<?php echo site_url('m/e-games/'); ?>" (click)="closeNav(-1);">  
                                            <div class="">  
                                                <span class="circle">  
                                                    <i class="icon-others"></i>  
                                                </span>  
                                            </div>  
                                            <div class="fs-sm mt-1">E-GAMES</div>  
                                        </a>  
                                    </li>  
                                    <li> <a href="<?php echo site_url('m/cockfight/'); ?>" (click)="closeNav(-1);">  
                                            <div class="">  
                                                <span class="circle">  
                                                    <i class="icon-cockfight"></i>  
                                                </span>  
                                            </div>  
                                            <div class="fs-sm mt-1">SABUNG AYAM</div>  
                                        </a>  
                                    </li>  


                                </ul>  
                            </div>  
                        </li>  

                        <li class="nav-item">  

                            <a class="navlink" href="<?php echo site_url('m/promotion/'); ?>" onclick="closeNav(-1);">  
                                <div><i class="icon-gift"></i></div>  
                                <!--routerLinkActiveOptions for root URL-->  
                                <div class="nav-title" i18n="@PROMOS">PROMOSI</div>  
                            </a>  
                        </li>  

                        <li class="nav-item">  

                            <a class="navlink" href="<?php echo site_url('m/referral'); ?>/" onclick="closeNav(-1);">  
                                <div><i class="icon-users"></i></div>  
                                <!--routerLinkActiveOptions for root URL-->  
                                <div class="nav-title" i18n="@REFERRAL">REFERRAL</div>  
                            </a>  

                        </li>  
                        <li class="nav-item">  

                            <a class="navlink" href="<?php echo site_url('m/info'); ?>" onclick="closeNav(-1);">  
                                <div><i class="icon-info"></i></div>  
                                <!--routerLinkActiveOptions for root URL-->  
                                <div class="nav-title" i18n="@INFO">INFO</div>  
                            </a>  

                        </li>  
                        <li class="nav-item">  
                            <a class="navlink" href="<?php echo site_url('m/contact-us'); ?>" onclick="closeNav(-1);">  
                                <div><i class="icon-address-book"></i></div>  
                                <!--routerLinkActiveOptions for root URL-->  
                                <div class="nav-title" i18n>HUBUNGI KAMI</div>  
                            </a>  
                        </li>  
                        <li class="nav-item">  
                            <a href="javascript:void(0);" class="navlink" onclick="closeNav();" data-trigger='nifty'  
                                data-target='#langModal-mobile'>  
                                <div><i class="icon-language"></i></div>  
                                Bahasa  
                            </a>  
                        </li>  
                        <li class="nav-item">  
                            <a class="navlink" href="<?php echo site_url('desktop'); ?>"  
                                onclick="closeNav(-1);">  
                                <div><i class="icon-display"></i></div>  
                                <!--routerLinkActiveOptions for root URL-->  
                                <div class="nav-title">Desktop View</div>  
                            </a>  
                        </li>  
                        <li class="nav-item"><a href="javascript:void(0);" class="navlink" onclick="closeNav();"> <i  
                                    class="icon-double_arrow_l"></i></a></li>  
                    </ul>  
                    <?php }?>  
                </nav>  
                <script>  
                    var arr = [0, 0];  

                    function openNavItem(index) {  
                        $('.nav-item-content').removeClass('open');  
                        $('.navlink.has-sub').removeClass('active');  
                        if (index >= 0) {  
                            $('.nav-item-content').eq(index).addClass('open');  
                            $('.navlink.has-sub').eq(index).addClass('active');  
                            $("#mainContent").addClass("navContentOpen");  
                            $("#sideNav").addClass("navContentOpen");  
                        }  
                    }  

                    function closeNav() {  
                        $('.nav-item-content').removeClass('open');  
                        $('.navlink.has-sub').removeClass('active');  

                        $("#sideNav").removeClass("navContentOpen");  
                        $("#sideNav").removeClass("open");  
                        $("#mainContent").removeClass("navContentOpen");  
                        $("#mainContent").removeClass("sideNavOpen");  

                    }  
                </script>  
    </div>  
    <div class="main-content" id="mainContent">  
        <div class="backdrop" id="mainContentContainer">  
            <div class="top-bar">  
                <div class="inner-header flex-row ">  

                    <button id="btnToggleSideNav" class="btn btn-link">  
                        <i class="icon-bars"></i>  
                    </button>  
                    <a href="<?php echo $urlweb; ?>" class="logo">  
<div>  
    <img class="img-fluid"  
         alt="<?php echo isset($s0['instansi']) ? htmlspecialchars($s0['instansi']) : 'Logo'; ?>"  
         src="<?php echo htmlspecialchars(isset($s0['image']) ? $s0['image'] : ''); ?>"  
         style="height:65px; position:relative; top:-13px; object-fit:contain; display:block;">  
</div>

</a>  <a id="btnToggleRSideNav">  
                        <i class="icon-user-o"></i>  
                    </a>  
                </div>  
            </div>  
            <div class="content my01">  
            <?php  
                if(isset($_SESSION['user'])){  
                $user =mysqli_query($conn,"SELECT * FROM `tb_user` WHERE username = '".$_SESSION['user']."'") or die (mysqli_error());  
                $u = mysqli_fetch_array($user);  
                $users = $u['username'];  
                $userid = $u['username'];  
                $id_user = $u['cuid'];  
                $userID = $u['cuid'];  
                $token_id = isset($u['token_id']) ? $u['token_id'] : false;  
                $level = isset($u['level']) ? $u['level'] : false;  
                $sql_balance = mysqli_query($conn,"SELECT * FROM `tb_balance` WHERE userID = '$userID'") or die(mysqli_error());  
                $sb = mysqli_fetch_array($sql_balance);  
            ?>  
                <!-- Letakkan kode tombol refresh dalam elemen HTML -->

<div class="container wallet-bal">  
    <div class="row text-left">  
        <div class="col-xs-6">  
            <!-- Tombol refresh dengan class btn-refresh-wallet -->  
            <button class="btn btn-clear btn-refresh-wallet">  
                <i class="icon-currency-dollar fs-lg i-dollar"></i>  
                &nbsp;&nbsp;  
                <!-- Gunakan class balance-txt untuk menampilkan saldo -->  
                <span class="balance-txt">IDR <?php echo number_format((float)$sb['active'], 2, ',', '.'); ?></span>  
            </button>  
        </div>  
        <div class="col-xs-6 noSidePadding i-refresh">  
            <!-- Tombol refresh -->  
            <button class="btn btn-clear btn-refresh-wallet pull-right"><i class="icon-refresh-2"></i></button>  
        </div>  
    </div>  
    <div class="row game-bals" id="other-game-bals" style="display:none;">  
    </div>  
</div>  <!-- Tambahkan jQuery untuk melakukan panggilan AJAX -->  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>  <script>  
$(document).ready(function() {  
    function loadBalance(isManual = false) {  
        $.ajax({  
            url: '/getBal.php',  
            type: 'GET',  
            success: function(data) {  
                $('.balance-txt').text('IDR ' + data);  
                  
                // Jika dipicu oleh klik tombol (manual), tampilkan modal sukses  
                if (isManual) {  
                    Swal.fire({  
                        icon: 'success',  
                        title: 'Saldo Diperbarui',  
                        text: 'Saldo Anda telah berhasil disinkronkan dengan provider.',  
                        timer: 1500,  
                        showConfirmButton: false  
                    });  
                }  
            },  
            error: function(xhr, status, error) {  
                Swal.fire({  
                    icon: 'error',  
                    title: 'Gagal',  
                    text: 'Terjadi kesalahan saat memperbarui saldo.'  
                });  
            }  
        });  
    }  
  
    // Muat otomatis saat halaman dibuka (tanpa modal)  
    loadBalance(false);  
  
    // Muat manual saat tombol diklik (dengan modal sukses)  
    $('.btn-refresh-wallet').click(function(e) {  
        e.preventDefault();  
        loadBalance(true);  
    });  
});  
</script>  <script>  
function getQueryParams() {  
    var params = {};  
    var queryString = window.location.search.substring(1);  
    var regex = /([^&=]+)=([^&]*)/g;  
    var match;  
    while (match = regex.exec(queryString)) {  
        params[decodeURIComponent(match[1])] = decodeURIComponent(match[2]);  
    }  
    return params;  
}  
  
function displayErrorNotification() {  
    var params = getQueryParams();  
    if (params.error) {  
        var errorMessage = '';  
  
        switch (params.error) {  
            case 'not_logged_in':  
                errorMessage = 'Anda harus login terlebih dahulu.';  
                break;  
            case 'invalid_amount':  
                errorMessage = 'Jumlah yang dimasukkan tidak valid.';  
                break;  
            case 'transaction_creation_failed':  
                errorMessage = 'Gagal membuat transaksi. Silakan coba lagi.';  
                break;  
            case 'invoice_creation_failed':  
                errorMessage = 'Gagal membuat invoice. Silakan coba lagi.';  
                break;  
            case 'user_not_found':  
                errorMessage = 'User tidak ditemukan.';  
                break;  
            case 'missing_data':  
                errorMessage = 'Data yang diperlukan tidak lengkap.';  
                break;  
            default:  
                errorMessage = 'Terjadi kesalahan. Silakan coba lagi.';  
        }  
  
        Swal.fire({  
            icon: 'error',  
            title: 'Error',  
            text: errorMessage,  
            confirmButtonText: 'OK'  
        });  
    }  
}  
  
// Call the function to display error notification on page load  
window.onload = displayErrorNotification;  
</script>  <?php }else{}?>