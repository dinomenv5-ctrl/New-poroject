<?php
include 'session.php';
include 'header.php';?>

<div class="container-wrapper info ">
  <div class="container container-box info-view">
    <div class="info-nav nav-icon">
      <div class="row no-gutters">
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="terms-terms_conditions.php" class="">
            <div>
              <i class="icon-clipboard"></i>
            </div>
            <div>TERMS & CONDITIONS </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-general.php" class="">

            <div> <i class="icon-help-circle"></i></div>

            <div>FAQ</div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                  <a href="how-sportsbook.php" class="">
            <div><i class="icon-list-numbered"></i> </div>
            <div>HOW TO PLAY </div>
          </a>
        </div>
         
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-referral.php" class="active">
            <div><i class="icon-clipboard1"></i></div>

            <div>REFERRAL</div>
          </a>
        </div>
                <div>
          <a href="responsiblegaming.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>Responsible Gaming</div>
          </a>
        </div>

      </div>
    </div>

<div class="border-box">
    <div class="fs-lg title">
        <?php echo $s0['instansi']; ?> Referral    </div>
    <p>
        Referral <?php echo $s0['instansi']; ?> adalah bisnis online yang memanfaatkan perkembangan pesat pemasaran online saat ini. Kami bukan yang pertama di bisnis Referral, namun kami satu-satunya yang menawarkan kemudahan proses kerjasama Referral ini.    </p>
    <div class="fs-md title">Mengapa memilih bisnis Referral <?php echo $s0['instansi']; ?>?</div>
    <p>
        Referral <?php echo $s0['instansi']; ?> menawarkan bisnis yang andal dengan prospek meningkat setiap hari, fleksibilitas dan kepercayaan adalah moto kami dalam membangun kerja sama yang erat. Bagi kami keberhasilan <?php echo $s0['instansi']; ?> adalah kesuksesan kami bersama. Dan oleh karena itu kami memastikan Anda tidak salah memilih kami sebagai mitra bisnis dengan prospek online yang tepercaya dan jelas di masa mendatang.    </p>
    <div class="fs-md title">Kami janjikan</div>
    <p>
        <?php echo $s0['instansi']; ?> akan selalu berusaha menghadirkan layanan yang cepat dan andal serta permainan berkualitas produk yang aman dan nyaman untuk dimainkan oleh anggota di seluruh dunia tidak hanya di Indonesia. Dan optimalkan layanan kami yang sangat baik dengan layanan pelanggan 24 jam online.    </p>
    <div class="fs-md title">Stabilitas dan keamanan</div>
    <p>Kami memastikan keamanan data Anda dengan tingkat keamanan tinggi yang didukung oleh teknologi terbaru. Tingkat stabilitas tinggi perusahaan adalah salah satu proses penjaminan transaksi Anda berjalan dengan lancar dan aman.</p>
    <p>&nbsp;</p>
</div>

  </div>
</div>



<script>
  $(function(){
    var pg =""; 
    var selectedMenu=  $('.navbar-nav .nav-link').filter(function(){ 
          return $(this).data("pg").toLowerCase() == pg.toLowerCase();
        }).text();
      $('#menu-select--info').text(selectedMenu);
    

    $('#navbar-toggler--info').click(function(){
        $('.info .navbar-collapse').toggleClass('show in');

    }) 
  });
</script>
            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>