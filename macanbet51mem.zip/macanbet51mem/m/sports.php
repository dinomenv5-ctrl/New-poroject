<?php
$providerCode = isset($_GET['provider']) ? $_GET['provider'] : 'af';
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');

$sid = session_id();
// Ambil data SEO
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error($conn));
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../config/url_helper.php');
}
$urlweb = get_active_base_url();

$pengguna = $s0['user'];
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d');

include "../m/header.php";

// Cek Status Maintenance
$sql_m = "SELECT status FROM maintenance WHERE id = 1";
$result_m = $conn->query($sql_m);
if ($result_m->num_rows > 0) {
    $row_m = $result_m->fetch_assoc();
    if ($row_m["status"] == 1) {
        echo "<script>alert('Halaman sedang dalam pemeliharaan. Kembali ke halaman sebelumnya.'); window.history.back();</script>";
        exit();
    }
}

/**
 * DAFTAR PERMAINAN SPORTS (ARRAY)
 * Memudahkan pengelolaan provider olahraga
 */
$sports_games = [
    [
        'name' => 'CMD 368',
        'img'  => 'https://files.sitestatic.net/GameImage/SportsProviders/mobile/normal/cmd_sport.jpg?v=1',
        'status' => 'maintenance',
        'link' => $urlweb . '/gameplay/opengame/?gamecode=2918&providercode=AF',
        'hot'  => true
    ],
    [
        'name' => 'WBET Sport',
        'img'  => 'https://files.sitestatic.net/GameImage/SportsProviders/mobile/normal/sport_wbet.png?v=1',
        'link' => $urlweb . '/gameplay/opengame/?gamecode=0&providercode=WB',
        'hot'  => true
    ],
    [
        'name' => 'SABA Sport',
        'img'  => 'https://files.sitestatic.net/GameImage/SportsProviders/mobile/normal/ibc_sport.jpg?v=2',
        'link' => $urlweb . '/gameplay/opengame/?gamecode=7499&providercode=IB',
        'hot'  => true
    ],
    [
        'name' => 'United Gaming',
        'img'  => 'https://files.sitestatic.net/GameImage/SportsProviders/mobile/normal/sport_ug.jpg?v=9',
        'link' => $urlweb . '/gameplay/opengame/?gamecode=2918&providercode=AF',
        'hot'  => true
    ],
    [
        'name' => 'BTI Sport',
        'img'  => 'https://files.sitestatic.net/GameImage/SportsProviders/mobile/normal/bti_sport.gif',
        'link' => $urlweb . '/gameplay/opengame/?gamecode=7500&providercode=WB',
        'hot'  => true
    ],
    [
        'name' => 'Pragmatic Sport',
        'img'  => 'https://files.sitestatic.net/GameImage/SportsProviders/mobile/normal/pp_virtualsport.jpg',
        'link' => $urlweb . '/gameplay/opengame/?gamecode=7499&providercode=IB',
        'hot'  => true
    ],
    [
        'name' => 'SBO',
        'img'  => 'https://files.sitestatic.net/GameImage/SportsProviders/mobile/normal/sport_sbo.jpg?v=9',
        'link' => $urlweb . '/gameplay/opengame/?gamecode=7535&providercode=S3',
        'hot'  => true
    ],
];
?>
<div class="container pt-1 games-category">
    <h2 class="title">sports</h2>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 image-grid">
            
            <?php foreach ($sports_games as $game): ?>
                <div class="col-xs-4 col-sm-3 col-md-2 box">
                    <div class="game-wrapper">
                        
                        <?php if ($game['hot']): ?>
                            <div class="hot-tag"></div>
                        <?php endif; ?>

                        <a href="<?php echo $game['link']; ?>" rel="opener" class="game" target="_blank">
                            <img class="img-fluid lazy" 
                                 alt="<?php echo $game['name']; ?>" 
                                 data-src="<?php echo $game['img']; ?>" 
                                 src="" />
                            <div class="loader-b" *ngIf="!showEle"></div>
                        </a>
                        
                    </div>
                </div>
            <?php endforeach; ?>

        </div>
    </div>
</div>

<?php include "footer.php"; ?>