<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');

$sid = session_id();
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error($conn));
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../config/url_helper.php');
}
$urlweb = get_active_base_url();
$urlwebs = $urlweb;
$pengguna = $s0['user'];
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d');
$stat = mysqli_query($conn, "INSERT INTO `tb_stat` (`ip`, `date`, `hits`, `page`, `user`) VALUES ('$ip', '$date', 1, 'Fish Hunter', '$pengguna')") or die(mysqli_error($conn));

$sql_banner = mysqli_query($conn, "SELECT * FROM `tb_banner` WHERE cuid = 1") or die(mysqli_error($conn));
$ssb = mysqli_fetch_array($sql_banner);
$status = $ssb['status'];
if ($status == true) {
    $cekPopup = mysqli_query($conn, "SELECT * FROM `tb_popup` WHERE ip = '$ip'") or die(mysqli_error($conn));
    $cpp = mysqli_num_rows($cekPopup);
    if ($cpp == 0) {
        $pop = mysqli_query($conn, "INSERT INTO `tb_popup` (`ip`, `date`, `status`) VALUES ('$ip', '$date', 0)") or die(mysqli_error($conn));
        $lihat = $status;
    } else {
        $cp = mysqli_fetch_array($cekPopup);
        $statusnya = $cp['status'];
        if ($statusnya == 0) {
            $lihat = $status;
        } else {
            $lihat = 'false';
        }
    }
} else {
    $lihat = $status;
}

include "header.php";
?>

<div class="container pt-1 games-category">
    <h2 class="title">fish hunter</h2>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 image-grid">
            <?php
            // Query mengambil provider dengan game_category 'FH' (Fish Hunter)
            $result = mysqli_query($conn, "SELECT * FROM `tb_provider` 
                                   WHERE `game_category` = 'FH' 
                                   ORDER BY FIELD(code, 'PR', 'PG', 'HB') DESC, name ASC");

            if (!$result) {
                die("Query Error: " . mysqli_error($conn));
            }

            while ($rowProvider = mysqli_fetch_assoc($result)) {
                $provider_name = strtolower(str_replace(' ', '-', trim($rowProvider["name"])));
                $provider_code = strtolower($rowProvider["code"]);
                $provider_status = $rowProvider["status"];

                // Gambar diambil dari folder prov hasil sinkronisasi
                $media_src = $urlweb . '/uploads/prov/' . $provider_name . '.jpg';

                if ($provider_status == 0) {
                    $link = 'javascript:void(0)';
                    $onclick = "onclick=\"alert('Provider sedang dalam maintenance.')\"";
                } else {
                    // Tautan ke sub-folder fish-hunter
                    $link = $urlweb . '/m/fish-hunter/game.php?provider=' . $provider_code;
                    $onclick = '';
                }

                echo '
        <div class="col-xs-4 col-sm-3 col-md-2 box">
            <div class="game-wrapper">
                <a href="' . $link . '" ' . $onclick . ' rel="opener" class="game">
                    <img class="img-fluid" alt="' . strtoupper($rowProvider["name"]) . '" src="' . $media_src . '" />
                    <div class="g-title" style="font-size: smaller;">' . strtoupper($rowProvider["name"]) . '</div>
                </a>
            </div>
        </div>';
            }
            ?>
        </div>
    </div>
</div>
<?php include "footer.php"; ?>