<?php
include 'session.php';
include 'header.php';?>

<div class="container contact-us">
    <div class="row">
      <div class="col-xs-12">
        <h1 class="mt-4">Hubungi kami</h1>
        <p class="fs-lg">Spesialis Dukungan Pelanggan tersedia setiap hari selama 24 jam.</p>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12">
        <div class="bg-1 fs-lg">
                                                                                                                                                                                                                 
              <a class="btn dis_flex" href="https://www.facebook.com/groups/<?php echo $s0['instansi']; ?>">
                <span class="icon-txt fs-xxl">
                  <i class="icon-facebook"></i>
                </span>
                <span>Facebook</span>
              </a>
           
                                                                       
              <a class="btn dis_flex" href="https://www.instagram.com/<?php echo $s0['instansi']; ?>">
                <span class="icon-txt fs-xxl">
                  <i class="icon-instagram"></i>
                </span>
                <span>Instagram</span>
              </a>
           
                                                                                                                         
              <a class="btn dis_flex" href="https://direct.lc.chat/<?php echo $sc['lc_mobile']; ?>">
                <span class="icon-txt fs-xxl">
                  <i class="icon-telegram"></i>
                </span>
                <span><?php echo $s0['instansi']; ?></span>
              </a>
           
                            
                            </div>
    </div>
  </div>
</div>
            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>