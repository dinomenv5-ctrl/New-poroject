<?php
include 'session.php';
include 'header.php';?>

<div class="container-wrapper info ">
  <div class="container container-box info-view">
    <div class="info-nav nav-icon">
      <div class="row no-gutters">
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="terms-terms_conditions.php" class="">
            <div>
              <i class="icon-clipboard"></i>
            </div>
            <div>TERMS & CONDITIONS </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-general.php" class="active">

            <div> <i class="icon-help-circle"></i></div>

            <div>FAQ</div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                  <a href="how-sportsbook.php" class="">
            <div><i class="icon-list-numbered"></i> </div>
            <div>HOW TO PLAY </div>
          </a>
        </div>
         
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-referral.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>REFERRAL</div>
          </a>
        </div>
                <div>
          <a href="responsiblegaming" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>Responsible Gaming</div>
          </a>
        </div>

      </div>
    </div>
<nav class="navbar navbar-expand-lg navbar-light navbar-default  ">
  <!--<span class="menu-select" id="menu-select">General</span>-->
  <div class="navbar-header d-lg-none clearfix">
    <button class="navbar-toggler" id="navbar-toggler--info"  type="button" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <i class="icon-bars navbar-toggler-icon"></i>
    </button>
    <div class="menu-select d-lg-none" id="menu-select--info"></div>
  </div>

  <div class="collapse navbar-collapse" >
    <ul class="navbar-nav mt-lg-0" style="list-style-type:none;">
      <li class="nav-item" >
        <a class="nav-link" href="faq-general.php" data-pg="general">General</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-deposit.php" data-pg="deposit">Deposits</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq_withdrawal.php" data-pg="faq_withdrawal">Withdrawal</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-games.php" data-pg="games">Gaming</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-technical.php"  data-pg="technical">Technical</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-banking.php" data-pg="banking">Banking</a>
      </li>
    </ul>
  </div>
</nav>


<div class="panel-group" id="info_accordion">
    <!-- First Panel -->
        <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse1">
             <h5 class="panel-title info" >
                1. Cara melakukan setoran dana untuk akun <?php echo $s0['instansi']; ?>?             </h5>
        </div>
        <div id="collapse1" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Setoran dana dapat ditransfer melalui kartu debit atau transfer bank.</p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse2">
             <h5 class="panel-title info" >
                2. Mata uang apa yang dapat diterima oleh <?php echo $s0['instansi']; ?>?             </h5>
        </div>
        <div id="collapse2" class="panel-collapse collapse">
            <div class="info panel-body">
                <p><?php echo $s0['instansi']; ?> untuk saat ini hanya menerima  Indonesia mata uang Rupiah.</p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse3">
             <h5 class="panel-title info" >
                3. Dapatkah saya menggunakan lebih dari satu rekening bank untuk transaksi setoran?             </h5>
        </div>
        <div id="collapse3" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Tidak ada ketentuan tentang jumlah rekening bank yang digunakan untuk transaksi setoran, namun nama lengkap pengirim dana/depositor rekening bank harus sama dengan nama rekening yang tercantum di <?php echo $s0['instansi']; ?>. Harap dicatat bahwa <?php echo $s0['instansi']; ?> memiliki hak untuk menolak segala jenis transaksi yang dilakukan oleh nama pihak ketiga.</p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse4">
             <h5 class="panel-title info" >
                4. Apakah slip transfer / pembayaran harus dikirim ke <?php echo $s0['instansi']; ?> setelah saya mentransfer dana melalui bank?             </h5>
        </div>
        <div id="collapse4" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Ini tidak wajib, tetapi dalam situasi tertentu, slip pembayaran Anda diperlukan untuk menyederhanakan proses transaksi Anda.</p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse5">
             <h5 class="panel-title info" >
                5. Berapa lama untuk memproses transaksi deposit?             </h5>
        </div>
        <div id="collapse5" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Transaksi setoran akan diproses dalam waktu 5 (lima) menit setelah kami menerima dana Anda. Ketika verifikasi akun diperlukan untuk beberapa kasus, waktu pemrosesan dimulai setelah verifikasi selesai. </p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse6">
             <h5 class="panel-title info" >
                6. Di mana saya bisa mendapatkan informasi nomor akun <?php echo $s0['instansi']; ?> dan berapa jumlah setoran minimum?             </h5>
        </div>
        <div id="collapse6" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Silakan hubungi layanan pelanggan kami (online 24 jam) untuk mendapatkan informasi mengenai nomor akun dan jumlah minimum untuk transaksi deposit. </p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse7">
             <h5 class="panel-title info" >
                7. Cara Deposit             </h5>
        </div>
        <div id="collapse7" class="panel-collapse collapse">
            <div class="info panel-body">
                <p><b>Petunjuk Deposit</b></p>
        <ol>
          <li>Hubungi Layanan Pelanggan kami (online 24 jam) untuk mendapatkan informasi tentang nomor akun setoran <?php echo $s0['instansi']; ?>.</li>
          <li>Silakan masuk ke situs web <?php echo $s0['instansi']; ?> dan pilih "Transaksi> Deposit" pada Tab menu.</li>
          <li>Formulir setoran harus diisi dengan menggunakan data yang valid dan benar.</li>
          <li>Isi jumlah setoran tanpa simbol titik / koma. Misalnya: 1000 (seribu rupiah). </li>
          <li>Masukkan tanggal dan waktu yang benar (pagi / malam) </li>
          <li>Pilih promosi yang dipilih, jika ada.</li>
          <li>Pilih "Kirim" dan harap tunggu sementara Deposit Anda sedang diproses.</li>
          <br>
        </ol>

      <p>
        <strong>Harap dicatat bahwa setiap transaksi deposit (masuk / keluar dari promosi) harus disesuaikan dengan kebijakan yang telah ditentukan. <?php echo $s0['instansi']; ?> memiliki hak untuk menolak segala jenis transaksi jika tidak mematuhi kebijakan. Untuk informasi lebih lanjut silakan hubungi perwakilan layanan pelanggan kami (online 24 jam).</strong>
      </p>            </div>
        </div>
    </div>
 
</div>
  </div>
</div>



<script>
  $(function(){
    var pg ="deposit"; 
    var selectedMenu=  $('.navbar-nav .nav-link').filter(function(){ 
          return $(this).data("pg").toLowerCase() == pg.toLowerCase();
        }).text();
      $('#menu-select--info').text(selectedMenu);
    

    $('#navbar-toggler--info').click(function(){
        $('.info .navbar-collapse').toggleClass('show in');

    }) 
  });
</script>
            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>