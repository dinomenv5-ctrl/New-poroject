<?php 
include 'session.php';
include 'header.php';?>

<div class="container-wrapper info ">
  <div class="container container-box info-view">
    <div class="info-nav nav-icon">
      <div class="row no-gutters">
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="terms-terms_conditions.php" class="">
            <div>
              <i class="icon-clipboard"></i>
            </div>
            <div>TERMS & CONDITIONS </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-general.php" class="active">

            <div> <i class="icon-help-circle"></i></div>

            <div>FAQ</div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                  <a href="how-sportsbook.php" class="">
            <div><i class="icon-list-numbered"></i> </div>
            <div>HOW TO PLAY </div>
          </a>
        </div>
         
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-referral.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>REFERRAL</div>
          </a>
        </div>
                <div>
          <a href="responsiblegaming" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>Responsible Gaming</div>
          </a>
        </div>

      </div>
    </div>
<nav class="navbar navbar-expand-lg navbar-light navbar-default  ">
  <!--<span class="menu-select" id="menu-select">General</span>-->
  <div class="navbar-header d-lg-none clearfix">
    <button class="navbar-toggler" id="navbar-toggler--info"  type="button" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <i class="icon-bars navbar-toggler-icon"></i>
    </button>
    <div class="menu-select d-lg-none" id="menu-select--info"></div>
  </div>

  <div class="collapse navbar-collapse" >
    <ul class="navbar-nav mt-lg-0" style="list-style-type:none;">
      <li class="nav-item" >
        <a class="nav-link" href="faq-general.php" data-pg="general">General</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-deposit.php" data-pg="deposit">Deposits</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq_withdrawal.php" data-pg="faq_withdrawal">Withdrawal</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-games.php" data-pg="games">Gaming</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-technical.php"  data-pg="technical">Technical</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-banking.php" data-pg="banking">Banking</a>
      </li>
    </ul>
  </div>
</nav>


<div class="panel-group" id="info_accordion">
    <!-- First Panel -->
        <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse1">
             <h5 class="panel-title info" >
                1. Persyaratan umur?              </h5>
        </div>
        <div id="collapse1" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Untuk bergabung, Anda harus menyetujui Persyaratan & Ketentuan dan berusia minimal 18 tahun atau lebih. Sebagian besar negara memiliki aturannya sendiri tentang permainan online dan karenanya Anda harus memastikan bahwa Anda mengetahui adanya peraturan dan mematuhi aturan mereka. </p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse2">
             <h5 class="panel-title info" >
                2. Bagaimana saya bisa menganggap permainan itu adil?              </h5>
        </div>
        <div id="collapse2" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Kami memiliki profesional untuk menghitung persentase pembayaran untuk semua game kami, memastikan bahwa Anda dapat yakin bahwa game kami memenuhi peraturan keadilan standar industri.</p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse3">
             <h5 class="panel-title info" >
                3. Berapa jumlah taruhan minimum dan maksimum <?php echo $s0['instansi']; ?>?              </h5>
        </div>
        <div id="collapse3" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Jumlah taruhan minimum dan maksimum akan tergantung pada jenis tabel permainan yang Anda pilih juga disesuaikan berdasarkan unit mata uang yang Anda gunakan saat mendaftar untuk sebuah akun <?php echo $s0['instansi']; ?>.</p>            </div>
        </div>
    </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse4">
             <h5 class="panel-title info" >
                4. Berapa lama hingga taruhan selesai?              </h5>
        </div>
        <div id="collapse4" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Kami bertujuan untuk menyelesaikan taruhan secepat mungkin, namun untuk beberapa acara diperlukan konfirmasi resmi yang dapat menunda prosedur penyelesaian.</p>            </div>
        </div>
    </div>
 
</div>

  </div>
</div>



<script>
  $(function(){
    var pg ="games"; 
    var selectedMenu=  $('.navbar-nav .nav-link').filter(function(){ 
          return $(this).data("pg").toLowerCase() == pg.toLowerCase();
        }).text();
      $('#menu-select--info').text(selectedMenu);
    

    $('#navbar-toggler--info').click(function(){
        $('.info .navbar-collapse').toggleClass('show in');

    }) 
  });
</script>
            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>