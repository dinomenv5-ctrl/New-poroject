<?php
session_start();
include('../../config/koneksi.php');

if (isset($_GET['trx_id'])) {
    $trx_id = mysqli_real_escape_string($conn, $_GET['trx_id']);
    
    // Melakukan pencarian berdasarkan kd_transaksi sesuai dengan ID dari YerePay 
    $query = mysqli_query($conn, "SELECT status FROM tb_transaksi WHERE kd_transaksi = '$trx_id' LIMIT 1");
    $data = mysqli_fetch_assoc($query);

    if ($data) {
        // Mengembalikan status transaksi (0 untuk pending, 1 untuk sukses) 
        echo json_encode(['status' => (int)$data['status']]);
    } else {
        echo json_encode(['status' => 0]);
    }
} else {
    echo json_encode(['status' => 0, 'message' => 'Transaction ID not provided']);
}
?>