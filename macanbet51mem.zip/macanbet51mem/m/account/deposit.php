<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../../config/koneksi.php');
$sid = session_id();
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../../config/url_helper.php');
}
$urlweb = get_active_base_url();

$pengguna = $s0['user'];
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d');
$stat = mysqli_query($conn, "INSERT INTO `tb_stat` (`ip`, `date`, `hits`, `page`, `user`) VALUES ('$ip', '$date', 1, 'Beranda', '$pengguna')") or die(mysqli_error());

$pgaLabel = 'RED PAY';

include "../header.php"; ?>

<div class="container-wrapper acc">
    <div class="container container-box noSidePadding">
        <div class="head-content">
            <div class="row no-gutters">
                <div class="col-12">
                    <ng-content select="app-game-bals"></ng-content>
                </div>
                <div class="col-12 account_menu">
                    <div class="mdc-tab-bar" role="tablist">
                        <div class="mdc-tab-scroller">
                            <div class="mdc-tab-scroller__scroll-area mdc-tab-scroller__scroll-area--scroll mdc-tab-scroller__scroll-x"
                                style="margin-bottom: 0px;">
                                <div class="mdc-tab-scroller__scroll-content">
                                    <ul class="list-inline">
                                        <li>
                                            <div class="deposit-notice-menu">
                                                <a role="tab" href="<?php echo $urlweb; ?>/m/account/deposit/"
                                                    data-active='accountdeposit' class="mdc-tab" aria-selected="false"
                                                    tabindex="-1" id="goog_2098347606-FIXED-0">
                                                    <span class="mdc-tab__content">
                                                        <span class="mdc-tab__text-label">
                                                            Deposit
                                                        </span>
                                                    </span>
                                                    <span class="mdc-tab-indicator">
                                                        <span
                                                            class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"
                                                            style=""></span>
                                                    </span>
                                                    <span class="mdc-tab__ripple mdc-ripple-upgraded"
                                                        style="--mdc-ripple-fg-size:91px; --mdc-ripple-fg-scale:1.8648; --mdc-ripple-fg-translate-start:76px, -10.5px; --mdc-ripple-fg-translate-end:30.6563px, -21.5px;"></span>
                                                    &nbsp;
                                                </a>
                                            </div>

                                        </li>
                                        <li>
                                            <a role="tab" href="<?php echo $urlweb; ?>/m/account/withdrawal/"
                                                data-active='accountwithdrawal' class="mdc-tab" aria-selected="true"
                                                tabindex="0" id="goog_2098347606-FIXED-1">
                                                <span class="mdc-tab__content">

                                                    <span class="mdc-tab__text-label">
                                                        Withdraw
                                                    </span>
                                                </span>
                                                <span class="mdc-tab-indicator">
                                                    <span
                                                        class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"
                                                        style=""></span>
                                                </span>
                                                <span class="mdc-tab__ripple mdc-ripple-upgraded"
                                                    style="--mdc-ripple-fg-size:93px; --mdc-ripple-fg-scale:1.85613; --mdc-ripple-fg-translate-start:48.6875px, -6.5px; --mdc-ripple-fg-translate-end:31.1875px, -22.5px;"></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a role="tab" href="<?php echo $urlweb; ?>/m/account/history/"
                                                data-active='accountlastdirecttransfer' class="mdc-tab"
                                                aria-selected="false" tabindex="-1" id="goog_2098347606-FIXED-3">
                                                <span class="mdc-tab__content">
                                                    <span class="mdc-tab__text-label">
                                                        5 Transaksi Terakhir
                                                    </span>
                                                </span>
                                                <span class="mdc-tab-indicator">
                                                    <span
                                                        class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"
                                                        style=""></span>
                                                </span>
                                                <span class="mdc-tab__ripple mdc-ripple-upgraded"
                                                    style="--mdc-ripple-fg-size:102px; --mdc-ripple-fg-scale:1.83267; --mdc-ripple-fg-translate-start:-44.1875px, -35px; --mdc-ripple-fg-translate-end:34.1484px, -27px;"></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a role="tab" href="<?php echo $urlweb; ?>/m/account/history/"
                                                data-active='accounthistory' class="mdc-tab" aria-selected="false"
                                                tabindex="-1" id="goog_2098347606-FIXED-2">
                                                <span class="mdc-tab__content">
                                                    <span class="mdc-tab__text-label">
                                                        Pernyataan
                                                    </span>
                                                </span>
                                                <span class="mdc-tab-indicator">
                                                    <span
                                                        class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"
                                                        style=""></span>
                                                </span>
                                                <span class="mdc-tab__ripple mdc-ripple-upgraded"
                                                    style="--mdc-ripple-fg-size:102px; --mdc-ripple-fg-scale:1.83267; --mdc-ripple-fg-translate-start:-44.1875px, -35px; --mdc-ripple-fg-translate-end:34.1484px, -27px;"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        error_reporting(0);
        if(isset($_SESSION['user'])) {
            $user = mysqli_query($conn,"SELECT * FROM `tb_user` WHERE username = '".$_SESSION['user']."'") or die (mysqli_error());
            $u = mysqli_fetch_array($user);
            $useridnya = $u['cuid'];
            
            // Cek apakah ada deposit pending
            $cekTransaksi = mysqli_query($conn,"SELECT * FROM `tb_transaksi` WHERE userID = '$useridnya' AND jenis = 1 AND status = 0 ORDER BY cuid DESC LIMIT 1") or die(mysqli_error());
            $ct = mysqli_num_rows($cekTransaksi);
            
            if($ct > 0){
                $pendingDeposit = mysqli_fetch_array($cekTransaksi);
                $pendingNominal = number_format((float)($pendingDeposit['total'] ?? 0), 2, ',', '.');
                $pendingDate = $pendingDeposit['date'] ?? '-';
                $pendingKdTransaksi = $pendingDeposit['kd_transaksi'] ?? '-';
                $pendingCuid = $pendingDeposit['cuid'] ?? 0;
        ?>
            <div class="content">
                <div class="alert alert-warning alert-dismissible mb-2" role="alert" style="margin: 15px;">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <div class="alert-message">
                        <h5 style="margin-bottom: 15px; font-weight: bold;">⚠️ Deposit Pending</h5>
                        <p style="margin-bottom: 10px;">Anda masih memiliki Permintaan Deposit yang Belum Diproses:</p>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;">
                            <table style="width: 100%;">
                                <tr>
                                    <td style="padding: 5px 0;"><strong>Nomor Transaksi:</strong></td>
                                    <td style="padding: 5px 0;"><?php echo htmlspecialchars($pendingKdTransaksi); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 5px 0;"><strong>Tanggal:</strong></td>
                                    <td style="padding: 5px 0;"><?php echo htmlspecialchars($pendingDate); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 5px 0;"><strong>Nominal:</strong></td>
                                    <td style="padding: 5px 0; color: #007bff; font-weight: bold;">IDR <?php echo $pendingNominal; ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 5px 0;"><strong>Status:</strong></td>
                                    <td style="padding: 5px 0;"><span class="label label-warning" style="padding: 5px 10px; border-radius: 5px;">Menunggu Proses</span></td>
                                </tr>
                            </table>
                        </div>
                        <div style="margin-top: 15px;">
                            <!-- [FIX F] Tombol lanjutkan pembayaran QRIS pending:
                                 buka halaman QR dengan ?kd=<kd_transaksi> sehingga
                                 QR dibangun ulang dari AutoGopay API + polling
                                 tetap jalan walau session qris_payment kosong. -->
                            <?php if (isset($pendingDeposit['metode']) && strtoupper((string)$pendingDeposit['metode']) === 'QRIS') { ?>
                            <button type="button" class="btn btn-success" onclick="window.location.href='<?php echo $urlweb; ?>/m/account/qris_payment?kd=<?php echo urlencode((string)$pendingKdTransaksi); ?>';" style="margin-right: 10px;">
                                <i class="icon-qr-code"></i> Lanjutkan Pembayaran QRIS
                            </button>
                            <?php } ?>
                            <button type="button" class="btn btn-danger" id="btnCancelDeposit" data-trans-id="<?php echo $pendingCuid; ?>" style="margin-right: 10px;">
                                <i class="icon-close"></i> Batalkan Deposit
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="window.location.reload();">
                                <i class="icon-refresh"></i> Refresh
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <script>
                $(document).ready(function() {
                    $('#btnCancelDeposit').on('click', function() {
                        var transId = $(this).data('trans-id');
                        
                        if (!confirm('Apakah Anda yakin ingin membatalkan deposit ini? Tindakan ini tidak dapat dibatalkan.')) {
                            return false;
                        }
                        
                        // Disable button
                        $(this).prop('disabled', true).html('<i class="icon-spinner"></i> Memproses...');
                        
                        // AJAX request untuk membatalkan deposit
                        $.ajax({
                            url: '<?php echo $urlweb; ?>/m/account/cancel_deposit.php',
                            type: 'POST',
                            data: {
                                trans_id: transId
                            },
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    alert('Deposit berhasil dibatalkan!');
                                    window.location.reload();
                                } else {
                                    alert('Gagal membatalkan deposit: ' + response.message);
                                    $('#btnCancelDeposit').prop('disabled', false).html('<i class="icon-close"></i> Batalkan Deposit');
                                }
                            },
                            error: function(xhr, status, error) {
                                alert('Terjadi kesalahan: ' + error);
                                $('#btnCancelDeposit').prop('disabled', false).html('<i class="icon-close"></i> Batalkan Deposit');
                            }
                        });
                    });
                });
            </script>
        <?php
            } else {
        ?>
            <div class="content">
                <div class="deposit">
                    <div class="container container-box">
                        <div class="row">
                            <!-- Konfirmasi Transfer Bank -->
                            <div class="col-xs-12 col-md-8 content-form">
                                <div class="methods_form" id="metode">
                                    <div class="box-wrapper plr-15">
                                        <div class="row align-items-center">
                                            <div class="col-md-3 col-xs-12 text-center pay-title">
                                                <div>
                                                    Konfirmasi Transfer Bank / E Wallet (Manual Cek)
                                                </div>
                                            </div>
                                            <div class="col-md-9 col-xs-12 d-flex flex-wrap">
                                                <?php
                                                // Ambil bank admin (userID = 1) yang aktif untuk deposit
                                                $adminUserID = 1;
                                                $bankQuery = "SELECT * FROM `tb_bank` WHERE userID = ? AND status = 1 ORDER BY cuid ASC";
                                                $stmt = mysqli_prepare($conn, $bankQuery);
                                                
                                                if ($stmt) {
                                                    mysqli_stmt_bind_param($stmt, "i", $adminUserID);
                                                    mysqli_stmt_execute($stmt);
                                                    $bankResult = mysqli_stmt_get_result($stmt);
                                                    
                                                    if (mysqli_num_rows($bankResult) > 0) {
                                                        while ($bank = mysqli_fetch_assoc($bankResult)) {
                                                            $bankImage = !empty($bank['image']) ? $bank['image'] : 'https://via.placeholder.com/70x50?text=Bank';
                                                            $bankEncoded = base64_encode($bank['cuid']);
                                                            
                                                            echo '<a class="payment-methods payment-methods-items online" href="' . $urlweb . '/m/account/metode/?bank=' . $bankEncoded . '">';
                                                            echo '<div class="verti online">';
                                                            echo '<img class="img-fluid" style="max-width: 70px; max-height: 50px; object-fit: contain;" src="' . htmlspecialchars($bankImage) . '" alt="' . htmlspecialchars($bank['akun'] ?? 'Bank') . '">';
                                                            echo '</div>';
                                                            echo '</a>';
                                                        }
                                                    } else {
                                                        echo '<div class="col-12 text-center text-muted" style="padding: 20px;">Tidak ada bank yang tersedia</div>';
                                                    }
                                                    
                                                    mysqli_stmt_close($stmt);
                                                } else {
                                                    echo '<div class="col-12 text-center text-danger" style="padding: 20px;">Error: Gagal memuat data bank</div>';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- QRIS -->
                                    <div class="box-wrapper plr-15">
                                        <div class="row align-items-center">
                                            <div class="col-md-3 col-xs-12 text-center pay-title">
                                                <div>
                                                    QRIS <?php echo htmlspecialchars($pgaLabel); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-9 col-xs-12">
                                                <a id="btn_qris" href="<?php echo $urlweb; ?>/m/account/qris_deposit" style="display:block; width:100%;">
                                                    <img src="https://simpangambar.my.id/uploads/6a5d23f08a252_1784488944.webp" alt="QRIS Deposit Otomatis" style="width:100%; height:auto; display:block; border-radius:8px;">
                                                </a>
                                                <input type="hidden" id="preload" value="1">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Pulsa -->
                                    <div class="box-wrapper plr-15">
                                        <div class="row align-items-center">
                                            <div class="col-md-3 col-xs-12 text-center pay-title">
                                                <div>
                                                    Pulsa (Manual Cek)
                                                </div>
                                            </div>
                                            <div class="col-md-9 col-xs-12 d-flex flex-wrap">
                                                <!-- Pulsa Buttons -->
                                                <button class="payment-methods payment-methods-items online" disabled>
                                                    <div class="verti offline">
                                                        <img class="img-fluid" src="https://files.sitestatic.net/sprites/bank_logos/ewallet/xl_col.jpg?v=1" alt="XL">
                                                    </div>
                                                </button>
                                                <button class="payment-methods payment-methods-items offline" disabled>
                                                    <div class="verti offline">
                                                        <img class="img-fluid" src="https://files.sitestatic.net/sprites/bank_logos/ewallet/telkomsel_col.jpg?v=1" alt="Telkomsel">
                                                    </div>
                                                </button>
                                                <input type="hidden" id="preload" value="1">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
            }
        } else {
            // Jika user tidak login, tampilkan pesan
            echo '<div class="content"><div class="alert alert-warning">Silakan login terlebih dahulu.</div></div>';
        }
        ?>
    </div>
</div>
<?php include "../footer.php"; ?>