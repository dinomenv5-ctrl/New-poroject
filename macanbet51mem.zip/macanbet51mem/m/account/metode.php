<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);



if (isset($_GET['bank'])) {

    $encoded_cuid = $_GET['bank'];


    $decoded_cuid = base64_decode($encoded_cuid);
} else {
    // Jika parameter 'bank' tidak ada dalam URL
    echo 'Parameter "bank" tidak ditemukan dalam URL.';
    exit;
}
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../../config/koneksi.php');
$sid = session_id();
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../../config/url_helper.php');
}
$urlweb = get_active_base_url();

if (isset($_SESSION['user'])) {
    $sql_1 = mysqli_query($conn, "SELECT * FROM `tb_user` WHERE cuid = 1") or die(mysqli_error());
    $s1b = mysqli_fetch_array($sql_1);

    $user = mysqli_query($conn, "SELECT * FROM `tb_user` WHERE username = '" . $_SESSION['user'] . "'") or die(mysqli_error());
    $u = mysqli_fetch_array($user);
    $users = $u['username'];
    $id_user = $u['cuid'];
    $userID = $u['cuid'];
    $sql_3 = mysqli_query($conn, "SELECT * FROM `tb_balance` WHERE userID = '$userID'") or die(mysqli_error());
    $s3 = mysqli_fetch_array($sql_3);

    $sql_banks = mysqli_query($conn, "SELECT * FROM `tb_bank` WHERE userID = '$userID'") or die(mysqli_error());
    $sbs = mysqli_fetch_array($sql_banks);
} else {
}
include "../header.php"; ?>

<div class="container-wrapper acc">
    <div class="container container-box noSidePadding">
        <div class="head-content">
            <div class="row no-gutters">
                <div class="col-12">
                    <ng-content select="app-game-bals"></ng-content>
                </div>
                <div class="col-12 account_menu">
                    <div class="mdc-tab-bar" role="tablist">
                        <div class="mdc-tab-scroller">
                            <div class="mdc-tab-scroller__scroll-area mdc-tab-scroller__scroll-area--scroll mdc-tab-scroller__scroll-x"
                                style="margin-bottom: 0px;">
                                <div class="mdc-tab-scroller__scroll-content">
                                    <ul class="list-inline">
                                        <li>
                                            <div class="deposit-notice-menu">
                                                <a role="tab" href="<?php echo $urlweb; ?>/m/account/deposit/"
                                                    data-active='accountdeposit' class="mdc-tab" aria-selected="false"
                                                    tabindex="-1" id="goog_2098347606-FIXED-0">
                                                    <span class="mdc-tab__content">
                                                        <span class="mdc-tab__text-label">
                                                            Deposit
                                                        </span>
                                                    </span>
                                                    <span class="mdc-tab-indicator">
                                                        <span
                                                            class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"
                                                            style=""></span>
                                                    </span>
                                                    <span class="mdc-tab__ripple mdc-ripple-upgraded"
                                                        style="--mdc-ripple-fg-size:91px; --mdc-ripple-fg-scale:1.8648; --mdc-ripple-fg-translate-start:76px, -10.5px; --mdc-ripple-fg-translate-end:30.6563px, -21.5px;"></span>
                                                    &nbsp;
                                                </a>
                                            </div>

                                        </li>
                                        <li>
                                            <a role="tab" href="<?php echo $urlweb; ?>/m/account/withdrawal/"
                                                data-active='accountwithdrawal' class="mdc-tab" aria-selected="true"
                                                tabindex="0" id="goog_2098347606-FIXED-1">
                                                <span class="mdc-tab__content">

                                                    <span class="mdc-tab__text-label">
                                                        Withdraw
                                                    </span>
                                                </span>
                                                <span class="mdc-tab-indicator">
                                                    <span
                                                        class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"
                                                        style=""></span>
                                                </span>
                                                <span class="mdc-tab__ripple mdc-ripple-upgraded"
                                                    style="--mdc-ripple-fg-size:93px; --mdc-ripple-fg-scale:1.85613; --mdc-ripple-fg-translate-start:48.6875px, -6.5px; --mdc-ripple-fg-translate-end:31.1875px, -22.5px;"></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a role="tab" href="<?php echo $urlweb; ?>/m/account/history/"
                                                data-active='accountlastdirecttransfer' class="mdc-tab"
                                                aria-selected="false" tabindex="-1" id="goog_2098347606-FIXED-3">
                                                <span class="mdc-tab__content">
                                                    <span class="mdc-tab__text-label">
                                                        5 Transaksi Terakhir
                                                    </span>
                                                </span>
                                                <span class="mdc-tab-indicator">
                                                    <span
                                                        class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"
                                                        style=""></span>
                                                </span>
                                                <span class="mdc-tab__ripple mdc-ripple-upgraded"
                                                    style="--mdc-ripple-fg-size:102px; --mdc-ripple-fg-scale:1.83267; --mdc-ripple-fg-translate-start:-44.1875px, -35px; --mdc-ripple-fg-translate-end:34.1484px, -27px;"></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a role="tab" href="<?php echo $urlweb; ?>/m/account/history/"
                                                data-active='accounthistory' class="mdc-tab" aria-selected="false"
                                                tabindex="-1" id="goog_2098347606-FIXED-2">
                                                <span class="mdc-tab__content">
                                                    <span class="mdc-tab__text-label">
                                                        Pernyataan
                                                    </span>
                                                </span>
                                                <span class="mdc-tab-indicator">
                                                    <span
                                                        class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"
                                                        style=""></span>
                                                </span>
                                                <span class="mdc-tab__ripple mdc-ripple-upgraded"
                                                    style="--mdc-ripple-fg-size:102px; --mdc-ripple-fg-scale:1.83267; --mdc-ripple-fg-translate-start:-44.1875px, -35px; --mdc-ripple-fg-translate-end:34.1484px, -27px;"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        error_reporting(0);
        $useridnya = $u['cuid'];
        $cekTransaksi = mysqli_query($conn, "SELECT * FROM `tb_transaksi` WHERE userID = '$useridnya' AND jenis = 1 AND status = 0 ORDER BY cuid DESC LIMIT 1") or die(mysqli_error());
        $ct = mysqli_num_rows($cekTransaksi);
        if ($ct > 0) {
            $pendingDeposit = mysqli_fetch_array($cekTransaksi);
            $pendingNominal = number_format((float)($pendingDeposit['total'] ?? 0), 2, ',', '.');
            $pendingDate = $pendingDeposit['date'] ?? '-';
            $pendingKdTransaksi = $pendingDeposit['kd_transaksi'] ?? '-';
            $pendingCuid = $pendingDeposit['cuid'] ?? 0;
        ?>
            <div class="content">
                <div class="alert alert-warning alert-dismissible mb-2" role="alert" style="margin: 15px;">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <div class="alert-message">
                        <h5 style="margin-bottom: 15px; font-weight: bold;">⚠️ Deposit Pending</h5>
                        <p style="margin-bottom: 10px;">Anda masih memiliki Permintaan Deposit yang Belum Diproses:</p>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;">
                            <table style="width: 100%;">
                                <tr>
                                    <td style="padding: 5px 0;"><strong>Nomor Transaksi:</strong></td>
                                    <td style="padding: 5px 0;"><?php echo htmlspecialchars($pendingKdTransaksi); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 5px 0;"><strong>Tanggal:</strong></td>
                                    <td style="padding: 5px 0;"><?php echo htmlspecialchars($pendingDate); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 5px 0;"><strong>Nominal:</strong></td>
                                    <td style="padding: 5px 0; color: #007bff; font-weight: bold;">IDR <?php echo $pendingNominal; ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 5px 0;"><strong>Status:</strong></td>
                                    <td style="padding: 5px 0;"><span class="label label-warning" style="padding: 5px 10px; border-radius: 5px;">Menunggu Proses</span></td>
                                </tr>
                            </table>
                        </div>
                        <div style="margin-top: 15px;">
                            <button type="button" class="btn btn-danger" id="btnCancelDeposit" data-trans-id="<?php echo $pendingCuid; ?>" style="margin-right: 10px;">
                                <i class="icon-close"></i> Batalkan Deposit
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="window.location.reload();">
                                <i class="icon-refresh"></i> Refresh
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                $(document).ready(function() {
                    $('#btnCancelDeposit').on('click', function() {
                        var transId = $(this).data('trans-id');
                        
                        if (!confirm('Apakah Anda yakin ingin membatalkan deposit ini? Tindakan ini tidak dapat dibatalkan.')) {
                            return false;
                        }
                        
                        // Disable button
                        $(this).prop('disabled', true).html('<i class="icon-spinner"></i> Memproses...');
                        
                        // AJAX request untuk membatalkan deposit
                        $.ajax({
                            url: '<?php echo $urlweb; ?>/m/account/cancel_deposit.php',
                            type: 'POST',
                            data: {
                                trans_id: transId
                            },
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    alert('Deposit berhasil dibatalkan!');
                                    window.location.reload();
                                } else {
                                    alert('Gagal membatalkan deposit: ' + response.message);
                                    $('#btnCancelDeposit').prop('disabled', false).html('<i class="icon-close"></i> Batalkan Deposit');
                                }
                            },
                            error: function(xhr, status, error) {
                                alert('Terjadi kesalahan: ' + error);
                                $('#btnCancelDeposit').prop('disabled', false).html('<i class="icon-close"></i> Batalkan Deposit');
                            }
                        });
                    });
                });
            </script>
        <?php
        ?>
        <?php } else { ?>
            <div class="content">
                <div id="modal_qris" style="display: block">
                    <div class="box-wrapper plr-15">
                        <div class="container-b3">
                            <div class="row">
                                <div class="col-xs-12 col-md-12 content-form">
                                    <style>
                                        * {
                                            -webkit-backface-visibility: visible;
                                        }

                                        select>option.disble {
                                            background-color: #d4d4d4;
                                        }
                                    </style>

                                    <form id="depositForm" method="POST" action="<?php echo $urlweb . '/function/deposit.php'; ?>">
                                        <!-- Hidden fields untuk data yang diperlukan -->
                                        <input type="hidden" name="postID" value="<?php echo $u['cuid']; ?>">
                                        <input type="hidden" name="metode" value="<?php echo htmlspecialchars($decoded_cuid); ?>">
                                        <input type="hidden" name="username" value="<?php echo htmlspecialchars($_SESSION['user']); ?>">
                                        <input type="hidden" name="submit" value="1">

                                        <div class="box-wrapper plr-15">
                                            <div class="row d-flex">
                                                <div class="col-md-3 col-xs-4  ">
                                                    <div class="font-weight-bold"> Metode Penyetoran<span
                                                            class="text-danger">*</span>
                                                    </div>
                                                </div>
                                                <div class="col-md-9 col-xs-8 d-flex flex-wrap">
                                                    <div class="radio_2 m-15 mt-2">
                                                        <input id="radioBank5" checked="" type="radio" value="5">
                                                        <label class=" " for="radioBank5">
                                                            <span class="radio-title"> Bank / E-Wallet </span>
                                                            <span class="marked">
                                                                <i class="icon-checkmark"></i>
                                                            </span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab">
                                                <div class="row d-flex">
                                                    <div class="col-md-3 col-xs-4  ">
                                                        <div class="font-weight-bold">Username<span
                                                                class="text-danger">*</span></div>
                                                    </div>
                                                    <div class="col-md-9 col-xs-8  d-flex flex-wrap">
                                                        <input type="text" class="form-control m-15" name="username"
                                                            value="<?php echo htmlspecialchars($_SESSION['user']); ?>" readonly required>
                                                    </div>

                                                </div>
                                                <div class="row d-flex">
                                                    <div class="col-md-3 col-xs-4  ">
                                                        <div class="font-weight-bold">Rekening Pengirim<span
                                                                class="text-danger">*</span></div>
                                                    </div>
                                                    <div class="col-md-9 col-xs-8  d-flex flex-wrap">
                                                        <select class="form-control m-15" name="pay_from" required>

                                                            <option value="<?php echo $sbs['cuid']; ?>">
                                                                <?php echo $sbs['akun']; ?> - <?php
                                                                                                $no_rek = $sbs['no_rek'];

                                                                                                // Panjang total nomor rekening
                                                                                                $total_length = strlen($no_rek);

                                                                                                // Panjang digit yang akan ditampilkan (misalnya, 4 digit terakhir)
                                                                                                $length_to_display = 4;

                                                                                                // Bagian nomor rekening yang akan ditampilkan
                                                                                                $visible_part = substr($no_rek, -$length_to_display);

                                                                                                // Bagian nomor rekening yang akan disensor
                                                                                                $censored_part = str_repeat('X', $total_length - $length_to_display);

                                                                                                // Menampilkan nomor rekening yang telah disensor
                                                                                                echo $censored_part . $visible_part;
                                                                                                ?>
                                                                -
                                                                <?php echo $sbs['pemilik']; ?>
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row info-lst" id="bankInfo_de001" style="">
                                                    <?php
                                                    // Query untuk ambil data bank berdasarkan decoded_cuid
                                                    // Pastikan bank adalah bank admin (userID = 1) untuk deposit
                                                    $decoded_cuid_escaped = mysqli_real_escape_string($conn, $decoded_cuid);
                                                    
                                                    // Validasi decoded_cuid adalah numeric
                                                    if (!is_numeric($decoded_cuid)) {
                                                        $decoded_cuid = (int)$decoded_cuid;
                                                        $decoded_cuid_escaped = mysqli_real_escape_string($conn, $decoded_cuid);
                                                    }
                                                    
                                                    // Coba ambil bank admin dulu (bank untuk deposit biasanya userID = 1)
                                                    $sql_bank = mysqli_query($conn, "SELECT * FROM `tb_bank` WHERE cuid = '$decoded_cuid_escaped' AND status = 1 AND userID = 1") or die(mysqli_error());
                                                    $sq = mysqli_fetch_array($sql_bank);
                                                    
                                                    // Jika tidak ditemukan sebagai bank admin, coba tanpa filter userID (untuk kompatibilitas)
                                                    if (!$sq || empty($sq['pemilik']) || empty($sq['no_rek'])) {
                                                        $sql_bank = mysqli_query($conn, "SELECT * FROM `tb_bank` WHERE cuid = '$decoded_cuid_escaped' AND status = 1") or die(mysqli_error());
                                                        $sq = mysqli_fetch_array($sql_bank);
                                                    }

                                                    if ($sq && !empty($sq['pemilik']) && !empty($sq['no_rek'])) {
                                                        $status = ($sq['status'] == 1) ? 'ONLINE' : 'OFFLINE';
                                                        $statusClass = ($sq['status'] == 1) ? 'text-success' : 'text-danger';
                                                    ?>
                                                        <div class="col-xs-12 col-md-9">
                                                            <div class="bankInfo-box" id="bankList">
                                                                <div class="box-title">
                                                                    <i class="icon-invoice i-invoice"></i>
                                                                    Rincian Deposit Akun
                                                                    <div class="pull-right acc_status">STATUS : <span
                                                                            class="<?php echo $statusClass; ?>"><?php echo $status; ?></span>
                                                                    </div>
                                                                    <input type="hidden" id="depo_acc_status" value="<?php echo $status; ?>" />
                                                                </div>

                                                                <table class="table table-borderless text-right info-box--001">
                                                                    <tbody>
                                                                        <!-- Rekening Penerima -->
                                                                        <tr class="text-left first">
                                                                            <td class="col-xs-12 col-md-6" colspan="2">
                                                                                <small><strong>Rekening Penerima</strong></small>
                                                                            </td>
                                                                        </tr>
                                                                        <tr class="text-left first">
                                                                            <td class="col-xs-12 col-md-6" colspan="2">
                                                                                <small>Nama Bank</small>
                                                                            </td>
                                                                        </tr>
                                                                        <tr class="">
                                                                            <td class="col-xs-12 col-md-6" colspan="2">
                                                                                <span class="lbl" style="font-weight: bold; color: #333;">
                                                                                    <?php echo isset($sq['akun']) ? htmlspecialchars($sq['akun']) : '-'; ?>
                                                                                </span>
                                                                            </td>
                                                                        </tr>
                                                                        <tr class="text-left first">
                                                                            <td class="col-xs-12 col-md-6" colspan="2">
                                                                                <small>Nama Akun</small>
                                                                            </td>
                                                                        </tr>
                                                                        <tr class="">
                                                                            <td class="col-xs-12 col-md-6" colspan="2" style="padding-bottom: 10px">
                                                                                <input id="info-copy-1"
                                                                                    value="<?php echo isset($sq['pemilik']) ? htmlspecialchars($sq['pemilik']) : ''; ?>"
                                                                                    class="copy-input" style="display: none;" />
                                                                                <a href="javascript:void(0);"
                                                                                    data-sel="info-copy-1"
                                                                                    class="btn btn-link btn-copy lbl">
                                                                                    <span class="" style="font-weight: bold;">
                                                                                        <?php echo isset($sq['pemilik']) ? htmlspecialchars($sq['pemilik']) : '-'; ?>
                                                                                    </span>
                                                                                    <i class="icon-copy"></i>
                                                                                </a>
                                                                            </td>
                                                                        </tr>
                                                                        <tr class="text-left first">
                                                                            <td class="col-xs-12 col-md-6" colspan="2">
                                                                                <small>Nomor Rekening</small>
                                                                            </td>
                                                                        </tr>
                                                                        <tr class=" ">
                                                                            <td class="col-xs-12 col-md-6" colspan="2"
                                                                                style="padding-bottom: 10px">
                                                                                <input id="info-copy-2"
                                                                                    value="<?php echo isset($sq['no_rek']) ? htmlspecialchars($sq['no_rek']) : ''; ?>"
                                                                                    class="copy-input" style="display: none;" />
                                                                                <a href="javascript:void(0);"
                                                                                    data-sel="info-copy-2"
                                                                                    class="btn btn-link btn-copy lbl">
                                                                                    <span class=""
                                                                                        style="white-space: normal; word-break: break-word; font-weight: bold; font-size: 16px; color: #007bff;">
                                                                                        <?php echo isset($sq['no_rek']) ? htmlspecialchars($sq['no_rek']) : '-'; ?>
                                                                                    </span>
                                                                                    <i class="icon-copy"></i>
                                                                                </a>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="2" style="padding: 10px 0; border-top: 1px solid #eee;"></td>
                                                                        </tr>
                                                                    <?php } else { ?>
                                                                        <tr>
                                                                            <td colspan="2" style="padding: 15px; text-align: center; color: #dc3545;">
                                                                                <div class="alert alert-warning">
                                                                                    <strong>⚠️ Data Bank Tidak Ditemukan</strong><br>
                                                                                    <small>Bank yang dipilih tidak tersedia atau data tidak lengkap. Silakan pilih bank lain.</small>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    <?php } ?>
                                                                    <tr class="text-left tr_type2">
                                                                        <td class="col-xs-6 col-md-6">
                                                                            <small>Min Deposit</small>
                                                                        </td>
                                                                        <td class="col-xs-6 col-md-6 text-right">
                                                                            <span class="lbl">IDR <?php echo 'Rp ' . number_format($s0['mindepo'], 2, ',', '.'); ?></span>
                                                                            <input type="hidden" id="bank_min_deposit"
                                                                                class="min_deposit" value="<?php echo $s0['mindepo']; ?>" />
                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-left tr_type2">
                                                                        <td class="col-xs-6 col-md-6">
                                                                            <small i18n="">Max Deposit</small>
                                                                        </td>
                                                                        <td class="col-xs-6 col-md-6 text-right">
                                                                            <span class="lbl">IDR <?php echo 'Rp ' . number_format($s0['maxdepo'], 0, ',', '.'); ?></span>
                                                                            <input type="hidden" id="bank_max_deposit"
                                                                                class="max_deposit" value="<?php echo $s0['maxdepo']; ?>" />
                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-left tr_type2">
                                                                        <td class="col-xs-6 col-md-6">
                                                                            <small i18n="">Komisi Bank / Transaksi</small>
                                                                        </td>
                                                                        <td class="col-xs-6 col-md-6 text-right">
                                                                            <span class="lbl">IDR 0.00 </span>
                                                                        </td>
                                                                    </tr>

                                                                    <input type="hidden" id="subsidi" value="IDR 0" />
                                                                    </tbody>
                                                                </table>
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        $('[data-toggle="tooltip"]').tooltip();
                                                                    });
                                                                </script>
                                                            </div>
                                                        </div>
                                                </div>

                                                <div class="row d-flex">
                                                    <div class="col-md-3 col-xs-4 ">
                                                        <div class="font-weight-bold">
                                                            Jumlah Deposit<span class="text-danger">*</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-9 col-xs-8">
                                                        <div class="d-flex flex-wrap">
                                                            <input type="number" id="amount"
                                                                class="form-control m-15"
                                                                placeholder="Masukan Nominal Deposit"
                                                                name="amount"
                                                                min="<?php echo $s0['mindepo']; ?>"
                                                                max="<?php echo $s0['maxdepo']; ?>"
                                                                step="1000"
                                                                required>
                                                            <!-- Hidden field untuk nominal (backup untuk compatibility) -->
                                                            <input type="hidden" name="nominal" id="nominal_hidden">
                                                        </div>
                                                        <p class="min-max-notes">
                                                            Min Deposit<span class="min-deposit-amount"
                                                                style="padding-right: 5px;"><b id="min_bni">
                                                                    <?php echo number_format($s0['mindepo'], 2, ',', '.'); ?></b></span><br>
                                                            Max Deposit<span class="max-deposit-amount"><b><?php echo number_format($s0['maxdepo'], 2, ',', '.'); ?></b></span>
                                                        </p>

                                                    </div>
                                                </div>

                                                <div class="row d-flex">
                                                    <div class="col-md-3 col-xs-4  ">
                                                        <div class="font-weight-bold">
                                                            Keterangan </div>
                                                    </div>
                                                    <div class="col-md-9 col-xs-8 d-flex flex-wrap">
                                                        <input type="text" class="form-control m-15" id="catatan" maxlength="35"
                                                            minlength="5" name="catatan" placeholder="No. Referensi / Nama Pengirim">
                                                    </div>
                                                </div>

                                                <div class="row d-flex">
                                                    <div class="col-md-3 col-xs-4  ">
                                                        <div class="font-weight-bold"> Bonus
                                                        </div>
                                                    </div>
                                                    <div class="col-md-9 col-xs-8 d-flex flex-wrap">
                                                        <div class="m-15" style="width: 100%;">
                                                            <div style="width: 100%;">
                                                                <select class="form-control promoList" id="gameid"
                                                                    name="gameid">
                                                                    <option disabled selected value="0">Pilih promo
                                                                        tersedia</option>
                                                                    <?php
                                                                        $sql_transaksi = mysqli_query($conn, "SELECT * FROM `tb_post` WHERE kategori = 0 AND cuid ORDER BY cuid ASC") or die(mysqli_error());
                                                                        $no = 0;
                                                                        while ($st = mysqli_fetch_array($sql_transaksi)) {
                                                                        $no++;
                                                                    ?>
                                                                    <option value="<?php echo $st['cuid']; ?>">
                                                                        <?php echo ucwords(strtolower($st['title'])); ?>
                                                                        <?php } ?>
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row d-flex">
                                                    <div class="col-md-12 d-flex flex-wrap">
                                                        <label>
                                                            <input type="checkbox" class="form-check-input"
                                                                id="exampleCheck1" name="termcondition" required>
                                                            Saya telah membaca dan menyetujui
                                                            Syarat dan
                                                            Ketentuan Promosi. Kami tidak
                                                            menerima jenis
                                                            setoran dalam bentuk cek. Semua
                                                            jenis
                                                            pembayaran
                                                            dalam bentuk cek ke akun kami akan
                                                            diabaikan.
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--- second Tab end----->
                                            <div class="row d-flex">
                                                <div class="col-md-3 col-xs-4  ">
                                                </div>
                                                <div class="col-md-9 col-xs-8 d-flex flex-wrap">
                                                    <div class="m-15">
                                                        <button type="button" class="btn btn-primary" id="backBtn"
                                                            onclick="tutup_bank()">Back</button>
                                                        <button type="submit" class="btn btn-secondary" id="submitBtn"
                                                            name="submit">Lanjut</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php include "../footer.php"; ?>
                <script>
                    // Fungsi untuk copy ke clipboard
                    $(document).ready(function() {
                        $('.btn-copy').on('click', function(e) {
                            e.preventDefault();
                            var sel = $(this).attr('data-sel');
                            var copyInput = $('#' + sel);
                            var textToCopy = copyInput.val();

                            // Buat elemen textarea sementara untuk copy
                            var tempInput = $('<textarea>');
                            $('body').append(tempInput);
                            tempInput.val(textToCopy).select();

                            try {
                                var successful = document.execCommand('copy');
                                if (successful) {
                                    alert('Berhasil disalin ke clipboard!');
                                } else {
                                    // Fallback untuk browser modern
                                    if (navigator.clipboard && navigator.clipboard.writeText) {
                                        navigator.clipboard.writeText(textToCopy).then(function() {
                                            alert('Berhasil disalin ke clipboard!');
                                        }).catch(function(err) {
                                            console.error('Gagal menyalin: ', err);
                                            alert('Gagal menyalin. Silakan salin manual.');
                                        });
                                    } else {
                                        alert('Gagal menyalin. Silakan salin manual.');
                                    }
                                }
                            } catch (err) {
                                console.error('Gagal menyalin: ', err);
                                // Fallback untuk browser modern
                                if (navigator.clipboard && navigator.clipboard.writeText) {
                                    navigator.clipboard.writeText(textToCopy).then(function() {
                                        alert('Berhasil disalin ke clipboard!');
                                    }).catch(function(err) {
                                        console.error('Gagal menyalin: ', err);
                                        alert('Gagal menyalin. Silakan salin manual.');
                                    });
                                } else {
                                    alert('Gagal menyalin. Silakan salin manual.');
                                }
                            }

                            tempInput.remove();
                        });
                    });

                    function tutup_bank() {
                        window.location.href = '<?php echo $urlweb; ?>/m/account/deposit';
                    }


                    document.getElementById('depositForm').addEventListener('submit', function(e) {
                        console.log('Form submit event triggered');
                        const amount = document.getElementById('amount').value;
                        const minDepo = <?php echo $s0['mindepo']; ?>;
                        const maxDepo = <?php echo $s0['maxdepo']; ?>;
                        const termcondition = document.getElementById('exampleCheck1').checked;

                        console.log('Amount:', amount, 'Min:', minDepo, 'Max:', maxDepo, 'Term:', termcondition);

                        if (!termcondition) {
                            e.preventDefault();
                            alert('Anda harus menyetujui Syarat dan Ketentuan');
                            return false;
                        }

                        if (!amount || amount < minDepo) {
                            e.preventDefault();
                            alert('Minimum deposit adalah Rp ' + minDepo.toLocaleString('id-ID'));
                            return false;
                        }

                        if (amount > maxDepo) {
                            e.preventDefault();
                            alert('Maximum deposit adalah Rp ' + maxDepo.toLocaleString('id-ID'));
                            return false;
                        }

                        // Set nilai nominal hidden field untuk compatibility
                        var nominalHidden = document.getElementById('nominal_hidden');
                        if (nominalHidden) {
                            nominalHidden.value = amount;
                            console.log('Nominal hidden set to:', amount);
                        }

                        if (!confirm('Konfirmasi deposit sebesar Rp ' + parseInt(amount).toLocaleString('id-ID') + '?')) {
                            e.preventDefault();
                            return false;
                        }

                        // Hidden input submit sudah ada di form HTML, pastikan nilainya benar
                        var submitHidden = document.querySelector('input[name="submit"]');
                        if (!submitHidden) {
                            console.log('Submit hidden input not found, creating one...');
                            // Jika tidak ada, tambahkan
                            var submitInput = document.createElement('input');
                            submitInput.type = 'hidden';
                            submitInput.name = 'submit';
                            submitInput.value = '1';
                            this.appendChild(submitInput);
                        } else {
                            // Pastikan nilainya benar
                            submitHidden.value = '1';
                            console.log('Submit hidden input found, value set to:', submitHidden.value);
                        }
                        
                        const submitBtn = document.getElementById('submitBtn');
                        if (submitBtn) {
                            submitBtn.innerHTML = 'Memproses...';
                            submitBtn.disabled = true; // Boleh disable karena hidden input sudah ada
                        }
                        
                        console.log('All validations passed, allowing form submission...');
                        console.log('Form data:', new FormData(this));
                        
                        // Jangan preventDefault - biarkan form submit normal
                        // return true akan membiarkan form submit
                        return true;
                    });
                </script>