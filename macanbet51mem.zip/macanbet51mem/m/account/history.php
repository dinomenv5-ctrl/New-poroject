<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../../config/koneksi.php');

if (!isset($_SESSION['user'])) {
    header("Location: /");
    exit;
}

// ================= SEO DATA (untuk logo dan meta) =================
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);

// ================= USER =================
$user = mysqli_query($conn,"SELECT * FROM tb_user WHERE username='".mysqli_real_escape_string($conn,$_SESSION['user'])."'");
$u = mysqli_fetch_assoc($user);
$userID = (int)$u['cuid'];

// ================= BASE URL =================
if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../../config/url_helper.php');
}
$urlweb = get_active_base_url();

// ================= TOTAL CREDIT & DEBIT =================
$sqlTotal = "
SELECT 
    COALESCE(SUM(CASE WHEN jenis = 1 THEN total ELSE 0 END),0) AS totalCredit,
    COALESCE(SUM(CASE WHEN jenis = 2 THEN total ELSE 0 END),0) AS totalDebit
FROM tb_transaksi
WHERE userID = '$userID'
";
$qTotal = mysqli_query($conn,$sqlTotal);
$dTotal = mysqli_fetch_assoc($qTotal);

// HARD CAST (ANTI NULL)
$totalCredit = (float)($dTotal['totalCredit'] ?? 0);
$totalDebit  = (float)($dTotal['totalDebit'] ?? 0);

include "../header.php";
?>

<div class="container-wrapper acc">
    <div class="container container-box noSidePadding">
        <div class="head-content">
            <div class="row no-gutters">
                <div class="col-12">
                    <ng-content select="app-game-bals"></ng-content>
                </div>
                <div class="col-12 account_menu">
                    <div class="content">
                        <div class="row history">
                            <div class="pb-4 pb-md-0 col-md-8">

<!-- ================= TOTAL VIEW ================= -->
<div class="row total-data text-center">

    <div class="col-xs-4 noSidePadding">
        <div>
            <div>Total Credit</div>
            <div>IDR <?= number_format((float)$totalCredit, 2, ',', '.'); ?></div>
        </div>
    </div>

    <div class="col-xs-4 noSidePadding">
        <div>
            <div>Total Debit</div>
            <div>IDR <?= number_format((float)$totalDebit, 2, ',', '.'); ?></div>
        </div>
    </div>

</div>

<div class="row">
<div class="col-xs-12">
<div class="mat-group">
<input type="text" class="mat-control st_search" required>
<label>Saring</label>
</div>
</div>
</div>

<!-- ================= HISTORY LIST ================= -->
<?php
$sql = "
SELECT t.*, b.akun
FROM tb_transaksi t
LEFT JOIN tb_bank b ON t.metode = b.cuid
WHERE t.userID='$userID' AND t.jenis IN (1,2,7)
ORDER BY t.cuid DESC
";
$q = mysqli_query($conn,$sql);

if(mysqli_num_rows($q)>0):
while($r=mysqli_fetch_assoc($q)):

$nominal = (float)$r['total'];
$jenis   = (int)$r['jenis'];
$status  = (int)$r['status'];

switch($status){
    case 0: $label='label-warning'; $text='In Progress'; break;
    case 1: $label='label-success'; $text='Confirmed'; break;
    case 2: $label='label-danger';  $text='Rejected'; break;
    default:$label='label-default'; $text='Unknown';
}

$bankInfo = $r['akun'] ?? 'QRIS / SYSTEM';
?>

<div class="row no-gutters h-result">
    <div class="col-xs-6 row-head"><?= $r['date']; ?></div>
    <div class="col-xs-6 text-right">
        <span class="label <?= $label; ?>" style="border-radius:10px"><?= $text; ?></span>
    </div>

    <div class="col-xs-6">
        <?= $jenis==1?'Deposit':($jenis==2?'Withdraw':'Promotion Bonus'); ?>
    </div>
    <div class="col-xs-6 text-right">
        IDR <?= number_format((float)$nominal,2,',','.'); ?>
    </div>

    <div class="col-xs-4 row-footer">
        <small>TransID:</small><br><?= $r['kd_transaksi']; ?>
    </div>
    <div class="col-xs-8 row-footer text-right">
        <small><?= $bankInfo; ?></small><br>
        <?= ($status==2?$r['note']:''); ?>
    </div>
</div>

<?php endwhile; else: ?>
<div class="text-center" style="padding: 20px;">Tidak ada data transaksi</div>
<?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "../footer.php"; ?>
