<?php
/**
 * Halaman QRIS Payment - AutoGopay (Member)
 *
 * Menampilkan QR Code AutoGopay untuk di-scan member.
 * Polling status via check_qris_status.php setiap 5 detik.
 * Auto-credit saldo dilakukan oleh webhook callback_autogopay.php.
 */
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../../config/koneksi.php');

$sid = session_id();
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);


if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../../config/url_helper.php');
}
$urlweb = get_active_base_url();


// Cek apakah user sudah login
if (!isset($_SESSION['user'])) {
    header('Location: ' . $urlweb . '/m/?notif=6');
    exit();
}

// ============================================================
// [FIX F] Dukung akses via URL param ?kd=<kd_transaksi>
// Masalah versi lama: data QR hanya tersimpan di $_SESSION['qris_payment'].
// Jika member REFRESH halaman / kembali dari link pending-deposit,
// session kadang kosong -> redirect ke deposit -> member bingung,
// polling berhenti -> saldo terasa "tidak masuk".
// Sekarang: kalau session kosong tapi ada ?kd=, bangun ulang data QR
// dari tb_transaksi + AutoGopay API (getStatus mengembalikan
// qris_string, qr_image, payment_url, expired_at).
// ============================================================
$kdUrlParam = isset($_GET['kd']) ? trim((string)$_GET['kd']) : '';

if ((!isset($_SESSION['qris_payment']) || empty($_SESSION['qris_payment'])) && $kdUrlParam !== '') {
    include_once(__DIR__ . '/../../config/class.autogopay.php');
    include_once(__DIR__ . '/../../function/autocredit_helper.php');

    // Cari transaksi (anti-truncation lookup via helper)
    $trxData = qris_autocredit_find_trx($conn, $kdUrlParam, '');
    $rebuildOk = false;

    if ($trxData) {
        // Ownership: transaksi harus milik user yang login
        $uRow = qris_autocredit_get_user($conn, (int)$trxData['userID']);
        if ($uRow && strcasecmp((string)$uRow['username'], (string)$_SESSION['user']) === 0) {

            $trxStatus = (int)$trxData['status'];
            $kdDb      = (string)$trxData['kd_transaksi'];
            $noteDb    = (string)$trxData['note'];

            if ($trxStatus === 1) {
                // Sudah dibayar & dikredit -> arahkan ke deposit (sukses)
                header('Location: ' . $urlweb . '/m/account/deposit?notif=success');
                exit();
            }
            if ($trxStatus === 2) {
                // Sudah dibatalkan/gagal
                header('Location: ' . $urlweb . '/m/account/deposit?notif=failed');
                exit();
            }

            // Reference penuh dari note (anti-truncation)
            $fullRef = $kdDb;
            if (preg_match('/ORDER:\s*([A-Za-z0-9\-]+)/', $noteDb, $mRef)) {
                $fullRef = $mRef[1];
            }
            $invDb = '';
            if (preg_match('/INVOICE:\s*([A-Za-z0-9\-]+)/', $noteDb, $mInv)) {
                $invDb = $mInv[1];
            }

            // Ambil config + panggil AutoGopay getStatus
            $cfgQ2 = mysqli_query($conn, "SELECT autogopay_apikey, autogopay_apikey2, urlweb, urlweb2 FROM tb_seo WHERE cuid = 1 LIMIT 1");
            $cfg2  = $cfgQ2 ? mysqli_fetch_assoc($cfgQ2) : null;
            if ($cfg2) {
                $currentHost2 = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
                $host2b = !empty($cfg2['urlweb2']) ? parse_url(rtrim($cfg2['urlweb2'], '/'), PHP_URL_HOST) : '';
                $isSite2b = (!empty($host2b) && $currentHost2 === $host2b);
                $apiKey2use = $isSite2b
                    ? (isset($cfg2['autogopay_apikey2']) ? $cfg2['autogopay_apikey2'] : '')
                    : (isset($cfg2['autogopay_apikey']) ? $cfg2['autogopay_apikey'] : '');

                if ($apiKey2use !== '') {
                    try {
                        $ag = new AutoGopay($apiKey2use);
                        $st = $ag->getStatus($fullRef);
                        if (is_array($st) && !empty($st['success']) && isset($st['data'])) {
                            $d = $st['data'];
                            $_SESSION['qris_payment'] = [
                                'qris_data'    => isset($d['qris_string']) ? (string)$d['qris_string'] : '',
                                'amount'       => (int)$trxData['total'],
                                'kd_transaksi' => $kdDb,
                                'trx_id'       => isset($d['invoice']) ? (string)$d['invoice'] : $invDb,
                                'order_id'     => $fullRef,
                                'provider'     => 'autogopay',
                                'payment_url'  => isset($d['payment_url']) ? (string)$d['payment_url'] : '',
                                'qr_image_url' => isset($d['qr_image']) ? (string)$d['qr_image'] : '',
                                'expired_at'   => isset($d['expired_at']) ? (string)$d['expired_at'] : '',
                            ];
                            $rebuildOk = true;
                        }
                    } catch (Exception $e) {
                        // API down -> tetap tampilkan halaman dgn info dasar,
                        // polling tetap jalan (auto-credit tetap bekerja).
                        $_SESSION['qris_payment'] = [
                            'qris_data'    => '',
                            'amount'       => (int)$trxData['total'],
                            'kd_transaksi' => $kdDb,
                            'trx_id'       => $invDb,
                            'order_id'     => $fullRef,
                            'provider'     => 'autogopay',
                            'payment_url'  => '',
                            'qr_image_url' => '',
                            'expired_at'   => '',
                        ];
                        $rebuildOk = true;
                    }
                }
            }
        }
    }

    if (!$rebuildOk) {
        // Transaksi tidak ditemukan / bukan milik user -> kembali ke deposit
        header('Location: ' . $urlweb . '/m/account/deposit');
        exit();
    }
}

// Cek apakah ada data QRIS di session
if (!isset($_SESSION['qris_payment']) || empty($_SESSION['qris_payment'])) {
    header('Location: ' . $urlweb . '/m/account/deposit');
    exit();
}

$qrisData = $_SESSION['qris_payment'];
$qrisContent = $qrisData['qris_data'];
$amount = $qrisData['amount'];
$kd_transaksi = $qrisData['kd_transaksi'];
$trx_id = $qrisData['trx_id'];
$order_id = isset($qrisData['order_id']) ? $qrisData['order_id'] : $kd_transaksi;
$provider = isset($qrisData['provider']) ? $qrisData['provider'] : 'autogopay';
$providerLabel = 'AUTOGOPAY';
$paymentUrl = isset($qrisData['payment_url']) ? $qrisData['payment_url'] : '';
$sessionQrImage = isset($qrisData['qr_image_url']) ? $qrisData['qr_image_url'] : '';

// Generate QR Code image URL
if (!empty($sessionQrImage)) {
    $qrImageUrl = $sessionQrImage;
} else {
    $qrImageUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($qrisContent);
}

include "../header.php";
?>

<div class="container-wrapper acc" style="background-color: black">
    <div class="container container-box noSidePadding">
        <div class="content">
            <div class="box-wrapper plr-15">
                <div class="box-wrapper plr-15">
                    <h4 class="text-center" style="color: gold; margin-top: 20px;">Pembayaran QRIS (<?php echo htmlspecialchars($providerLabel); ?>)</h4>
                    <hr style="border-color: #333;">

                    <div class="row">
                        <div class="col-md-12 text-center">
                            <div class="alert alert-info">
                                <strong>Kode Transaksi:</strong> <?php echo htmlspecialchars($kd_transaksi); ?><br>
                                <strong>Invoice:</strong> <?php echo htmlspecialchars($trx_id); ?><br>
                                <strong>Jumlah:</strong> Rp <?php echo number_format($amount, 0, ',', '.'); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h5 style="color: white; margin-bottom: 20px;">Scan QR Code dengan aplikasi e-wallet atau mobile banking Anda</h5>
                            <div style="background: white; padding: 20px; display: inline-block; border-radius: 10px; margin-bottom: 20px;">
                                <img src="<?php echo htmlspecialchars($qrImageUrl); ?>" alt="QR Code" style="max-width: 300px; width: 100%;">
                            </div>
                            <?php if (!empty($paymentUrl) && preg_match('#^https?://#i', $paymentUrl)) { ?>
                            <div style="margin-bottom: 15px;">
                                <a href="<?php echo htmlspecialchars($paymentUrl); ?>" target="_blank" rel="noopener" class="btn btn-warning">
                                    Buka Halaman Pembayaran
                                </a>
                            </div>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-warning">
                                <strong>Petunjuk:</strong>
                                <ol style="text-align: left; margin-top: 10px;">
                                    <li>Buka aplikasi e-wallet atau mobile banking Anda</li>
                                    <li>Pilih menu Scan QRIS atau QR Code</li>
                                    <li>Scan QR Code di atas</li>
                                    <li>Pastikan nominal sesuai: <strong>Rp <?php echo number_format($amount, 0, ',', '.'); ?></strong></li>
                                    <li>Lakukan pembayaran</li>
                                    <li>Saldo akan otomatis masuk setelah pembayaran berhasil</li>
                                </ol>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12 text-center">
                            <p style="color: #999; font-size: 12px;">
                                QRIS akan expired dalam 20 menit. Jika sudah expired, silakan buat transaksi baru.
                            </p>
                            <p style="color: #999; font-size: 12px;">
                                Transaction ID: <?php echo htmlspecialchars($trx_id); ?>
                            </p>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-12 text-center">
                            <button type="button" class="btn btn-primary" id="btnCheckStatus" onclick="checkPaymentStatus()">
                                Cek Status Pembayaran
                            </button>
                            <a href="<?php echo $urlweb; ?>/m/account/deposit" class="btn btn-secondary">Kembali</a>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <div id="statusMessage" style="display: none;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let checkInterval = null;
let checkCount = 0;
const maxChecks = 600; // Maksimal 10 menit (600 x 1 detik)

function checkPaymentStatus() {
    // Prevent multiple intervals
    if (checkInterval) {
        clearInterval(checkInterval);
        checkInterval = null;
    }

    const btnCheckStatus = document.getElementById('btnCheckStatus');
    const statusMessage = document.getElementById('statusMessage');

    if (!btnCheckStatus || !statusMessage) {
        console.error('Elements not found');
        return;
    }

    btnCheckStatus.disabled = true;
    btnCheckStatus.textContent = 'Memeriksa...';
    statusMessage.style.display = 'block';
    statusMessage.innerHTML = '<div class="alert alert-info">Memeriksa status pembayaran...</div>';

    // Function untuk melakukan check
    function doCheck() {
        checkCount++;

        fetch('<?php echo $urlweb; ?>/function/check_qris_status.php?trx_id=<?php echo urlencode($trx_id); ?>&order_id=<?php echo urlencode($order_id); ?>')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Status check response:', data);

                if (data.success && data.status === 'success') {
                    if (checkInterval) {
                        clearInterval(checkInterval);
                        checkInterval = null;
                    }
                    statusMessage.innerHTML = '<div class="alert alert-success"><strong>Pembayaran Berhasil!</strong><br>Saldo Anda telah ditambahkan. Halaman akan di-refresh dalam 3 detik...</div>';
                    btnCheckStatus.disabled = true;
                    btnCheckStatus.textContent = 'Pembayaran Berhasil';

                    // Clear session dan redirect
                    setTimeout(function() {
                        window.location.href = '<?php echo $urlweb; ?>/m/account/deposit?notif=success';
                    }, 3000);
                } else if (data.success && data.status === 'pending') {
                    statusMessage.innerHTML = '<div class="alert alert-warning">Menunggu pembayaran... (Cek ke-' + checkCount + ')</div>';
                    btnCheckStatus.disabled = false;
                    btnCheckStatus.textContent = 'Cek Status Pembayaran';
                } else if (data.success && data.status === 'failed') {
                    if (checkInterval) {
                        clearInterval(checkInterval);
                        checkInterval = null;
                    }
                    statusMessage.innerHTML = '<div class="alert alert-danger"><strong>Pembayaran Gagal/Kadaluarsa</strong><br>Silakan buat transaksi baru.</div>';
                    btnCheckStatus.disabled = true;
                    btnCheckStatus.textContent = 'Pembayaran Gagal';
                } else {
                    statusMessage.innerHTML = '<div class="alert alert-info">Status: ' + (data.status || 'Pending') + '</div>';
                    btnCheckStatus.disabled = false;
                    btnCheckStatus.textContent = 'Cek Status Pembayaran';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                statusMessage.innerHTML = '<div class="alert alert-danger">Error memeriksa status. Silakan coba lagi.</div>';
                btnCheckStatus.disabled = false;
                btnCheckStatus.textContent = 'Cek Status Pembayaran';
            });

        // Stop checking setelah maxChecks
        if (checkCount >= maxChecks) {
            if (checkInterval) {
                clearInterval(checkInterval);
                checkInterval = null;
            }
            btnCheckStatus.disabled = false;
            btnCheckStatus.textContent = 'Cek Status Pembayaran';
            statusMessage.innerHTML = '<div class="alert alert-warning">Pemeriksaan otomatis dihentikan. Silakan klik tombol untuk mengecek secara manual.</div>';
        }
    }

    // Check pertama kali langsung
    doCheck();

    // Cek status setiap 1 detik (auto-credit instan setelah pembayaran)
    checkInterval = setInterval(doCheck, 1000);
}

// Auto check pertama kali setelah 1 detik
setTimeout(function() {
    checkPaymentStatus();
}, 1000);
</script>

<?php include "../footer.php"; ?>
