<?php
ob_start();
session_start();
include('../../config/koneksi.php');
include('../../config/class.yere.php');

// Menambahkan query SEO agar logo/URL di header muncul
$sql_0 = mysqli_query($conn,"SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);
$urlweb = $s0['urlweb'];

if (!isset($_POST['submit'])) {
    header("Location: auto.php");
    exit();
}

$nominal = $_POST['nominal'];
$postID = $_POST['postID'];
$pay_from = $_POST['pay_from'];
$gameid = $_POST['gameid'];
$username = $_SESSION['user'];

$yere = new RedPay();
$res = $yere->generateQRIS($nominal, $username);

if (!$res['success']) {
    die("Gagal menghubungi provider pembayaran: " . $res['message']);
}

$qris_img = $res['data']['qris_image'];
$trx_id_yere = $res['data']['transaction_id'];
$date = date('Y-m-d H:i:s');

mysqli_query($conn, "INSERT INTO `tb_transaksi` 
    (`kd_transaksi`, `date`, `transaksi`, `total`, `note`, `gameid`, `jenis`, `metode`, `pay_from`, `userID`, `status`) 
    VALUES 
    ('$trx_id_yere', '$date', 'Top Up', '$nominal', 'YerePay Auto Deposit', '$gameid', '1', 'qris', '$pay_from', '$postID', 0)");

include "../header.php"; ?>

<div class="container-wrapper" style="background-color: black; min-height: 100vh; color: white; padding-top: 20px;">
    <div class="container text-center">
        <h3 style="color: gold;">PEMBAYARAN QRIS</h3>
        <p>Silahkan scan kode QR di bawah ini untuk menyelesaikan deposit</p>
        
        <div id="qris-container" style="background: white; padding: 15px; display: inline-block; border-radius: 10px; margin: 20px 0;">
            <img src="<?php echo $qris_img; ?>" alt="QRIS" style="width: 280px; height: 280px;">
        </div>

        <div class="payment-info" style="background: #1a1a1a; padding: 15px; border-radius: 8px; max-width: 400px; margin: 0 auto; text-align: left; border: 1px solid #333;">
            <p><strong>Nominal:</strong> <span class="pull-right">IDR <?php echo number_format($nominal); ?></span></p>
            <p><strong>Trx ID:</strong> <span class="pull-right"><?php echo $trx_id_yere; ?></span></p>
            <p><strong>Status:</strong> <span id="status-text" class="pull-right" style="color: #f39c12;">MENUNGGU PEMBAYARAN</span></p>
        </div>

        <div class="mt-4">
            <button onclick="checkStatus()" class="btn btn-primary btn-block" style="margin-bottom: 10px; background-color: #f39c12; border: none;">CEK STATUS SEKARANG</button>
            <a href="/m/" class="btn btn-secondary btn-block" style="background-color: #333; border: none;">KEMBALI KE BERANDA</a>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function checkStatus() {
        $.ajax({
            url: 'check_transaction.php',
            type: 'GET',
            data: { trx_id: '<?php echo $trx_id_yere; ?>' },
            dataType: 'json',
            success: function(response) {
                if (response.status === 1) {
                    alert('Pembayaran Berhasil! Saldo Anda telah bertambah.');
                    window.location.href = '/m/?notif=8';
                }
            }
        });
    }

    setInterval(checkStatus, 5000);
</script>

<?php include "../footer.php"; ?>