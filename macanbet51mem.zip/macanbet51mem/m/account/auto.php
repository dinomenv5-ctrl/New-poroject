<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../../config/koneksi.php');

$sid = session_id();
$sql_0 = mysqli_query($conn,"SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);
$urlweb = $s0['urlweb'];

if(isset($_SESSION['user'])) {
    $user = mysqli_query($conn,"SELECT * FROM `tb_user` WHERE username = '".$_SESSION['user']."'") or die (mysqli_error());
    $u = mysqli_fetch_array($user);
    $id_user = $u['cuid'];
    $sql_banks = mysqli_query($conn,"SELECT * FROM `tb_bank` WHERE userID = '$id_user'") or die(mysqli_error());
    $sbs = mysqli_fetch_array($sql_banks);
}

include "../header.php";?>
<div class="container-wrapper acc" style="background-color: black">
    <div class="container container-box noSidePadding">
        <div class="content">
            <div class="box-wrapper plr-15">
                <form id="depositForm" action="payment.php" method="post">
                    <input type="hidden" name="postID" value="<?php echo $u['cuid']; ?>">
                    <div class="box-wrapper plr-15">
                        <h4 class="text-center" style="color: gold; margin-top: 20px;">Form Deposit QRIS</h4>
                        <hr style="border-color: #333;">
                        
                        <div class="row d-flex">
                            <div class="col-md-3 col-xs-4"><div class="font-weight-bold"> Metode</div></div>
                            <div class="col-md-9 col-xs-8"><input type="text" class="form-control" value="QRIS OTOMATIS" readonly></div>
                        </div>

                        <div class="row d-flex mt-3">
                            <div class="col-md-3 col-xs-4"><div class="font-weight-bold">Rekening Anda</div></div>
                            <div class="col-md-9 col-xs-8">
                                <select class="form-control" name="pay_from" required>
                                    <option value="<?php echo $sbs['cuid']; ?>"><?php echo $sbs['akun']; ?> - <?php echo $sbs['no_rek']; ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="row d-flex mt-3">
                            <div class="col-md-3 col-xs-4"><div class="font-weight-bold">Pilih Bonus</div></div>
                            <div class="col-md-9 col-xs-8">
                                <select class="form-control" name="gameid">
                                    <option value="">Tanpa Bonus</option>
                                    <?php
                                        $sql_p = mysqli_query($conn, "SELECT * FROM `tb_post` WHERE kategori = 0");
                                        while ($st = mysqli_fetch_array($sql_p)) {
                                            echo '<option value="'.$st['cuid'].'">'.$st['title'].'</option>';
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="row d-flex mt-3">
                            <div class="col-md-3 col-xs-4"><div class="font-weight-bold">Nominal (IDR)</div></div>
                            <div class="col-md-9 col-xs-8">
                                <input type="number" name="nominal" class="form-control" placeholder="Contoh: 20000" min="20000" required>
                            </div>
                        </div>

                        <div class="row d-flex mt-4">
                            <div class="col-md-12">
                                <button type="submit" name="submit" class="btn btn-block" style="background: #f39c12; color: white; font-weight: bold;">LANJUT KE PEMBAYARAN</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include "../footer.php";?>