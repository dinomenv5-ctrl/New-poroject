<?php
$providerCode = isset($_GET['provider']) ? $_GET['provider'] : 'af';
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');
$sid = session_id();

// Ambil data SEO
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error($conn));
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../config/url_helper.php');
}
$urlweb = get_active_base_url();

// Cek Status Maintenance
$sql_m = "SELECT status FROM maintenance WHERE id = 1";
$result_m = $conn->query($sql_m);
if ($result_m->num_rows > 0) {
    $row_m = $result_m->fetch_assoc();
    if ($row_m["status"] == 1) {
        echo "<script>alert('Halaman sedang dalam pemeliharaan. Kembali ke halaman sebelumnya.'); window.history.back();</script>";
        exit();
    }
}

include "../m/header.php";

/**
 * DAFTAR P2P / POKER (ARRAY)
 * Edit bagian ini untuk menambah atau mengubah permainan
 */
$poker_games = [
        [
        'name' => 'Aces and Eights',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTaVwcfrA9F8bb_buehVR4kLqNAKLJQ9MKNZw&usqp=CAU',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=AcesAndEights&providercode=KA',
        'type' => 'link',
        'tag' => 'hot',
        'wrapper' => 'rng'
    ],
    [
        'name' => 'Bonus Poker',
        'img' => 'https://www.getwin.com/images/casino/games/kagaming/bonus-poker/thumbnail.webp',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=BonusPoker&providercode=KA',
        'type' => 'link',
        'tag' => 'hot',
        'wrapper' => ''
    ],
    [
        'name' => 'Lucky Video Poker',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRImK-5zSAxNcZgUjQb9cA2vOzhv1HVdhH2zflIaQ0SrXYxMEANi1bvi-Dn&s=10',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=LuckyVideoPoker&providercode=KA',
        'type' => 'link',
        'tag' => 'hot',
        'wrapper' => ''
    ],
    [
        'name' => 'Super Video Poker',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQG8BGSz9XVf9dYhVP5L6MXoLt4urJN0fr76w&usqp=CAU',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=SuperVideoPoker&providercode=KA',
        'type' => 'link',
        'tag' => 'hot',
        'wrapper' => ''
    ],
    [
        'name' => 'Texas Poker',
        'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_tpoker.jpg',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=6651&providercode=V8',
        'type' => 'maintenance',
        'tag' => 'hot',
        'wrapper' => 'rng'
    ],
    [
        'name' => 'Sakong',
        'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_sakong.jpg',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=6652&providercode=v8',
        'type' => 'maintenance',
        'tag' => 'hot',
        'wrapper' => ''
    ],
    [
        'name' => 'Omaha',
        'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_omaha.jpg',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=6655&providercode=v8',
        'type' => 'maintenance',
        'tag' => 'hot',
        'wrapper' => ''
    ],
    [
        'name' => 'Cemek',
        'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_cemek.jpg',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=6657&providercode=v8',
        'type' => 'maintenance',
        'tag' => 'hot',
        'wrapper' => ''
    ],
    [
        'name' => 'Cemed',
        'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_cemed.jpg',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=6659&providercode=v8',
        'type' => 'maintenance',
        'tag' => 'hot',
        'wrapper' => ''
    ],
    [
        'name' => 'Baccarat',
        'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_baccarat.jpg',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=6665&providercode=v8',
        'type' => 'maintenance',
        'tag' => 'hot',
        'wrapper' => ''
    ],
    // Bagian Maintenance
    ['name' => 'P2P 7', 'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_3cd.jpg?v=4', 'type' => 'maintenance', 'tag' => 'none', 'wrapper' => ''],
    ['name' => 'P2P 8', 'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_dqq.jpg', 'type' => 'maintenance', 'tag' => 'none', 'wrapper' => ''],
    ['name' => 'P2P 9', 'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_13c.jpg', 'type' => 'maintenance', 'tag' => 'none', 'wrapper' => ''],
    ['name' => 'P2P 10', 'img' => 'https://files.sitestatic.net/GameImage/P2PProviders/mobile/normal/poker_sakong.jpg', 'type' => 'maintenance', 'tag' => 'none', 'wrapper' => ''],
];
?>
<div class="container pt-1 games-category">
    <h2 class="title">P2P</h2>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 image-grid">
            
            <?php foreach ($poker_games as $game): ?>
                <div class="col-xs-4 col-sm-3 col-md-2 box">
                    <div class="game-wrapper <?php echo $game['wrapper']; ?>">
                        
                        <?php if ($game['tag'] == 'hot'): ?>
                            <div class="hot-tag"></div>
                        <?php elseif ($game['tag'] == 'live'): ?>
                            <div style="position:absolute;right:0;top:0;z-index: 9;">
                                <img src="https://files.sitestatic.net/images/live_icon.gif" ref="live" height="25px">
                            </div>
                        <?php endif; ?>

                        <?php if ($game['type'] == 'maintenance'): ?>
                            <div class="game maintenance-alert">
                                <img class="img-fluid lazy" alt="<?php echo $game['name']; ?>" data-src="<?php echo $game['img']; ?>" src="" />
                                <div class="loader-b" *ngIf="!showEle"></div>
                                <div class="g-title"></div>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo $game['url']; ?>" rel="opener" class="game" target="_blank">
                                <img class="img-fluid lazy" alt="<?php echo $game['name']; ?>" data-src="<?php echo $game['img']; ?>" src="" />
                                <div class="loader-b" *ngIf="!showEle"></div>
                                <div class="g-title"></div>
                            </a>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endforeach; ?>

        </div>
    </div>
</div>

<?php include "footer.php"; ?>