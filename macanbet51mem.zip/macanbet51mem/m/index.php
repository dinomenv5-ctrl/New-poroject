<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');
$sid = session_id();
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../config/url_helper.php');
}
$urlweb = get_active_base_url();
$urlwebs = $urlweb;

include "header.php";
?>

<?php
error_reporting(0);

$validNotifications = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

if (!empty($_GET['notif']) && in_array($_GET['notif'], $validNotifications)) {
    $popupContent = '';
    $popupIcon = 'info'; // Default icon

    switch ($_GET['notif']) {
        case 1:
            $popupContent = '<strong>Username atau Password Salah</strong>';
            $popupIcon = 'warning';
            break;
        case 2:
            $popupContent = 'Username atau Password Salah';
            $popupIcon = 'warning';
            break;
        case 3:
            $popupContent = 'Username Atau Password Salah!';
            $popupIcon = 'warning';
            break;
        case 4:
            $popupContent = 'Login Berhasil';
            $popupIcon = 'success';
            break;
        case 5:
            $popupContent = 'Logout Berhasil';
            $popupIcon = 'success';
            break;
        case 6:
            $popupContent = 'Silahkan Login Terlebih Dahulu';
            $popupIcon = 'warning';
            break;
        case 7:
            $popupContent = 'Mohon Maaf Halaman / Provider Sedang Maintenance';
            $popupIcon = 'error';
            break;
        case 8:
            $popupContent = 'Permintaan Deposit Berhasil Dikirimkan';
            $popupIcon = 'success';
            break;
        case 9:
            $popupContent = 'Permintaan Penarikan Berhasil Dikirimkan';
            $popupIcon = 'success';
            break;
        case 10:
            $popupContent = 'Mohon Maaf Akun Anda Sedang Terkunci Silahkan Menghubungi Admin / Livechat';
            $popupIcon = 'warning';
            break;
        case 11:
            $popupContent = 'Deposit Berhasil Diterima';
            $popupIcon = 'success';
            break;
        case 12:
            $popupContent = 'Saldo Anda Kurang Dari 1000';
            $popupIcon = 'warning';
            break;
    }

    // Output JavaScript code to show SweetAlert
    echo "
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                Swal.fire({
                    icon: '$popupIcon',
                    title: 'Notification',
                    html: '$popupContent',
                });
            });
        </script>
    ";
}
?>

</script>
<style>
    /*POP-UP MESSAGE WD*/
    .messagebleft-container {
        transition-property: opacity, left;
        transition-duration: 2s, 3s, 6s, 3s;
        transition-property: top, right, bottom, left, opacity;
        font-family: Roboto, sans-serif;
        font-size: 14px;
        min-height: 14px;
        background-color: #070b0e;
        position: fixed;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #fff;
        line-height: 22px;
        padding: 18px 24px;
        bottom: -100px;
        top: -100px;
        opacity: 0;
        z-index: 9999;
    }

    .messagebleft-container .action {
        background: inherit;
        display: inline-block;
        font-size: inherit;
        text-transform: uppercase;
        color: #4caf50;
        margin: 0 0 0 24px;
        padding: 0;
        min-width: min-content;
        cursor: pointer;
    }

    @media (min-width: 640px) {
        .messagebleft-container {
            min-width: 288px;
            max-width: 568px;
            display: inline-flex;
            border-radius: 2px;
            margin: 24px;

        }

    }

    @media (max-width: 640px) {
        .messagebleft-container {
            left: 0;
            right: 0;
            width: 100%;
            margin-bottom: 10px;
            bottom: 10px !imporant;
        }

        .messagebleft-pos.top-left {
            top: 10% !important;
        }
    }

    .messagebleft-pos.bottom-center {
        top: auto !important;
        bottom: 0;
        left: 50%;
        transform: translate(-50%, 0);
    }

    .messagebleft-pos.bottom-left {
        top: auto !important;
        bottom: 0;
        left: 0;
        margin-bottom: 10px;

    }

    .messagebleft-pos.bottom-right {
        top: auto !important;
        bottom: 0;
        right: 0;
    }

    .messagebleft-pos.top-left {
        bottom: auto !important;
        top: 0;
        left: 0;
    }

    .messagebleft-pos.top-center {
        bottom: auto !important;
        top: 0;
        left: 50%;
        transform: translate(-50%, 0);
    }

    .messagebleft-pos.top-right {
        bottom: auto !important;
        top: 0;
        right: 0;
    }

    @media (max-width: 640px) {

        .messagebleft-pos.bottom-center,
        .messagebleft-pos.top-center {
            left: 0;
            transform: none;
        }
    }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<title></title>
<div class="fixed-left" data-v-38a8c498="">
    <main data-v-38a8c498="">
    </main>

</div>


<style>
    .fixed-left[data-v-38a8c498] {
        zoom: .65;
        position: fixed;
        z-index: 99;
        bottom: 90px;
        left: -10px;
        width: 120px;
        padding: 15px 15px 15px 20px;
        background-color: transparent;
        border-radius: 10px;
        border: 3px solid rgba(255, 0, 0, 0);
        transition: .5s ease-in-out;
    }

    .fixed-left a[data-v-38a8c498],
    main {
        display: block;
    }

    .fixed-img-100[data-v-38a8c498],
    .fixed-rtp[data-v-38a8c498],
    .fixed-wa[data-v-38a8c498] {
        width: 100%;
    }

    .fixed-rtp .fixed-apk .fixed-rtp .fixed-vpn [data-v-38a8c498] {
        margin-bottom: 5px;
        /* Properti margin-bottom untuk menambahkan jarak */
    }

    .fixed-rtp .animated[data-v-38a8c498],
    .fixed-wa .animated[data-v-38a8c498] {
        -webkit-animation: 1s ease-in-out infinite alternate zoom-data-v-38a8c498;
        animation: 1s ease-in-out infinite alternate zoom-data-v-38a8c498;
    }

    .fixed-arrow[data-v-38a8c498] {
        position: absolute;
        right: -25px;
        top: 10px;
        bottom: 10px;
        background: linear-gradient(to bottom, #000000 0%, #fdbb2c 50%, #000000 100%);
        width: 25px;
        border-radius: 0 10px 10px 0;
        cursor: pointer;
    }

    .vertical-align-center {
        align-items: center;
    }

    .dflex {
        display: flex !important;
    }

    .justify-content-center {
        justify-content: center !important;
    }

    .fixed-arrow img[data-v-38a8c498] {
        transform: rotate(270deg);
        filter: invert(1);
    }

    .img-xxs {
        height: 20px;
    }

    @media (max-width:1366px) {
        .img-xxs {
            height: 15px;
        }
    }

    .fixed-left.nganu[data-v-38a8c498] {
        left: -110px;
    }
</style>
</script>

<div class="apk-down-bar" id="apk-down-bar" style="display:none;">
    <table>
        <tr>
            <td rowspan="2" style="width:18%; " class="clearfix">
                <button class="btn btn-link" id="btn-close--apk">X</button>
                <span class="fs-lg android-wrap"><i class="icon-android"></i></span>
            </td>
            <td style="width:100%; ">
                <div><?php echo $s0['instansi']; ?> Lite Download</div>

            </td>
            <td rowspan="2">
                <a href="#" class="btn btn-link">
                    <i class="icon-download" style="font-size:1.8em;"></i>
                </a>
            </td>
        </tr>
        <tr>
            <td>
                <div><small>Fast, Light & Secure</small></div>
            </td>
        </tr>
    </table>
</div>

<section class="carousel-fixed-height">
    <div id="carousel-fixed-height" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php
            $sql_21 = mysqli_query($conn, "SELECT * FROM `tb_slide` ORDER BY sort ASC") or die(mysqli_error());
            $nos = 0;
            while ($s21 = mysqli_fetch_array($sql_21)) {
                $nos++;
                $a = $nos - 1;
            ?>
                <li data-target="#carousel-fixed-height" data-slide-to="<?php echo $a; ?>" <?php if ($nos == 1) {
                                                                                                echo ' class="active"';
                                                                                            } ?>></li>
            <?php } ?>
        </ol>
        <div class="carousel-inner" role="listbox">
            <?php
            $sql_2 = mysqli_query($conn, "SELECT * FROM `tb_slide` ORDER BY sort ASC") or die(mysqli_error());
            $nos = 0;
            while ($s2 = mysqli_fetch_array($sql_2)) {
                $nos++;
            ?>
                <div class="item <?php if ($nos == 1) {
                                        echo 'active';
                                    } ?>">
                    <a href="#">
                        <img class="slider-size" src="<?php echo $s2['image']; ?>"
                            style="display: block; width: 100%; max-height: 500px;  min-height: 130px;" alt="Slide">
                    </a>
                </div>
            <?php } ?>
        </div>
        <a class="left carousel-control" href="#carousel-fixed-height" role="button" data-slide="prev">
            <span class="fas fa-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-fixed-height" role="button" data-slide="next">
            <span class="fas fa-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var swiper = new Swiper('#carousel-fixed-height', {
                loop: true, // Enable continuous loop
                autoplay: {
                    delay: 2000, // Time in milliseconds between slides
                },
                pagination: {
                    el: '.carousel-indicators',
                    clickable: true,
                },
                navigation: {
                    nextEl: '.carousel-control.right',
                    prevEl: '.carousel-control.left',
                },
            });
        });
    </script>
</section>
<!-- Check if the user is not logged in -->
<?php if (!isset($_SESSION['user'])) { ?>
    <div class="btns-log row no-gutters">
        <div class="col-xs-6">
            <button type="button" class="btn btn-tertiery btn-block" id="btnLogin--home">LOGIN</button>
        </div>
        <div class="col-xs-6">
            <a class="btn btn-accent btn-block" href="<?php echo $urlweb; ?>/m/register">DAFTAR</a>
        </div>
    </div>
<?php } ?>

<!-- END Login Buttons-->
<div class="container">
    <div class="ann-wrapper">
        <div class="clearfix pt-2">
            <div class="pull-left pointer">
                <div>
                    <i class="icon-megaphone"></i>
                </div>
            </div>
            <div class="ann-content">
                <marquee scrollamount="5">
                    <?php echo $s0['news']; ?>
                </marquee>
            </div>
        </div>
    </div>
</div>
<!--Shorcut Menu -->
<div class="scroll-wrapper no-gutters" _home>
    <div style="overflow:hidden; " class="scroller">
        <div class="  no-gutters text-center slider-content" #scrollContent>
            <!--//hardcoded links.......-->
            <div class="col">
                <a class="btn-box" href="<?php echo $urlweb; ?>/m/slots/">
                    <i class="icon-slot"></i>
                    <div>SLOTS</div>
                    <span class='hot'>HOT</span>
                </a>
            </div>
            <div class="col">
                <a class="btn-box" href="<?php echo $urlweb; ?>/m/live/">
                    <img src="https://files.sitestatic.net/images/live_game_icon.gif?v=1" alt="Live Games" width="44" height="44">
                    <div>LIVE GAMES</div>
                    <span class='hot'>HOT</span>
                </a>
            </div>
            <div class="col">
                <a class="btn-box" href="<?php echo $urlweb; ?>/m/sports/">
                    <i class="icon-soccer"></i>
                    <div>SPORTS</div>
                </a>
            </div>
            <div class="col">
                <a class="btn-box" href="<?php echo $urlweb; ?>/m/casino/">
                    <i class="icon-casino"></i>
                    <div>CASINO</div>
                    <span class="hot new ">PROMO</span>
                </a>
            </div>
            <div class="col">
                <a class="btn-box" href="<?php echo $urlweb; ?>/m/lottery/">
                    <i class="icon-lottery"></i>
                    <div>LOTRE</div>
                </a>
            </div>
            <div class="col">
                <a class="btn-box" href="<?php echo $urlweb; ?>/m/poker/">
                    <i class="icon-menu-poker-01"></i>
                    <div>P2P</div>
                </a>
            </div>
            <div class="col">
                <a class="btn-box" href="<?php echo $urlweb; ?>/m/fish-hunter/">
                    <i class="icon-fish_hunter"></i>
                    <div>TEMBAK IKAN</div>
                </a>
            </div>
            <div class="col">
                <a class="btn-box" href="<?php echo $urlweb; ?>/m/e-games/">
                    <i class="icon-others"></i>
                    <div>E-GAMES</div>
                    <span class="hot new ">NEW</span>
                </a>
            </div>
        </div>
    </div>

</div>
<div class="app-wrapper container">
    <div class="jackpot">
        <img class="img-fluid" src="https://cdn.robotaset.com/assets/tpl/c78a74fc9e/images/progressive-jackpot-small.gif"
            alt="jackpot" />
        <div class="txt-overlay">
            <div class="text-content">
                <span id="jackpot_amount">...Loading</span>
            </div>
        </div>
    </div>
    <div class="mobile-border"></div>
    <div class="row">
        <div class="gListSection">

            <div class="g-slider-wrapper">
                <h4 class="title">GAME TERPOPULAR</h4>
                <ul>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=pr" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Gates of Olympus" src="" alt="Gates of Olympus" data-src="https://files.sitestatic.net/games/i/220x220/0f24ad48867a50ce331205dc4d1d9d30.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Super Mahjong</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=pr" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Gates of Olympus 1000" src="" alt="Gates of Olympus 1000" data-src="https://files.sitestatic.net/games/i/220x220/12aba443526306c47646afa82d84ba46.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Gates of Olympus Super Scater</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=pr" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Starlight Princess" src="" alt="Starlight Princess" data-src="https://files.sitestatic.net/games/i/220x220/c957cd96f3779941ca5755ad5a3e9af0.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Starlight Princess</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=pr" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Starlight Princess 1000" src="" alt="Starlight Princess 1000" data-src="https://files.sitestatic.net/games/i/220x220/220106934a3dcdf7fc45d13bf8c3cbe5.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Starlight Princess 1000</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=pr" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Sweet Bonanza" src="" alt="Sweet Bonanza" data-src="https://files.sitestatic.net/games/i/220x220/cf7fdad8713f88703071adaf9a189b74.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Sweet Bonanza</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=PG" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Mahjong Ways 2" src="" alt="Mahjong Ways 2" data-src="https://files.sitestatic.net/games/i/220x220/f24e33352829cf3475df062f42e059ef.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Mahjong Ways 2</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=PG" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Mahjong Ways" src="" alt="Mahjong Ways" data-src="https://files.sitestatic.net/games/i/220x220/531e9d0cd776c15906ce761bb56f90ae.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Mahjong Ways</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=PG" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Lucky Neko" src="" alt="Lucky Neko" data-src="https://files.sitestatic.net/games/i/220x220/9a43da1342aca190cb05be8886f44821.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Lucky Neko</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=PG" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Wild Bandito" src="" alt="Wild Bandito" data-src="https://files.sitestatic.net/games/i/220x220/9c9f5f5160abe569deada38af4f5fc7c.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Wild Bandito</div>

                        </a>
                    </li>
                    <li style=" margin-top: 5px;
            margin-left: 5px;">
                        <a href="<?= $mainURL ?>slots/game/?provider=pr" class="game-box" rel="opener">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <div class="hot-game-tag"> </div>
                            <img class="lazy" alt="Spaceman" src="" alt="Spaceman" data-src="https://files.sitestatic.net/games/i/220x220/f03057338930b460b32db17061e57680.webp" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Spaceman</div>

                        </a>
                    </li>
                </ul>
            </div>
            <!--games-slider-->

            <div class="mobile-border"></div>
            <div class="g-slider-wrapper">
                <h4 class="title">slots</h4>
                <ul>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="PRAGMATIC" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_pp.jpg?v=11.2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">PRAGMATIC</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="REEL KINGDOM" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/reel_kingdom.png?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">REEL KINGDOM</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="PGSOFT" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_pgsoft.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">PGSOFT</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="JOKER" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_joker.jpg?v=9.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">JOKER</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="PLAYTECH" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_pt.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">PLAYTECH</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="HABANERO" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_haba.jpg?v=9.2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">HABANERO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="SPADE GAMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_sg.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">SPADE GAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="HACKSAW" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/Hacksaw_Game_Slot.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">HACKSAW</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="RELAXGAMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/relax.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">RELAXGAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="TOP TREND" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_ttg.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">TOP TREND</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="MICROGAMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_mg.jpg?v=12" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">MICROGAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="PLAYNGO" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_png.jpg?v=9.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">PLAYNGO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="SKYWIND" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/skywind.png?v=1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">SKYWIND</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="YGG" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_ygg.jpg?v=1.0" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">YGG</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="BOOMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_booming.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">BOOMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="BNG" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/booongo.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">BNG</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="FASTSPIN" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/fastspin.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">FASTSPIN</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="CQ9" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_cq9.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">CQ9</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="EVOPLAY" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/evoplay.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">EVOPLAY</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="PLAYSTAR" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/playstar.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">PLAYSTAR</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="NOLIMITCITY" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/nolimitcity.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">NOLIMITCITY</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="MANCALA GAMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/mancalagaming.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">MANCALA GAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="EA GAMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/eagaming.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">EA GAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="RED TIGER" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/redtiger.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">RED TIGER</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="NETENT" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/netent.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">NETENT</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="SBO" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/sbo_slot.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">SBO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="DRAGOON SOFT" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/dragoon_soft.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">DRAGOON SOFT</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="KA GAMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/KA_Gaming_Slot.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">KA GAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="NAGAGAMES" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/naga_gaming_slot.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">NAGAGAMES</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="REEVO" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/reevo.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">REEVO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="LIVE22" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/live22.jpg?v=0.3" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">LIVE22</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="APOLLO777" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/apollo777.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">APOLLO777</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="FACHAI" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/slot_fa_chai.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">FACHAI</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="ADVANTPLAY" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/advantplay_slot.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">ADVANTPLAY</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="BGAMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/bgaming.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">BGAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="JILI" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/jili.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">JILI</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="JDB" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/jdb_slot.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">JDB</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="i8" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/i8.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">i8</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="GMW" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/gmw.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">GMW</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>slots/" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="DODO GAMING" src="" data-src="https://files.sitestatic.net/GameImage/SlotsProviders/thumbnail/normal/dodo_slot.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">DODO GAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                </ul>
            </div>
            <div class="mobile-border"></div>
            <div class="g-slider-wrapper">
                <h4 class="title">LIVE GAMES</h4>
                <ul>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/12D.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">12D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" src="" data-src="https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/24D.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">24D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" src="" data-src="https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/36D.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">36D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" src="" data-src="https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/60D.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">60D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" src="" data-src="https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/sicbo.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Sicbo</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" src="" data-src="https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/oglokball.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Oglok</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/MPO_Number.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">LV NUMBER GAME</div>
                        </div>

                    </li>
                    <li>
                        <a href="<?php echo $urlweb; ?>/gameplay/opengame/?gamecode=7503&providercode=S6" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="sv388 Cock fight" src="" data-src="https://files.sitestatic.net/GameImage/CFProviders/thumbnail/normal/cock_sv388.jpg?v=1.0" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">sv388 Cock fight</div>
                            <!--</ng-container> -->
                        </a>
                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" src="" data-src="https://files.sitestatic.net/GameImage/CFProviders/mobile/normal/ws168_cf.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">WS168</div>
                        </div>

                    </li>
                </ul>
            </div>

            <div class="mobile-border"></div>
            <div class="g-slider-wrapper">
                <h4 class="title">sports</h4>
                <ul>
                    <li>


                        <a href="<?= $mainURL ?>sports" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="CMDS" src="" data-src="https://files.sitestatic.net/GameImage/SportsProviders/thumbnail/normal/cmd_sport.jpg?v=1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">AFB SPORTS</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>sports" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="WBET" src="" data-src="https://files.sitestatic.net/GameImage/SportsProviders/thumbnail/normal/sport_wbet.png?v=1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">WBET</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>sports" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Saba Sports" src="" data-src="https://files.sitestatic.net/GameImage/SportsProviders/thumbnail/normal/ibc_sport.jpg?v=2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Saba Sports</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>sports" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="SBO" src="" data-src="https://files.sitestatic.net/GameImage/SportsProviders/thumbnail/normal/sport_sbo.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">SBO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>sports" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="UG" src="" data-src="https://files.sitestatic.net/GameImage/SportsProviders/thumbnail/normal/sport_ug.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">UG</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>sports" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="BTI" src="" data-src="https://files.sitestatic.net/GameImage/SportsProviders/thumbnail/normal/sport_bti.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">BTI</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>sports" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="BETER ESPORT" src="" data-src="https://files.sitestatic.net/GameImage/SportsProviders/thumbnail/normal/sport_beter.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">BETER ESPORT</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                </ul>
            </div>

            <div class="mobile-border"></div>
            <div class="g-slider-wrapper">
                <h4 class="title">casino</h4>
                <ul>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="PRAGMATIC" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_pp.jpg?v=16.2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">PRAGMATIC</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="EVO" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_evo.jpg?v=11" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">EVO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="AG" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_ag.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">AG</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/maintenance/casino_ab.jpg?v=9" *ngIf="showEle" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">ALLBET</div>
                        </div>

                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="AE SEXY" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_sb.jpg?v=9.5" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">AE SEXY</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="BIG GAMING CASINO" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_big.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">BIG GAMING CASINO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="568win" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_568win.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">568win</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="SKYWIND" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_skywind.jpg?v=1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">SKYWIND</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="MICROGAMING" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_mg.jpg?v=10" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">MICROGAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="DREAM GAMING" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_dreamgame.jpg?v=1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">DREAM GAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="EZUGI" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/ezugi_casino.png?v=1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">EZUGI</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="OPUS" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_opus.jpg?v=1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">OPUS</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="LG88" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/lg88_casino.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">LG88</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="WM CASINO" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/casino_wm.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">WM CASINO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>casino/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="W CASINO" src="" data-src="https://files.sitestatic.net/GameImage/CasinoProviders/thumbnail/normal/w_casino.png?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">W CASINO</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                </ul>
            </div>
            <div class="mobile-border"></div>
            <div class="g-slider-wrapper">
                <h4 class="title">LOTRE</h4>
                <ul>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4d_amazon.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Amazon 4D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4d_king.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">King 4D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4d_hongkong_grand.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Hongkong Grand 4D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4d_shanghai_hero.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Shanghai Hero 4D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4D_singapore_pools.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Singapore Pools 4D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4D_malaysia_toto.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Toto Singapore Pools</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4D_malaysia_magnum.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Malaysia Magnum 4D</div>
                        </div>

                    </li>
                    <li>
                        <div class="game-box maintenance-alert">
                            <img class="lazy" alt="" src="" data-src="https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4D_malaysia.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Malaysia Damacai 4D</div>
                        </div>

                    </li>
                    <li>


                        <a href="<?php echo $urlweb; ?>/gameplay/opengame/?gamecode=2920&providercode=QK" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Cai Shen Bingo" src="" data-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSju3T7o_tkkM4KBB_8HaEIVoP0gowHjkJT9RnFc1WnBA&s=10" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Qq Keno</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                </ul>
            </div>

            <div class="mobile-border"></div>
            <div class="g-slider-wrapper">
                <h4 class="title">poker</h4>
                <ul>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Texas Poker" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_tpoker.jpg?v=2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Texas Poker</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Poker Dealer" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_omaha.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Poker Dealer</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Domino QQ" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_dqq.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Domino QQ</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Ceme Take Turn" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_cemek.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Ceme Take Turn</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Ceme Dealer" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_cemed.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Ceme Dealer</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="13 Cards" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_13c.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">13 Cards</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="13 Cards Dealer" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_13cd.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">13 Cards Dealer</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Baccarat Dealer" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_baccarat.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Baccarat Dealer</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Sakong" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_sakong.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Sakong</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Ceme Adu" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/ceme-adu.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Ceme Adu</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="3 Cards Dealer" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_3cd.jpg?v=4" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">3 Cards Dealer</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>poker/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="3 Cards" src="" data-src="https://files.sitestatic.net/GameImage/P2PProviders/thumbnail/normal/poker_3c.jpg?v=4" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">3 Cards</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                </ul>
            </div>

            <div class="mobile-border"></div>
            <div class="g-slider-wrapper">
                <h4 class="title">tembak ikan</h4>
                <ul>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="SKYWIND" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/fishing_skywind.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">SKYWIND</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="SPADE GAMING" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/fishing_spade.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">SPADE GAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="CQ9" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/fishing_cq9.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">CQ9</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="JOKER" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/fishing_joker.jpg?v=9" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">JOKER</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="PLAYSTAR" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/playstar.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">PLAYSTAR</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="DRAGOON SOFT" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/fishing_dragoonsoft.jpg?v=1.0" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">DRAGOON SOFT</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="KA GAMING" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/KA_Gaming_Fishing.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">KA GAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="FASTSPIN" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/fastspin.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">FASTSPIN</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="KSGAMING" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/ksgaming.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">KSGAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="LIVE22" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/live22.jpg?v=0.3" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">LIVE22</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="FACHAI" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/fishing_fa_chai.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">FACHAI</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="JILI" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/jili.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">JILI</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="JDB" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/jdb_fishing.png" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">JDB</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>fish-hunter" class="game-box">
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="i8" src="" data-src="https://files.sitestatic.net/GameImage/FishingProviders/thumbnail/normal/i8.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">i8</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                </ul>
            </div>

            <div class="mobile-border"></div>
            <div class="g-slider-wrapper">
                <h4 class="title">e-games</h4>
                <ul>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Bola Tangkas 5C" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/rng_bt.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Bola Tangkas 5C</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Classic Bola Tangkas 5C" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/rng_cbt.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Classic Bola Tangkas 5C</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Ultimate Keno" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/rng_ukeno.jpg?v=2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Ultimate Keno</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Classic Keno 8" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/rng_ckeno8.jpg?v=2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Classic Keno 8</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Classic Keno 10" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/rng_ckeno15.jpg?v=3.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Classic Keno 10</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Caribbean Stud Poker" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/rng_cpoker.jpg?v=2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Caribbean Stud Poker</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Baccarat" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/rng_baccarat.jpg?v=2" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Baccarat</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Baccarat" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/baccarat.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Baccarat</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Multihand Blackjack" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/multihand_blackjack.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Multihand Blackjack</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="American Blackjack" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/american_blackjack.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">American Blackjack</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Dragon Tiger" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/dragon_tiger.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Dragon Tiger</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Dragon Bonus Baccarat" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/slot_prag_dragon.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Dragon Bonus Baccarat</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Roulette" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/slot_prag_roulette.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Roulette</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Spaceman" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/spaceman.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Spaceman</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="Big Bass Crash" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/big-bass-crash.jpg?v=0.1" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">Big Bass Crash</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="KSGAMING" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/ksgaming.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">KSGAMING</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="JILI" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/jili.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">JILI</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                    <li>


                        <a href="<?= $mainURL ?>e-games/" class="game-box" target=_blank>
                            <!--[ngTemplateOutlet]="gameItemContent"> -->
                            <img class="lazy" alt="GEMINI" src="" data-src="https://files.sitestatic.net/GameImage/RngProviders/thumbnail/normal/gemini.jpg" />
                            <!--TODO alt text-->
                            <div class="loader-b" *ngIf="!showEle"></div>
                            <div class="text-center game-title">GEMINI</div>
                            <!--</ng-container> -->
                        </a>


                    </li>
                </ul>
            </div>
            <!--games-slider END-->
        </div>
    </div>
    <section class="common-section">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <!-- Last deposit -->
                <div class="lw-horizontal-slider lates-deposit-section">
                    <div class="text-center">
                        <div class="title-wrapper ">
                            <h4 class="common-title text-center"><span
                                    class="ovo-game-heading ovo-game-heading-color Poppins-font ">Setoran
                                    Terakhir</span></h4>
                        </div>
                    </div>
                    <div class="g-slider-wrapper trx-slider-y gradient-bg">
                        <div class="flex-display lw-loop-content">
                            <ul style="position: absolute;" id="list-container-deposit" data-count="20">
                                <!-- Daftar akan ditambahkan secara dinamis di sini -->
                            </ul>
                        </div>

                        <script>
                            // Skrip untuk menambahkan item setoran acak
                            function getRandomDepositData() {
                                // Fungsi ini menghasilkan data deposit acak
                                const names = ["Budi", "Susi", "Joko", "Lina", "Dewi", "Andi", "Rina", "Adi", "Rudi",
                                    "Putri", "Dian", "Ani", "Dedi", "Lia", "Agus", "Sari", "Rina", "Agung", "Fitri",
                                    "Hadi"
                                ];
                                const amounts = ["IDR 50K", "IDR 25K", "IDR 30K", "IDR 100K"];
                                const randomNameIndex = Math.floor(Math.random() * names.length);
                                const originalName = names[randomNameIndex];

                                // Ubah nama dengan menambahkan karakter acak di tengah
                                const firstHalf = originalName.substring(0, Math.floor(originalName.length / 2));
                                const secondHalf = originalName.substring(Math.floor(originalName.length / 2));
                                const newName = firstHalf + "***********";

                                const randomAmount = amounts[Math.floor(Math.random() * amounts.length)];
                                const date = new Date();
                                const randomDate =
                                    `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
                                return {
                                    name: newName,
                                    amount: randomAmount,
                                    date: randomDate
                                };
                            }

                            function addRandomDepositItems() {
                                const listContainer = document.getElementById('list-container-deposit');
                                const itemCount = parseInt(listContainer.dataset.count);

                                for (let i = 0; i < itemCount; i++) {
                                    const depositData = getRandomDepositData();

                                    const depositListItem = document.createElement('li');
                                    depositListItem.innerHTML = `
                <div class="flex-start  LW-div">
                    <div>
                        <img class="wd-item__avatar lazy ui avatar image"
                            data-src="https://files.sitestatic.net/AvatarImages/lw_avathar_circle.png"
                            src="">
                    </div>
                    <div class="flex-space-btw">
                        <div>
                            <span class="flex-display lato-font LW-font fw-bold">
                                ${depositData.name} </span>
                            <span class="flex-display lato-font LW-date-font">
                                Deposit, ${depositData.date}</span>
                        </div>
                        <span class="LW-btn lato-font LW-date-fontCurrency">
                            ${depositData.amount} </span>
                    </div>
                </div>
            `;
                                    listContainer.appendChild(depositListItem);
                                }
                            }

                            addRandomDepositItems();
                        </script>


                    </div>
                </div>
                <div class="lw-horizontal-slider ">
                    <div class="text-center">
                        <div class="title-wrapper ">

                            <h4 class="common-title text-center"><span
                                    class="ovo-game-heading ovo-game-heading-color Poppins-font ">Penarikan
                                    Terakhir</span></h4>

                        </div>
                    </div>

                    <div class="g-slider-wrapper  trx-slider-y gradient-bg">

                        <div class="flex-display lw-loop-content">
                            <ul style="position: absolute;" id="list-container" data-count="20">
                                <!-- Daftar akan ditambahkan secara dinamis di sini -->
                            </ul>
                        </div>

                        <script>
                            function getRandomData() {
                                // Fungsi ini menghasilkan data acak
                                const names = ["John", "Jane", "Alice", "Bob", "Charlie", "David", "Emily", "Frank",
                                    "Grace", "Henry"
                                ];
                                const amounts = ["IDR 50K", "IDR 100K", "IDR 200K", "IDR 500K"];
                                const randomNameIndex = Math.floor(Math.random() * names.length);
                                const originalName = names[randomNameIndex];

                                // Ubah nama dengan menambahkan karakter acak di tengah
                                const firstHalf = originalName.substring(0, Math.floor(originalName.length / 2));
                                const secondHalf = originalName.substring(Math.floor(originalName.length / 2));
                                const newName = firstHalf + "********";

                                const randomAmount = amounts[Math.floor(Math.random() * amounts.length)];
                                const date = new Date();
                                const randomDate =
                                    `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
                                return {
                                    name: newName,
                                    amount: randomAmount,
                                    date: randomDate
                                };
                            }

                            function addRandomListItems() {
                                const listContainer = document.getElementById('list-container');
                                const itemCount = parseInt(listContainer.dataset.count);

                                for (let i = 0; i < itemCount; i++) {
                                    const data = getRandomData();
                                    const listItem = document.createElement('li');
                                    listItem.innerHTML = `
                    <div class="flex-start  LW-div">
                        <div>
                            <img class="wd-item__avatar lazy ui avatar image"
                                data-src="https://files.sitestatic.net/AvatarImages/lw_avathar_circle.png"
                                src="">
                        </div>
                        <div class="flex-space-btw">
                            <div>
                                <span class="flex-display lato-font LW-font fw-bold">
                                    ${data.name} </span>
                                <span class="flex-display lato-font LW-date-font LW-date-fontWithdraw">
                                    Withdraw, ${data.date}</span>
                            </div>
                            <span class="LW-btn lato-font">
                                ${data.amount} </span>
                        </div>
                    </div>
                `;
                                    listContainer.appendChild(listItem);
                                }
                            }

                            addRandomListItems();
                        </script>
                    </div>
                </div>
                <!--END Last withdraw -->

                <!--home info-->
                <div class="app-info row">

                    <div class="col-md-6 col-lg-4 col-xs-12 gradient-border mobile-border">
                        <h4 class="title">KELEBIHAN LAYANAN</h4>
                        <div class="ml-md-2 mt-2 ">
                            <div class="row center no-gutters">
                                <div class="col-xs-8">
                                    <div class="fs-md">DEPOSIT</div>
                                    <div>Waktu rata-rata</div>
                                </div>
                                <div class="col-xs-4 text-right">
                                    <div class="mb-0 progressNumber">1<span class="fs-sm">Mins</span></div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" style="width: 1%" aria-valuenow="1" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3 center no-gutters">
                                <div class="col-xs-8">
                                    <div class="fs-md">WITHDRAW</div>
                                    <div>Waktu rata-rata</div>
                                </div>
                                <div class="col-xs-4 text-right">
                                    <div class="mb-0 progressNumber">3<span class="fs-sm">Mins</span></div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" style="width: 3%" aria-valuenow="3" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 fs-sm">
                                *Referensi Waktu Rata-rata tidak berlaku jika bank offline, gangguan koneksi, dan informasi yang tidak lengkap disediakan </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xs-12 gradient-border mobile-border">
                        <h4 class="title">JENIS PERMAINAN</h4>

                        <section class="carousel-fixed-height">
                            <div id="pagination-info" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li data-target="#pagination-info" data-slide-to="0" class="active">
                                    </li>
                                    <li data-target="#pagination-info" data-slide-to="1" class="">
                                    </li>
                                </ol>

                                <div class="carousel-inner" role="listbox">
                                    <div class="item active">

                                        <div class="d-block mb-3 pointer text-left">
                                            <div class="mb-0 font-weight-bold">1G POKER</div>
                                            <div style="white-space: normal;">Tuan rumah hingga 10 game P2P luar biasa dengan pemain sungguhan dan tanpa bot. </div>
                                        </div>

                                        <div class="d-block mb-3 pointer text-left">
                                            <div class="mb-0 font-weight-bold">TEMBAK IKAN</div>
                                            <div style="white-space: normal;">Game memancing yang sangat sederhana namun mengasyikkan, petualangan dengan banyak fitur yang akan dinikmati banyak orang. </div>
                                        </div>

                                        <div class="d-block mb-3 pointer text-left">
                                            <div class="mb-0 font-weight-bold">SLOTS</div>
                                            <div style="white-space: normal;">Lebih dari 10 merek slot terkenal untuk dipilih dengan lebih dari 1000+ permainan slot dengan sistem suara dan grafik yang realistis. </div>
                                        </div>

                                    </div>
                                    <div class="item">

                                        <div class="d-block mb-3 pointer text-left">
                                            <div class="mb-0 font-weight-bold">SPORTSBOOK</div>
                                            <div style="white-space: normal;">Ribuan peluang setiap hari untuk semua jenis taruhan olahraga di seluruh dunia. </div>
                                        </div>

                                        <div class="d-block mb-3 pointer text-left">
                                            <div class="mb-0 font-weight-bold">RNG</div>
                                            <div style="white-space: normal;">Menangkan lebih banyak dengan bertaruh dengan lebih banyak pilihan nomor di keno klasik dan pamungkas kami! </div>
                                        </div>

                                        <div class="d-block mb-3 pointer text-left">
                                            <div class="mb-0 font-weight-bold">LIVE CASINO</div>
                                            <div style="white-space: normal;">Rasakan pengalaman dan sensasi bermain seperti kasino yang sebenarnya </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </section>

                    </div>
                    <div class="col-md-6 col-lg-4 col-xs-12 gradient-border mobile-border">

                        <h4 class="title">PUSAT INFO</h4>
                        <div class="ml-md-3 mt-md-4">
                            <div class="pointer mb-md-4 mb-3"><a class="flex" href="<?= $mainURL ?>faq-general"><i class="i-stop icon-stop2"></i>&nbsp;&nbsp; <div>Cara Bermain SportsBook</div> &nbsp;</a></div>
                            <div class="pointer mb-md-4 mb-3"><a class="flex" href="<?= $mainURL ?>faq-general"><i class="i-stop icon-stop2"></i>&nbsp;&nbsp; <div>Cara Melakukan Deposit</div> &nbsp;</a></div>
                            <div class="pointer "><a class="flex" href="<?= $mainURL ?>faq-general"><i class="i-stop icon-stop2"></i>&nbsp;&nbsp; <div>Cara Melakukan Withdraw</div> &nbsp;</a></div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xs-12 gradient-border mobile-border">
                        <h4 class="title">KONTAK LAYANAN PELANGGAN</h4>
                        <section class="carousel-fixed-height">
                            <div id="pagination-contacts" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li data-target="#pagination-contacts" data-slide-to="0"
                                        class="active" style="margin-right:5px"></li>
                                    <li data-target="#pagination-contacts" data-slide-to="1"
                                        class="" style="margin-right:5px"></li>
                                </ol>

                                <div class="carousel-inner member-service" role="listbox">

                                    <div class="item active">
                                        <div class="content-item"><a class="d-block clearfix  mb-3 " href="https://direct.lc.chat/<?php echo $sc['lc_mobile']; ?>" target="_blank">
                                                <div class="row no-gutters text-center text-lg-left">
                                                    <div class="col-xs-12 col-lg-3 ">
                                                        <i class="icon-comment"></i>
                                                    </div>
                                                    <div class="col-xs-12 col-lg-6 mobile-text">
                                                        <div class="mb-0 font-weight-bold">Obrolan Langsung</div>
                                                        <div>Klik disini</div>
                                                    </div>
                                                </div>
                                            </a></div>
                                        <div class="content-item"> <a class="d-block clearfix  mb-3" href="javascript:void(0)" target="_blank">
                                                <div class="row no-gutters text-center text-lg-left">
                                                    <div class="col-xs-12 col-lg-3">
                                                        <i class="icon-phone"></i>
                                                    </div>
                                                    <div class="col-xs-12 col-lg-6 mobile-text">
                                                        <div class="mb-0 font-weight-bold">HOTLINE</div>
                                                        <div><?php echo $wa; ?></div>
                                                    </div>
                                                </div>
                                            </a></div>
                                        <div class="content-item"> <a class="d-block clearfix  mb-3" href="https://api.whatsapp.com/send?phone=+<?php echo $wa; ?>" target="_blank">
                                                <div class="row no-gutters text-center text-lg-left">
                                                    <div class="col-xs-12 col-lg-3">
                                                        <i class="icon-whatsapp"></i>
                                                    </div>
                                                    <div class="col-xs-12 col-lg-6 mobile-text">
                                                        <div class="mb-0 font-weight-bold">WHATSAPP</div>
                                                        <div><?php echo $wa; ?></div>
                                                    </div>
                                                </div>
                                            </a></div>
                                    </div>
                                    <div class='item'>
                                        <div class="content-item"> <a class="d-block clearfix  mb-3" href="https://www.facebook.com/" target="_blank">
                                                <div class="row no-gutters text-center text-lg-left">
                                                    <div class="col-xs-12 col-lg-3">
                                                        <i class="icon-facebook"></i>
                                                    </div>
                                                    <div class="col-xs-12 col-lg-6 mobile-text">
                                                        <div class="mb-0 font-weight-bold">FACEBOOK</div>
                                                        <div>Klik disini</div>
                                                    </div>
                                                </div>
                                            </a></div>
                                        <div class="content-item"> <a class="d-block clearfix  mb-3" href="#" target="_blank">
                                                <div class="row no-gutters text-center text-lg-left">
                                                    <div class="col-xs-12 col-lg-3">
                                                        <i class="icon-instagram"></i>
                                                    </div>
                                                    <div class="col-xs-12 col-lg-6 mobile-text">
                                                        <div class="mb-0 font-weight-bold">INSTAGRAM</div>
                                                        <div>Klik disini</div>
                                                    </div>
                                                </div>
                                            </a></div>
                                        <div class="content-item"> <a class="d-block clearfix  mb-3" href="https://t.me/<?php echo $tele; ?>" target="_blank">
                                                <div class="row no-gutters text-center text-lg-left">
                                                    <div class="col-xs-12 col-lg-3">
                                                        <i class="icon-telegram"></i>
                                                    </div>
                                                    <div class="col-xs-12 col-lg-6 mobile-text">
                                                        <div class="mb-0 font-weight-bold">TELEGRAM</div>
                                                        <div><?php echo $tele; ?></div>
                                                    </div>
                                                </div>
                                            </a></div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <!--home info END-->
            </div>
            <div class=" container">
                <div class="row">
                    <div class="footer-content clearfix">
                        <div class="col-xs-12">
                            <div class=" text-left footerlink mt-2">
                                <div class="small">
                                    Cara Pembayaran </div>
                                <div class="payment_imgs mt-2">
                                    <div style="display: flex;flex-wrap: wrap;gap: 10px;">
                                        <img class="img-fluid" style="width: 150px; border-radius:10px" src="https://files.sitestatic.net/sprites/bank_logos/bank_col.jpg?v=4" alt="bank payment method">
                                        <img class="img-fluid" style="width: 150px; border-radius:10px" src="https://files.sitestatic.net/sprites/bank_logos/ewallet_col.jpg?v=4" alt="ewallet payment method">
                                        <img class="img-fluid" style="width: 150px; border-radius:10px" src="https://files.sitestatic.net/sprites/bank_logos/pulsa_col.jpg?v=4" alt="pulsa payment method">
                                        <img class="img-fluid" style="width: 150px; border-radius:10px" src="https://files.sitestatic.net/sprites/bank_logos/payment_types/qris_col.webp" alt="payment gateway">
                                    </div>
                                </div>

                                <div class=" text-left footerlink mt-2">
                                    <div class="small">
                                        Browser yang Disarankan </div>
                                    <a class="mt-2 mb-2">
                                        <div style="display: flex;flex-wrap: wrap;gap: 10px;">
                                            <i class="icon-chrome browserIcons" style="font-size:1.8em;"></i>
                                            <i class="icon-firefox browserIcons" style="font-size:1.8em;"></i>
                                            <i class="icon-safari browserIcons" style="font-size:1.8em;"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="footerlink">
                                <a class="clearfix">
                                    <a href="<?php echo $urlweb; ?>/m/faq-general">Tentang kami</a> |
                                    <a href="<?php echo $urlweb; ?>/m/faq-banking">Info Perbankan</a> |
                                    <a href="<?php echo $urlweb; ?>/m/faq-general">Pusat Info</a> |
                                    <a href="<?php echo $urlweb; ?>/contact-us">Hubungi kami</a>
                                </a>
                            </div>
                            <div class="footerlink version-sec">
                                <a class="clearfix">

                                    <a class="copyright">
                                        @2026 <?php echo $s0['instansi']; ?>. Seluruh hak cipta | 18+ | v2.90
                                    </a>

                                </a>
                            </div>
                            <div class="clearfix mt-3">
                                <div class="pull-left footerlink">
                                    <div class="small">
                                        Game Provider </div>
                                    <div class="footer_pwrd_by_logo">
                                        <img class="img-fluid" src="https://files.sitestatic.net/images/footer_provider_col.png?v=0.3">

                                    </div>

                                </div>
                            </div>
                            <?php
                            $sql = "SELECT image FROM tb_banner WHERE cuid = 1";
                            $result = $conn->query($sql);

                            // Periksa apakah ada hasil dari query
                            if ($result->num_rows > 0) {
                                // Loop melalui hasil query
                                while ($row = $result->fetch_assoc()) {
                                    // Tampilkan gambar
                                    $image = $row['image'];
                                }
                            } else {
                                echo "Tidak ada gambar yang ditemukan dengan status aktif.";
                            }
                            ?>
                            <script>
                                $(document).ready(function() {

                                    console.log((!document.referrer.includes('__cf')))
                                    if (document.referrer.indexOf(location.protocol + "//" +
                                            location.host) ===
                                        0 && (!document.referrer.includes('__cf'))) {
                                        sessionStorage.setItem('isClosedPopUp', 'true');
                                    }
                                    var isClosedPopUp = sessionStorage.getItem(
                                        'isClosedPopUp');

                                    if (isClosedPopUp !== "true") {
                                        var popUpInst = $.fancybox.open({
                                            src: `<a href="/" class="d-inline-block"><img src="<?php echo $image; ?>" class="img-fluid" ></a>`,
                                            type: 'html',
                                            opts: {
                                                afterShow: function(instance,
                                                    current) {
                                                    console.log(document
                                                        .referrer.indexOf(
                                                            location
                                                            .protocol +
                                                            "//" + location
                                                            .host));
                                                    console.log(location
                                                        .protocol + "//" +
                                                        location
                                                        .host);
                                                    console.log(document
                                                        .referrer);
                                                    console.log((!document
                                                        .referrer
                                                        .includes(
                                                            '__cf')))
                                                    if (document.referrer
                                                        .indexOf(location
                                                            .protocol + "//" +
                                                            location.host) ===
                                                        0 && (!document.referrer
                                                            .includes('__cf'))
                                                    ) {
                                                        sessionStorage.setItem(
                                                            'isClosedPopUp',
                                                            'true');
                                                    }
                                                }
                                            }
                                        });
                                    }
                                    ajax_jackpot();

                                    setInterval(function() {
                                        prize += getRandomIntInclusive(80000000, 3470)
                                        prize = parseFloat(prize);
                                        prize = prize;
                                        $('#jackpot_amount').html(window
                                            .currencyCode + ' ' +
                                            commaSeparateNumber(prize, true));
                                    }, 751);

                                });
                            </script>
                            </style>



                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    function hideElements() {
                                        if (window.innerWidth < 768) { // Hanya untuk perangkat mobile
                                            document.getElementById('snackbar').style.display = '';
                                            document.getElementById('assistiveTouch2').style.display = '';
                                        }
                                    }

                                    if (window.location.pathname === '/' || window.location.pathname === '/index.html') {
                                        if (window.innerWidth < 768) { // Hanya untuk perangkat mobile
                                            document.getElementById('snackbar').style.display = 'block';
                                            document.getElementById('assistiveTouch2').style.display = 'block';
                                        }
                                    } else {
                                        hideElements();
                                    }

                                    window.addEventListener('beforeunload', function() {
                                        hideElements();
                                    });
                                });
                            </script>
                            <style>
                                @media (min-width: 768px) {

                                    #snackbar,
                                    #assistiveTouch2,
                                    #modalbooster {
                                        display: none;
                                    }
                                }

                                .assistive-touch2 {
                                    position: fixed;
                                    bottom: 40%;
                                    right: 20px;
                                    z-index: 1000;
                                    width: 50px;
                                    height: 50px;
                                    border-radius: 50%;
                                    background-color: rgb(0 0 0 / 60%);
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    color: white;
                                    font-size: 24px;
                                    cursor: pointer;
                                    touch-action: none;
                                    animation: pulse 1s infinite;
                                    font-family: sans-serif;
                                }

                                @keyframes pulse {
                                    0% {
                                        transform: scale(1);
                                    }

                                    50% {
                                        transform: scale(1.2);
                                    }

                                    100% {
                                        transform: scale(1);
                                    }
                                }

                                .modalbooster {
                                    display: none;
                                    position: fixed;
                                    left: 0;
                                    top: 0;
                                    width: 100%;
                                    height: 100%;
                                    background: rgba(0, 0, 0, 0.5);
                                    z-index: 2000;
                                    align-items: center;
                                    justify-content: center;
                                }

                                .modal-contentbooster {
                                    background-color: white !important;
                                    background-size: 100% 100% !important;
                                    background-position: center !important;
                                    background-repeat: no-repeat !important;
                                    padding: 20px;
                                    border-radius: 10px;
                                    text-align: center;
                                    animation: scaleIn 0.5s forwards;
                                    font-family: sans-serif;
                                    color: #000;
                                    font-weight: bold;
                                    box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
                                    text-transform: uppercase;
                                    margin: 0 auto;
                                    width: 80%;
                                }

                                @keyframes scaleIn {
                                    0% {
                                        opacity: 0;
                                        transform: scale(0.5);
                                    }

                                    100% {
                                        opacity: 1;
                                        transform: scale(1);
                                    }
                                }

                                .close-button3booster {
                                    position: absolute;
                                    top: 10px;
                                    right: 10px;
                                    width: 20px;
                                    height: 20px;
                                    border-radius: 50%;
                                    background-color: rgb(116, 0, 0);
                                    color: white;
                                    font-size: 15px;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    cursor: pointer;
                                    box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
                                    font-family: sans-serif;
                                }

                                .loading-bar2 {
                                    display: none;
                                    width: 100%;
                                    height: 10px;
                                    background-color: #ddd;
                                    margin-top: 10px;
                                    border-radius: 5px;
                                    overflow: hidden;
                                }

                                .loading-bar2::after {
                                    content: "";
                                    display: block;
                                    width: 100%;
                                    height: 100%;
                                    background: linear-gradient(to right,
                                            #800000 30%,
                                            #ff6347 50%,
                                            #800000 70%);
                                    background-size: 200% 100%;
                                    animation: loadingAnimation 2s linear infinite;
                                }

                                @keyframes loadingAnimation {
                                    0% {
                                        background-position: 200% 0;
                                    }

                                    100% {
                                        background-position: -200% 0;
                                    }
                                }

                                .close-modal2booster {
                                    cursor: pointer;
                                    margin-top: 10px;
                                    padding: 10px 20px;
                                    background-color: #800000;
                                    /* Merah Maroon */
                                    color: white;
                                    border: none;
                                    border-radius: 5px;
                                    font-size: 16px;
                                    font-weight: bold;
                                    transition: background-color 0.3s;
                                    box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
                                    text-transform: uppercase;
                                    font-family: sans-serif;
                                    animation: pulse 1s infinite;
                                }

                                @keyframes pulse {
                                    0% {
                                        transform: scale(1);
                                    }

                                    50% {
                                        transform: scale(1.2);
                                    }

                                    100% {
                                        transform: scale(1);
                                    }
                                }

                                .close-modal2booster:hover {
                                    background-color: #5d0000;
                                    /* Warna lebih gelap untuk efek hover */
                                }

                                .assistive-touch2 img {
                                    box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
                                    border-radius: 50%;
                                }

                                #loadingText {
                                    font-size: 12px;
                                    font-family: sans-serif;
                                    color: #000;
                                }

                                #loadingDots {
                                    font-size: 10px;
                                    font-family: sans-serif;
                                    color: #000;
                                }

                                .swal2-title {
                                    font-size: 16px;
                                    font-family: sans-serif;
                                    font-weight: bold;
                                    color: #000;
                                }

                                .swal2-content {
                                    font-size: 12px;
                                    font-family: sans-serif;
                                }

                                .swal2-confirm {
                                    background-color: maroon !important;
                                    color: #fff;
                                    font-family: sans-serif;
                                    font-weight: bold;
                                }

                                .swal2-popup {
                                    background-color: !important;
                                    background-size: 100% 100% !important;
                                    background-position: center !important;
                                    background-repeat: no-repeat !important;
                                }

                                #boosterGif {
                                    display: block;
                                    margin: 0 auto;
                                }

                                * {
                                    font-family: sans-serif !important;
                                }
                            </style>







                            <meta charset="utf-8">

                            <meta name="csrf-token" content="hpTuvxTE7ugnKAYef6XdhZw5C29aavcDtN9oQKQz">

                            <script src="https://cdn.sitestatic.net/assets/jquery/juery.min.js"></script>
                            <script src="https://cdn.sitestatic.net/assets/bootstrap/bootstrap.min.js"></script>
                            <script src="https://cdn.sitestatic.net/assets/jquery/sweet_alert2.min.js"></script>

                            </script>
                            <?php include "footer.php"; ?>