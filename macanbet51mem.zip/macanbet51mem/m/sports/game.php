<?php
clearstatcache();
// Menangkap kode provider dari URL, default ke 'PR' jika tidak ada
$providerCode = isset($_GET['provider']) ? $_GET['provider'] : 'wb';

ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../../config/koneksi.php');

$sid = session_id();
$sql_0 = mysqli_query($conn,"SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error($conn));
$s0 = mysqli_fetch_array($sql_0);
$urlweb = $s0['urlweb'];

include "../../m/header.php";
?>

<?php
error_reporting(E_ALL);
// Cek status maintenance provider yang sedang dipilih
$checkProv = mysqli_query($conn, "SELECT status FROM tb_provider WHERE code = '$providerCode' AND game_category = 'sb' LIMIT 1");
if (mysqli_num_rows($checkProv) > 0) {
    $pRow = mysqli_fetch_assoc($checkProv);
    if ($pRow['status'] == 0) {
        echo "<script>alert('Provider ini sedang dalam pemeliharaan.'); window.history.back();</script>";
        exit();
    }
}
?>

<div class="container pt-1 sub-games">
    <div>
        <h3 class="title" i18n>SPORTSBOOK</h3>
        
        <div class="scroll-wrapper row" style="height:auto;">
            <div class="left">
                <button class="prev-btn btn" id="left-button"><i class="icon-keyboard_arrow_left"></i></button>
            </div>
            <div style="overflow:hidden;width:100%;" class="scroller">
                <?php
                // Migrasi: Mengambil daftar provider sports (SB) dari tb_provider
                $query = "SELECT * FROM tb_provider WHERE game_category ='sb' AND status = 1 ORDER BY FIELD(code, 'PR', 'PG', 'HB') DESC, name ASC";
                $result = mysqli_query($conn, $query);
                
                if ($result) {
                    echo '<div class="row no-gutters text-center slider-content">';
                    while ($row = mysqli_fetch_assoc($result)) {
                        $activeClass = ($providerCode == $row['code']) ? 'style="border: 2px solid gold; border-radius: 10px;"' : '';
                        $img_name = strtolower(str_replace(' ', '-', trim($row['name']))) . '.jpg';
                        
                        echo '<div class="col" '.$activeClass.'>';
                        echo '<a class="btn-box" href="/m/sports/game.php?provider=' . $row['code'] . '">';
                        echo '<img alt="'.$row['name'].'" src="'.$urlweb.'/uploads/prov/'.$img_name.'" height="60" width="70" style="object-fit:contain;"/>';
                        echo '<div class="text-center fs-sm game-title" style="font-size:10px text-transform:uppercase;">' . $row['name'] . '</div>';
                        echo '</a>';
                        echo '</div>';
                    }
                    echo '</div>';
                }
                ?>
            </div>
            <div class="right">
                <button class="next-btn btn" id="right-button"><i class="icon-keyboard_arrow_right"></i></button>
            </div>
        </div>
    </div>

    <div class="row no-gutters filter">
        <div class="col-xs-10 text-center">
            <div class="row">
                <div class="col-xs-3"><button class="btn btn-clear f active">BARU</button></div>
                <div class="col-xs-3"><button class="btn btn-clear f">TOP</button></div>
                <div class="col-xs-3"><button class="btn btn-clear f">SEMUA</button></div>
            </div>
        </div>
        <div class="col-xs-1 text-right"><button class="btn btn-clear"><i class="icon-magnifier"></i></button></div>
        <div class="col-xs-1 text-right"><button class="btn btn-clear"><i class="icon-equalizer2"></i></button></div>
    </div>

    <div class="mobile-border"></div>
    <br />

    <div class="row games no-gutters">
    <?php
        // Migrasi: Mengambil list game dari tb_gamelist berdasarkan provider_code dan kategori sports (sb)
        $sql_games = mysqli_query($conn, "SELECT * FROM `tb_gamelist` 
                                          WHERE `provider_code` = '$providerCode' 
                                          AND `game_category` = 'sb' 
                                          AND `status` = 1") or die(mysqli_error($conn));
        
        if(mysqli_num_rows($sql_games) > 0) {
            while($s3 = mysqli_fetch_array($sql_games)){
                if(isset($_SESSION['user'])){
                    // Link launch game menggunakan game_code dari tb_gamelist
                    $playUrl = $urlweb.'/gameplay/opengame/?gamecode=' . $s3['game_code'] . '&providercode=' . $s3['provider_code'];
                } else {
                    $playUrl = $urlweb.'/m/?notif=6';
                }

                // Logika Warna RTP
                $rtp = $s3['game_rtp'];
                if ($rtp < 50) { $warna = 'red'; } 
                else if ($rtp >= 50 && $rtp < 75) { $warna = 'orange'; } 
                else { $warna = 'green'; }
                ?>
                
                <a class="col-xs-4 col-md-3 game-box text-center" href="<?php echo $playUrl; ?>" data-title="<?php echo $s3['game_name']; ?>">
                    <div class="content-wrapper" style="width: 100%; aspect-ratio: 1/1; border: 1px solid #333; display: flex; align-items: center; justify-content: center; overflow:hidden; background:#000; border-radius:8px;">
                        <img width="100%" class="lazy" style="object-fit: cover;" src="<?php echo $s3['banner']; ?>" alt="<?php echo $s3['game_name']; ?>">
                        <div style="position:absolute; bottom:25px; background: rgba(0,0,0,0.7); width:100%; color:<?php echo $warna; ?>; font-size:10px; font-weight:bold;">
                            RTP <?php echo $rtp; ?>%
                        </div>
                    </div>
                    <h5 style="font-size:11px; margin-top:5px; height:30px; overflow:hidden;"><?php echo $s3['game_name']; ?></h5>
                </a>
        <?php 
            } 
        } else {
            echo '<div class="col-xs-12 text-center text-white"><p>Tidak ada permainan tersedia untuk provider ini.</p></div>';
        }
        ?>
    </div>

    <?php include "../footer.php";?>
</div>