<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');
$sid = session_id();
$sql_0 = mysqli_query($conn,"SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);
$urlweb = $s0['urlweb'];
$urlwebs = $s0['urlweb'];
$pengguna = $s0['user'];
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d');
$stat = mysqli_query($conn,"INSERT INTO `tb_stat` (`ip`, `date`, `hits`, `page`, `user`) VALUES ('$ip', '$date', 1, 'Beranda', '$pengguna')") or die (mysqli_error());
$sql_banner = mysqli_query($conn,"SELECT * FROM `tb_banner` WHERE cuid = 1") or die(mysqli_error());
$ssb = mysqli_fetch_array($sql_banner);
$status = $ssb['status'];
if($status == true){
    $cekPopup = mysqli_query($conn,"SELECT * FROM `tb_popup` WHERE ip = '$ip'") or die(mysqli_error());
    $cpp = mysqli_num_rows($cekPopup);
    if($cpp == 0){
        $pop = mysqli_query($conn,"INSERT INTO `tb_popup` (`ip`, `date`, `status`) VALUES ('$ip', '$date', 0)") or die (mysqli_error());
        $lihat = $status;
    }
    else {
        $cp = mysqli_fetch_array($cekPopup);
        $statusnya = $cp['status'];
        if($statusnya == 0){
            $lihat = $status;
        }
        else {
            $lihat = 'false';
        }
    }
}
else {
    $lihat = $status;
}

include "header.php";
?>

<?php
error_reporting(0);

$validNotifications = [1];

if (!empty($_GET['notif']) && in_array($_GET['notif'], $validNotifications)) {
    $popupContent = '';
    $popupIcon = 'info'; // Default icon

    switch ($_GET['notif']) {
        case 1:
            $popupContent = '<strong>Akun Anda Sedang Dalam Masa Promosi Silahkan Melakukan Deposit Terlebih Dahulu</strong>';
            $popupIcon = '';
            break;
        }

        // Output JavaScript code to show SweetAlert
        echo "
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    Swal.fire({
                        icon: '$popupIcon',
                        title: 'Notification',
                        html: '$popupContent',
                    });
                });
            </script>
        ";
    }
    ?>

<div class="container pt-1 games-category">

    <h2 class="title">Cockfight</h2>
    <div class="row">
        <script type="text/javascript">
            var windowNames = JSON.parse('{"lottery":"lottery","live":"king4d","togel":"king4d"}');
        </script>


        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 image-grid">

<?php
error_reporting(E_ALL);
$result = mysqli_query($conn, "SELECT * FROM `tb_prov_sgx` WHERE `provider_type` = 'OT'");

if (!$result) {
    die("Query Error: " . mysqli_error($conn));
}

while ($rowProvider = mysqli_fetch_assoc($result)) {
    $provider_name = strtolower(str_replace(' ', '-', trim($rowProvider["provider_name"])));
    $provider_code = strtolower($rowProvider["provider_code"]);
    $provider_status = $rowProvider["provider_status"]; // Ambil status provider
    
    // Gunakan format jpg untuk semua file
    $media_src = $urlweb . '/uploads/prov/' . $provider_name . '.jpg';
    //var_dump($rowProvider);

    // Tentukan tautan berdasarkan status
        if ($provider_status == 0) {
            $link = 'javascript:void(0)';
            $onclick = "onclick=\"alert('Provider sedang dalam maintenance. Silakan coba lagi nanti.')\"";
        } else {
            $link = $urlweb . '/m/cockfight/game/?provider=' . $provider_code;
            $onclick = '';
        }

        echo '
        <div class="col-xs-4 col-sm-3 col-md-2 box">
            <div class="game-wrapper">
                <a href="' . $link . '" ' . $onclick . '/m/cockfight/game/?provider=' . $provider_code . '" rel="opener" class="game">
                <img class="img-fluid" alt="' . strtoupper($rowProvider["provider_name"]) . '" src="' . $media_src . '" />
                <div class="g-title" style="font-size: smaller;">' . strtoupper($rowProvider["provider_name"]) . '</div>
            </a>
        </div>
    </div>';
}
?>

                </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include "footer.php";?>