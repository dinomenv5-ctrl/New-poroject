<?php 
include 'session.php';
include 'header.php';?>

<div class="container-wrapper info ">
  <div class="container container-box info-view">
    <div class="info-nav nav-icon">
      <div class="row no-gutters">
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="terms-terms_conditions.php" class="">
            <div>
              <i class="icon-clipboard"></i>
            </div>
            <div>TERMS & CONDITIONS </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-general.php" class="active">

            <div> <i class="icon-help-circle"></i></div>

            <div>FAQ</div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                  <a href="how-sportsbook.php" class="">
            <div><i class="icon-list-numbered"></i> </div>
            <div>HOW TO PLAY </div>
          </a>
        </div>
         
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-referral.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>REFERRAL</div>
          </a>
        </div>
                <div>
          <a href="responsiblegaming" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>Responsible Gaming</div>
          </a>
        </div>

      </div>
    </div>
<nav class="navbar navbar-expand-lg navbar-light navbar-default  ">
  <!--<span class="menu-select" id="menu-select">General</span>-->
  <div class="navbar-header d-lg-none clearfix">
    <button class="navbar-toggler" id="navbar-toggler--info"  type="button" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <i class="icon-bars navbar-toggler-icon"></i>
    </button>
    <div class="menu-select d-lg-none" id="menu-select--info"></div>
  </div>

  <div class="collapse navbar-collapse" >
    <ul class="navbar-nav mt-lg-0" style="list-style-type:none;">
      <li class="nav-item" >
        <a class="nav-link" href="faq-general.php" data-pg="general">General</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-deposit.php" data-pg="deposit">Deposits</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq_withdrawal.php" data-pg="faq_withdrawal">Withdrawal</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-games.php" data-pg="games">Gaming</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-technical.php"  data-pg="technical">Technical</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-banking.php" data-pg="banking">Banking</a>
      </li>
    </ul>
  </div>
</nav>


<div class="panel-group" id="info_accordion">
    <!-- First Panel -->
        <div class="panel info panel-default">
        <div class="info panel-heading"  data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse1">
             <h5 class="panel-title info">
                1. Saya mengalami masalah saat memuat beberapa konten situs web. Bagaimana saya bisa mengatasi masalah ini?              </h5>
        </div>
        <div id="collapse1" class="panel-collapse collapse">
            <div class="info panel-body">
                <p>Ada masalah yang diketahui dengan versi Adobe Flash Player yang lebih lama saat menampilkan grafik Flash. Kami menyarankan Anda memperbarui Flash Player dan browser Anda. 
              </p>            </div>
        </div>
    </div>
 
</div>
  </div>
</div>



<script>
  $(function(){
    var pg ="technical"; 
    var selectedMenu=  $('.navbar-nav .nav-link').filter(function(){ 
          return $(this).data("pg").toLowerCase() == pg.toLowerCase();
        }).text();
      $('#menu-select--info').text(selectedMenu);
    

    $('#navbar-toggler--info').click(function(){
        $('.info .navbar-collapse').toggleClass('show in');

    }) 
  });
</script>

            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>