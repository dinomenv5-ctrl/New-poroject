<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');
$sid = session_id();

// Ambil data SEO
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error($conn));
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../config/url_helper.php');
}
$urlweb = get_active_base_url();

$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d');

// Statistik & Popup Logic
$stat = mysqli_query($conn, "INSERT INTO `tb_stat` (`ip`, `date`, `hits`, `page`, `user`) VALUES ('$ip', '$date', 1, 'Beranda', '$pengguna')") or die(mysqli_error($conn));
$sql_banner = mysqli_query($conn, "SELECT * FROM `tb_banner` WHERE cuid = 1") or die(mysqli_error($conn));
$ssb = mysqli_fetch_array($sql_banner);
$status_banner = $ssb['status'];

// Cek Status Maintenance Situs
$sql_m = "SELECT status FROM maintenance WHERE id = 1";
$result_m = $conn->query($sql_m);
if ($result_m->num_rows > 0) {
    $row_m = $result_m->fetch_assoc();
    if ($row_m["status"] == 1) {
        echo "<script>alert('Halaman sedang dalam pemeliharaan. Kembali ke halaman sebelumnya.'); window.history.back();</script>";
        exit();
    }
}

include "../m/header.php";

/**
 * DAFTAR LOTRE (ARRAY)
 * Edit bagian ini untuk mengelola daftar permainan
 */ 
$lotteries = [
    [
        'title' => 'NEX4D',
        'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/nex4d.jpg',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=7351&providercode=ND',
        'type' => 'maintenance',
        'icon' => 'live',
        'target' => '_ND'
    ],
        [
        'title' => 'Cai Shen Bingo',
        'img' => ' https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSju3T7o_tkkM4KBB_8HaEIVoP0gowHjkJT9RnFc1WnBA&s=10',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=12_12001&providercode=JD',
        'type' => 'link',
        'icon' => 'live',
        'target' => '_ND'
    ],
    [
        'title' => 'Caribbean Adventure Bingo',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTsSauQIYM_wDOhquG8A7wkw-m_9QhEASPa1VRL2yK3AA&s ',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=BINGO_CARIBBEAN&providercode=WW',
        'type' => 'link',
        'icon' => 'live',
        'target' => '_ND'
    ],
    [
        'title' => 'Go For Launch! Bingo',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQte74fZHYC7RQipjuIoE3vwa-XmKOyEEPaBCuhgufrCQ&s=10',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=BINGO_ROCKET&providercode=WW',
        'type' => 'link',
        'icon' => 'live',
        'target' => '_ND'
    ],
    [
        'title' => 'Gold Rooster Lottery',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSf46WpEqAU-7gGJw6C0yNztXvKbybgucEQbF99Qw1tvPGoZyG9GuLgwkk&s=10',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=12_12002&providercode=JD',
        'type' => 'link',
        'icon' => 'live',
        'target' => '_ND'
    ],
    [
        'title' => 'Happy Lottery',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-LuQEqlDXgOSfWB-_I69KGVXl3bM8R2hEsA&usqp=CAU',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=12_12003&providercode=JD',
        'type' => 'link',
        'icon' => 'live',
        'target' => '_ND'
    ],
    [
        'title' => 'Samba Bingo',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmQeR2olGjp1Y1NpAzw_H2ckSQLZm-xn2uHWJAhn_Nfgjofajp9sYFfFgB&s=10',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=BINGO_SAMBA&providercode=WW',
        'type' => 'link',
        'icon' => 'live',
        'target' => '_ND'
    ],
    
    ['title' => 'Amazon 4D', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4d_amazon.jpg', 'type' => 'maintenance', 'icon' => 'none'],
    ['title' => 'King 4D', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4d_king.jpg', 'type' => 'maintenance', 'icon' => 'none'],
    ['title' => 'Hongkong Grand 4D', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4d_hongkong_grand.jpg', 'type' => 'maintenance', 'icon' => 'none'],
    ['title' => 'Shanghai Hero 4D', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4d_shanghai_hero.jpg', 'type' => 'maintenance', 'icon' => 'none'],
    ['title' => 'Singapore Pools 4D', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4D_singapore_pools.png', 'type' => 'maintenance', 'icon' => 'none'],
    ['title' => 'Toto Singapore Pools', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4D_malaysia_toto.png', 'type' => 'maintenance', 'icon' => 'none'],
    ['title' => 'Malaysia Magnum 4D', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4D_malaysia_magnum.png', 'type' => 'maintenance', 'icon' => 'none'],
    ['title' => 'Malaysia Damacai 4D', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/4D_malaysia.png', 'type' => 'maintenance', 'icon' => 'none'],
];
?>

<div class="container pt-1 games-category">
    <h2 class="title">LOTRE</h2>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 image-grid">
            
            <?php foreach ($lotteries as $item): ?>
                <div class="col-xs-4 col-sm-3 col-md-2 box">
                    <div class="game-wrapper rng">
                        
                        <?php if ($item['icon'] == 'live'): ?>
                            <div style="position:absolute;right:0;top:0;z-index: 9;">
                                <img src="https://files.sitestatic.net/images/live_icon.gif" ref="live" height="25px">
                            </div>
                        <?php endif; ?>

                        <?php if ($item['type'] == 'maintenance'): ?>
                            <div class="game maintenance-alert">
                                <img class="img-fluid lazy" alt="<?php echo $item['title']; ?>" data-src="<?php echo $item['img']; ?>" src="" />
                                <div class="loader-b" *ngIf="!showEle"></div>
                                <div class="g-title"></div>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo $item['url']; ?>" rel="opener" class="game" target="<?php echo $item['target']; ?>">
                                <img class="img-fluid lazy" alt="<?php echo $item['title']; ?>" data-src="<?php echo $item['img']; ?>" src="" />
                                <div class="loader-b" *ngIf="!showEle"></div>
                            </a>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endforeach; ?>

        </div>
    </div>
</div>

<?php include "footer.php"; ?>