<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../../config/koneksi.php');
$sid = session_id();
$sql_0 = mysqli_query($conn,"SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);
$urlweb = $s0['urlweb'];
$urlwebs = $s0['urlweb'];
if(isset($_SESSION['user'])) {
    $sql_1 = mysqli_query($conn,"SELECT * FROM `tb_user` WHERE cuid = 1") or die(mysqli_error());
    $s1b = mysqli_fetch_array($sql_1);
    
    $user =mysqli_query($conn,"SELECT * FROM `tb_user` WHERE username = '".$_SESSION['user']."'") or die (mysqli_error());
    $u = mysqli_fetch_array($user);
    $users = $u['username'];
    $id_user = $u['cuid'];
    $userID = $u['cuid'];
    $sql_3 = mysqli_query($conn,"SELECT * FROM `tb_balance` WHERE userID = '$userID'") or die(mysqli_error());
    $s3 = mysqli_fetch_array($sql_3);
    
    $sql_banks = mysqli_query($conn,"SELECT * FROM `tb_bank` WHERE userID = '$userID'") or die(mysqli_error());
    $sbs = mysqli_fetch_array($sql_banks);
    } else {
    }

include "../header.php";?>

<!--start-->
<div class="container my_promo_view">
  <div class="container-wrapper profile-head">
  <div class="container container-box noSidePadding">
    <div class="title fs-lg clearfix">
      <span class="skew">     
       <span>Promo saya</span>    </span>
    </div>
    <div class="head-content">
      <div class="row no-gutters">
     
        
                <div class="col-xs-12 ">
          <div class="mdc-tab-bar" role="tablist">
            <div class="mdc-tab-scroller">
              <div class="mdc-tab-scroller__scroll-area mdc-tab-scroller__scroll-area--scroll" style="margin-bottom: 0px;">
                <div class="mdc-tab-scroller__scroll-content">
                  <!---->
     


          <!---->
            <a role="tab" href="<?= $urlweb;?>/m/promo/my-promo" 
   data-tabname="my-promo" data-active="promomy-promo" 
   class="mdc-tab" aria-selected="false" tabindex="-1" 
   onclick="window.location.href='<?= $urlweb;?>/m/promo/my-promo'; return true;">
    <span class="mdc-tab__content">
        <span class="mdc-tab__text-label"><!---->Promo saya<!----></span>
    </span>
    <span class="mdc-tab-indicator">
        <span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline" style=""></span>
    </span>
    <span class="mdc-tab__ripple mdc-ripple-upgraded" style="--mdc-ripple-fg-size:102px; --mdc-ripple-fg-scale:1.83267; --mdc-ripple-fg-translate-start:-44.1875px, -35px; --mdc-ripple-fg-translate-end:34.1484px, -27px;"></span>
</a>

          <!---->
<style>
    .mdc-tab-disabled {
    pointer-events: none;
    cursor: default;
}
</style>
          <!---->
       
                      <a href="<?= $urlweb;?>/m/promo/my-bonus" 
   data-disabled-tabname="bonus" data-inactive="promomy-bonus" 
   class="mdc-tab" aria-selected="false" tabindex="-1" onclick="window.location.href='<?= $urlweb;?>/m/promo/my-bonus'; return true;">
    <span class="mdc-tab__content">
        <span class="mdc-tab__text-label">Bonus saya</span>
    </span>
    <span class="mdc-tab-indicator">
        <span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span>
    </span>
    <span class="mdc-tab__ripple"></span>
</a>


        
          
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="outlet tab-content">
        <div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab">
          
          <div class="container-b3">
              
              
              <style>
    .modal-header::after, 
    .modal-header::before {
        display: table;
        content: none;
    }
</style>
<div class="row my-promo">
    <div class="col-lg-12 col-xs-12">
        <div class="row">
            <div class="col-md-4 noSidePadding">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-sm btn-warning check_bonus_history_btn" id="check_bonus_history_btn">
                    Catatan Bonus
                </button>


           <?php
$sql = "SELECT * FROM tb_vc_history WHERE userID = ? ORDER BY id DESC LIMIT 10"; // Ambil 10 data terakhir
$stmt = $conn->prepare($sql);

// Bind parameter
$stmt->bind_param("i", $userID);

// Eksekusi statement
$stmt->execute();

// Ambil hasil
$result = $stmt->get_result();

// Array untuk menyimpan data bonus history
$bonusHistory = [];
while ($row = $result->fetch_assoc()) {
    $bonusHistory[] = $row; // Simpan setiap baris dalam array
}
?>
<style>
    .modal-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }

    .modal-title {
        font-size: 1.25rem;
        font-weight: bold;
    }

    .modal-body {
        padding: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 1rem;
    }

    th, td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
        text-align: left;
    }

    th {
        background-color: #007bff;
        color: white;
        font-weight: bold;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #d1e7fd; /* Highlight on hover */
    }

    .modal-footer {
        justify-content: flex-end;
    }

    .btn {
        border-radius: 0.2rem;
    }
</style>
            <!-- Modal -->
<div class="modal-wrapper nifty-modal slide-in-bottom" id="BonusHistoryModalCenter">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="d-flex modal-header" style="justify-content: space-between;">
                <h5 class="modal-title" style="text-align: left;" id="exampleModalLongTitle">Bonus History (Last 10 records)</h5>
                <button type="button" class="close bonus_history_close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Kode Voucher</th>
                            <th>Nama</th>
                            <th>Nominal</th>
                            <th>Target</th>
                            <th>Sisa Target</th>
                            <th>Jenis</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($bonusHistory) > 0): ?>
                            <?php foreach ($bonusHistory as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                                    <td><?php echo htmlspecialchars($row['kd_voucher']); ?></td>
                                    <td><?php echo htmlspecialchars($row['nama']); ?></td>
                                    <td>IDR <?php echo htmlspecialchars($row['nominal']); ?></td>
                                    <td><?php echo htmlspecialchars($row['target']); ?></td>
                                    <td><?php echo htmlspecialchars($row['sisa_target']); ?></td>
                                    <td><?php echo htmlspecialchars($row['jenis']); ?></td>
                                    <td><?php echo $row['status'] == 1 ? 'Aktif' : 'Tidak Aktif'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center">Tidak ada data bonus history</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary bonus_history_close" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

    <br>
    <br>
    <div class="col-lg-4 col-xs-12">
        <div class="row">
            <div class="col-md-4 noSidePadding">
                <p class="lbl" i18n="i18n">Bonus saya:</p>
            </div>
            <div class="col-md-8 noSidePadding">
                <p>
                    <?php
                    // Cek bonus pengguna
                    $bonus_query = "SELECT * FROM tb_vc_history WHERE userID = ? AND status = 1 LIMIT 1";
                    $stmt = $conn->prepare($bonus_query);
                    $stmt->bind_param("i", $userID);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        $bonus_data = $result->fetch_assoc();
                        echo htmlspecialchars($bonus_data['nama']);
                    } else {
                        echo "-";
                    }
                    ?>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-md-4 noSidePadding">
                <p class="lbl" i18n="i18n">Jenis Bonus:</p>
            </div>
            <div class="col-xs-6 col-md-8 noSidePadding">
                <p>
                    <?php
                    if ($result->num_rows > 0) {
                        echo htmlspecialchars($bonus_data['jenis']);
                    } else {
                        echo "-";
                    }
                    ?>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-md-4 noSidePadding">
                <p class="lbl" i18n="i18n">Jumlah Bonus:</p>
            </div>
            <div class="col-xs-6 col-md-8 noSidePadding">
                <p>IDR 
                    <?php
                    if ($result->num_rows > 0) {
                        echo number_format(($bonus_data['nominal']), 2, '.', ',');
                    } else {
                        echo "-";
                    }
                    ?>
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-xs-12 "></div>

    <div class="col-lg-4 col-xs-12">
    <form method="POST" action="">
        <div class="row">
            <div class="col-xs-2 col-md-2">
                <p class="lbl" i18n="i18n">Terapkan Bonus</p>
            </div>
            <div class="col-xs-6 col-md-6">
                <input type="text" class="form-control input_text" name="bonus_code" id="bonus_code" placeholder="Masukkan Kode Bonus" required="required">
            </div>
            <div class="col-xs-4 col-md-4">
                <button type="submit" class="btn btn-sm btn-success">Memeriksa</button>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="p-5">
                <span class="bonus_event_display"></span>
            </div>
        </div>
    </form>
</div>

    </div>
</div>

<?php
// Logika untuk memproses kode bonus
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode_voucher = $_POST['bonus_code'];

    // Cek apakah userID sudah menggunakan kode voucher
    $check_history_query = "SELECT * FROM tb_vc_history WHERE kd_voucher = ? AND userID = ?";
    $stmt = $conn->prepare($check_history_query);
    $stmt->bind_param("ss", $kode_voucher, $userID);
    $stmt->execute();
    $history_result = $stmt->get_result();

    if ($history_result->num_rows > 0) {
        // User sudah menggunakan kode voucher
        echo '<script>$(".bonus_event_display").text("Anda sudah menggunakan kode voucher ini sebelumnya!");</script>';
    } else {
        // User belum menggunakan kode voucher, lanjutkan dengan pengecekan voucher
        $voucher_query = "SELECT * FROM tb_voucher WHERE kd_voucher = ? AND expired_at >= NOW()";
        $stmt = $conn->prepare($voucher_query);
        $stmt->bind_param("s", $kode_voucher);
        $stmt->execute();
        $voucher_result = $stmt->get_result();

        if ($voucher_result->num_rows > 0) {
            $voucher_data = $voucher_result->fetch_assoc();
            $nominal = $voucher_data['nominal'];
            $target = $voucher_data['target'];
            $username = $_SESSION['user'];

            // Sertakan class_softgaming.php untuk transaksi
            include '../../config/class_softgaming.php';
            $transaksi = $WL->transaksi($username, 'deposit', $nominal);
            var_dump($transaksi,$username,$nominal);

            if ($transaksi) {
                // Insert ke tb_vc_history
                $sisa_target = 0;  // Karena target langsung 0 setelah digunakan
                $insert_history = "INSERT INTO tb_vc_history (kd_voucher, nama, nominal, target, sisa_target, jenis, userID, status) VALUES (?, ?, ?, ?, ?, ?, ?, 1)";
                $stmt = $conn->prepare($insert_history);
                $stmt->bind_param("ssdddsd", $voucher_data['kd_voucher'], $voucher_data['nama'], $nominal, $target, $sisa_target, $voucher_data['jenis'], $userID);
                $stmt->execute();
                echo '<script>$(".bonus_event_display").text("Bonus berhasil diterapkan!");</script>';
            } else {
                echo '<script>$(".bonus_event_display").text("Transaksi gagal!");</script>';
            }
        } else {
            echo '<script>$(".bonus_event_display").text("Kode voucher tidak valid atau sudah kedaluwarsa!");</script>';
        }
    }
}
?>

<script>
    $(document).ready(function() {
    // Ketika tombol diklik, tampilkan modal
    $('#check_bonus_history_btn').on('click', function() {
        $('#BonusHistoryModalCenter').modal('show');
    });
    
    // Menutup modal ketika tombol close diklik
    $('.bonus_history_close').on('click', function() {
        $('#BonusHistoryModalCenter').modal('hide');
    });
});
</script>
<!-- Sertakan jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>



          </div>
        </div>

      </div>

    </div>
  </div>
</div>
</div>
<!--end-->
<?php include "../footer.php";?>
              