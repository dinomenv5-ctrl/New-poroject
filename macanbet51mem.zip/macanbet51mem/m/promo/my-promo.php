<?php
ob_start();
session_start();

// Pastikan user login dulu
if (!isset($_SESSION['user'])) {
    // Kalau belum login, bisa redirect ke login
    header("Location: /m/login.php");
    exit();
}

// Redirect ke affiliate baru
header("Location: https://ug.winkck.com/m/promotion.php");
exit();
