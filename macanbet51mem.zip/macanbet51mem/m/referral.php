<?php 
include 'session.php'; 
include 'header.php';  

$user_id = $_SESSION['cuid'] ?? '';  
$myCode = ''; 
$myLink = '';  

if($user_id != ''){
    $stmt = mysqli_prepare($conn, "SELECT referral_code FROM users WHERE cuid=?");
    mysqli_stmt_bind_param($stmt, "s", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);

    if($data && !empty($data['referral_code'])){
        $myCode = $data['referral_code'];
        $myLink = "https://".$_SERVER['HTTP_HOST']."/m/register/?reff=".$myCode;
    }
}
?>

<style>
.ref-box{
  background:#111;
  padding:15px;
  border-radius:10px;
  margin-bottom:20px;
  color:#fff;
}
.ref-display{
  background:#222;
  padding:12px;
  border-radius:6px;
  text-align:center;
  margin-bottom:12px;
  word-break: break-all;
  font-size:14px;
}
.ref-box button{
  padding:10px 18px;
  border:none;
  border-radius:6px;
  background:#ffc107;
  font-weight:bold;
  cursor:pointer;
}
</style>

<div class="container">
  <div class="referral">
    <div class="ref-box">

      <h4>Kode Referral Anda</h4>
      <div class="ref-display">
        <?= !empty($myCode) ? htmlspecialchars($myCode) : '-' ?>
      </div>

      <h4>Link Referral Anda</h4>
      <div class="ref-display" id="refLink">
        <?= !empty($myLink) ? htmlspecialchars($myLink) : '-' ?>
      </div>

      <button onclick="copyRef()">Copy Link</button>

    </div>
  </div>
</div>

<script>
function copyRef() {
  var text = document.getElementById("refLink").innerText;

  if(text === "-"){
      alert("Link belum tersedia!");
      return;
  }

  if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function() {
          alert("Link referral berhasil disalin!");
      });
  } else {
      var textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      alert("Link referral berhasil disalin!");
  }
}
</script>

<?php include 'footer.php'; ?>