<?php
clearstatcache();
$providerCode = isset($_GET['provider']) ? $_GET['provider'] : 'LK';

ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../../config/koneksi.php');

$sid = session_id();
$sql_0 = mysqli_query($conn,"SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error($conn));
$s0 = mysqli_fetch_array($sql_0);
$urlweb = $s0['urlweb'];

include "../../m/header.php";
?>

<?php
// Proteksi Maintenance Provider
$checkProv = mysqli_query($conn, "SELECT status FROM tb_provider WHERE code = '$providerCode' AND game_category = 'LK' LIMIT 1");
if (mysqli_num_rows($checkProv) > 0) {
    $pRow = mysqli_fetch_assoc($checkProv);
    if ($pRow['status'] == 0) {
        echo "<script>alert('Provider sedang maintenance.'); window.history.back();</script>";
        exit();
    }
}
?>

<div class="container pt-1 sub-games">
    <div>
        <h3 class="title">LOTTERY GAMES</h3>
        
        <div class="scroll-wrapper row" style="height:auto;">
            <div style="overflow:hidden;width:100%;" class="scroller">
                <?php
                $query = "SELECT * FROM tb_provider WHERE game_category ='LK' AND status = 1 ORDER BY FIELD(code, 'PR', 'PG', 'HB') DESC, name ASC";
                $result = mysqli_query($conn, $query);
                
                if ($result) {
                    echo '<div class="row no-gutters text-center slider-content">';
                    while ($row = mysqli_fetch_assoc($result)) {
                        $activeClass = ($providerCode == $row['code']) ? 'style="border: 2px solid #ff0000; border-radius: 10px;"' : '';
                        $img_name = strtolower(str_replace(' ', '-', trim($row['name']))) . '.jpg';
                        
                        echo '<div class="col" '.$activeClass.'>';
                        echo '<a class="btn-box" href="/m/lottery/game.php?provider=' . $row['code'] . '">';
                        echo '<img alt="'.$row['name'].'" src="'.$urlweb.'/uploads/prov/'.$img_name.'" height="60" width="70" style="object-fit:contain;"/>';
                        echo '<div class="text-center fs-sm game-title" style="font-size:10px;">' . $row['name'] . '</div>';
                        echo '</a>';
                        echo '</div>';
                    }
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>

    <div class="mobile-border"></div>
    <br />

    <div class="row games no-gutters">
    <?php
        // Mengambil list game dari tb_gamelist berdasarkan kategori 'lk'
        $sql_games = mysqli_query($conn, "SELECT * FROM `tb_gamelist` 
                                          WHERE `provider_code` = '$providerCode' 
                                          AND `game_category` = 'lk' 
                                          AND `status` = 1") or die(mysqli_error($conn));
        
        if(mysqli_num_rows($sql_games) > 0) {
            while($s3 = mysqli_fetch_array($sql_games)){
                if(isset($_SESSION['user'])){
                    $playUrl = $urlweb.'/gameplay/opengame/?gamecode=' . $s3['game_code'] . '&providercode=' . $s3['provider_code'];
                } else {
                    $playUrl = $urlweb.'/m/?notif=6';
                }

                $rtp = $s3['game_rtp'];
                $warna = ($rtp < 50) ? 'red' : (($rtp < 75) ? 'orange' : 'green');
                ?>
                
                <a class="col-xs-4 col-md-3 game-box text-center" href="<?php echo $playUrl; ?>">
                    <div class="content-wrapper" style="width: 100%; aspect-ratio: 1/1; border: 1px solid #333; display: flex; align-items: center; justify-content: center; overflow:hidden; background:#000; border-radius:8px; position:relative;">
                        <img width="100%" class="lazy" style="object-fit: cover;" src="<?php echo $s3['banner']; ?>" alt="<?php echo $s3['game_name']; ?>">
                        <div style="position:absolute; bottom:0; background: rgba(0,0,0,0.7); width:100%; color:<?php echo $warna; ?>; font-size:10px;">
                            RTP <?php echo $rtp; ?>%
                        </div>
                    </div>
                    <h5 style="font-size:11px; margin-top:5px;"><?php echo $s3['game_name']; ?></h5>
                </a>
        <?php 
            } 
        } else {
            echo '<div class="col-xs-12 text-center text-white"><p>Permainan tidak tersedia.</p></div>';
        }
        ?>
    </div>
</div>
<?php include "../../m/footer.php";?>