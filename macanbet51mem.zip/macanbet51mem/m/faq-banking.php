<?php 
include 'session.php';
include 'header.php';?>

<div class="container-wrapper info ">
  <div class="container container-box info-view">
    <div class="info-nav nav-icon">
      <div class="row no-gutters">
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="terms-terms_conditions.php" class="">
            <div>
              <i class="icon-clipboard"></i>
            </div>
            <div>TERMS & CONDITIONS </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-general.php" class="active">

            <div> <i class="icon-help-circle"></i></div>

            <div>FAQ</div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                  <a href="how-sportsbook.php" class="">
            <div><i class="icon-list-numbered"></i> </div>
            <div>HOW TO PLAY </div>
          </a>
        </div>
         
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-referral.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>REFERRAL</div>
          </a>
        </div>
                <div>
          <a href="responsiblegaming.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>Responsible Gaming</div>
          </a>
        </div>

      </div>
    </div>
<nav class="navbar navbar-expand-lg navbar-light navbar-default  ">
  <!--<span class="menu-select" id="menu-select">General</span>-->
  <div class="navbar-header d-lg-none clearfix">
    <button class="navbar-toggler" id="navbar-toggler--info"  type="button" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <i class="icon-bars navbar-toggler-icon"></i>
    </button>
    <div class="menu-select d-lg-none" id="menu-select--info"></div>
  </div>

  <div class="collapse navbar-collapse" >
    <ul class="navbar-nav mt-lg-0" style="list-style-type:none;">
      <li class="nav-item" >
        <a class="nav-link" href="faq-general.php" data-pg="general">General</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-deposit.php" data-pg="deposit">Deposits</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq_withdrawal.php" data-pg="faq_withdrawal">Withdrawal</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-games.php" data-pg="games">Gaming</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-technical.php"  data-pg="technical">Technical</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-banking.php" data-pg="banking">Banking</a>
      </li>
    </ul>
  </div>
</nav>


<div class="border-box">
  <!--<h4><strong>Banking</strong></h4>-->
  <p> <?php echo $s0['instansi']; ?> dikenal dengan transaksi yang efisien dan aman. Kelompok staf profesional disediakan untuk memastikan bahwa semua transaksi akan berjalan lancar dan aman..</p>

  <h5><strong>BANK LISTS</strong></h5>
  <p>Berikut adalah daftar detail perbankan yang disediakan  <?php echo $s0['instansi']; ?> Indonesia : </p>
  <div class="table-responsive ">
    <table class="table table-default"  >
      <thead>
        <tr>
          <th rowspan="2">
          nama bank          </th>
          <th rowspan="2">
          Status          </th>
          <th rowspan="2">transaksi</th>
          <th rowspan="2">Metode Perbankan</th>
          <th colspan="2">limit transaksi</th>
                     <th rowspan="2">waktu proses</th> 
                  </tr>
        <tr>
          <th>
          Min  
          </th>
          <th>
          Max          </th>
        </tr>
      </thead>
      <tbody>
      
        
          <tr class="first-child">
            <td rowspan="2">
              BCA<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            Active            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>50,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                    <tr>
            <td>Withdrawal</td>
            <td>Withdrawal</td>
            <td>50,000.00</td> <!--TODO add currency and use currency pipe-->
            <td>100,000,000.00</td> <!--TODO add currency and use currency pipe-->
                        <td>5 mins</td>
                      </tr>
                 
          <tr class="first-child">
            <td rowspan="2">
              Mandiri<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            Active            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>30,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                    <tr>
            <td>Withdrawal</td>
            <td>Withdrawal</td>
            <td>50,000.00</td> <!--TODO add currency and use currency pipe-->
            <td>100,000,000.00</td> <!--TODO add currency and use currency pipe-->
                        <td>5 mins</td>
                      </tr>
                 
          <tr class="first-child">
            <td rowspan="2">
              BNI<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            Active            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>30,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                    <tr>
            <td>Withdrawal</td>
            <td>Withdrawal</td>
            <td>50,000.00</td> <!--TODO add currency and use currency pipe-->
            <td>100,000,000.00</td> <!--TODO add currency and use currency pipe-->
                        <td>5 mins</td>
                      </tr>
                 
          <tr class="first-child">
            <td rowspan="2">
              BRI<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            Active            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>30,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                    <tr>
            <td>Withdrawal</td>
            <td>Withdrawal</td>
            <td>50,000.00</td> <!--TODO add currency and use currency pipe-->
            <td>100,000,000.00</td> <!--TODO add currency and use currency pipe-->
                        <td>5 mins</td>
                      </tr>
                 
          <tr class="first-child">
            <td rowspan="2">
              Danamon<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            Active            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>30,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                    <tr>
            <td>Withdrawal</td>
            <td>Withdrawal</td>
            <td>50,000.00</td> <!--TODO add currency and use currency pipe-->
            <td>100,000,000.00</td> <!--TODO add currency and use currency pipe-->
                        <td>5 mins</td>
                      </tr>
                 
          <tr class="first-child">
            <td rowspan="2">
              Panin<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            Active            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>30,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                    <tr>
            <td>Withdrawal</td>
            <td>Withdrawal</td>
            <td>50,000.00</td> <!--TODO add currency and use currency pipe-->
            <td>100,000,000.00</td> <!--TODO add currency and use currency pipe-->
                        <td>5 mins</td>
                      </tr>
                 
          <tr class="first-child">
            <td rowspan="2">
              CIMB NIAGA<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            Active            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>30,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                    <tr>
            <td>Withdrawal</td>
            <td>Withdrawal</td>
            <td>50,000.00</td> <!--TODO add currency and use currency pipe-->
            <td>100,000,000.00</td> <!--TODO add currency and use currency pipe-->
                        <td>5 mins</td>
                      </tr>
                 
          <tr class="first-child">
            <td rowspan="2">
              QRIS<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            info.Inactive            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>5,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                      <tr>
              <td>Withdrawal</td>
              <td>-</td>
              <td>-</td> <!--TODO add currency and use currency pipe-->
              <td>-</td> <!--TODO add currency and use currency pipe-->
                            <td>-</td>
                          </tr>
                 
          <tr class="first-child">
            <td rowspan="2">
              SEABANK<br />
              <div  class="img-fluid"></div>
            </td>
            <td rowspan="2">
            Active            </td>
                        <td>Deposit</td>
            <td>Deposit</td>
            <td>50,000.00</td>
            <td>30,000,000.00</td>
                        <td>1 mins</td>
                                  </tr>

                      <tr>
              <td>Withdrawal</td>
              <td>-</td>
              <td>-</td> <!--TODO add currency and use currency pipe-->
              <td>-</td> <!--TODO add currency and use currency pipe-->
                            <td>-</td>
                          </tr>
                 
      </tbody>
    </table>

  </div>
</div>
  </div>
</div>



<script>
  $(function(){
    var pg ="banking"; 
    var selectedMenu=  $('.navbar-nav .nav-link').filter(function(){ 
          return $(this).data("pg").toLowerCase() == pg.toLowerCase();
        }).text();
      $('#menu-select--info').text(selectedMenu);
    

    $('#navbar-toggler--info').click(function(){
        $('.info .navbar-collapse').toggleClass('show in');

    }) 
  });
</script>

            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>