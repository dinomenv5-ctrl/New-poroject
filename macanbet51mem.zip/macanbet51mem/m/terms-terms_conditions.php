<?php 
include 'session.php'; 
include 'header.php';?>

<div class="container-wrapper info ">
  <div class="container container-box info-view">
    <div class="info-nav nav-icon">
      <div class="row no-gutters">
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="terms-terms_conditions.php" class="active">
            <div>
              <i class="icon-clipboard"></i>
            </div>
            <div>TERMS & CONDITIONS </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-general.php" class="">

            <div> <i class="icon-help-circle"></i></div>

            <div>FAQ</div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                  <a href="how-sportsbook.php" class="">
            <div><i class="icon-list-numbered"></i> </div>
            <div>HOW TO PLAY </div>
          </a>
        </div>
         
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-referral.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>REFERRAL</div>
          </a>
        </div>
                <div>
          <a href="responsiblegaming.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>Responsible Gaming</div>
          </a>
        </div>

      </div>
    </div>
<nav class="navbar navbar-expand-lg navbar-light navbar-default  ">
  <!--<span class="menu-select" id="menu-select">General</span>-->
  <div class="navbar-header d-lg-none clearfix">
    <button class="navbar-toggler"  id="navbar-toggler--info" type="button" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <i class="icon-bars navbar-toggler-icon"></i>
    </button>
    <div class="menu-select d-lg-none"  id="menu-select--info">Terms & Conditions</div>
  </div>

  <div class="collapse navbar-collapse" >
    <ul class="navbar-nav mt-lg-0" style="list-style-type:none;">
      <li class="nav-item"  >
        <a class="nav-link" data-pg="terms_conditions" href="terms-terms_conditions.php" routerLink="https://sanjikaido.com/info/terms-terms_conditions" (click)="strSelectedMenu='Terms & Conditions';">Terms & Conditions</a>
      </li> 
    </ul>
  </div>
</nav> 



<div class="panel-group" id="info_accordion">
    <!-- First Panel -->
                           <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse1">
             <h5 class="panel-title info" >
                SYARAT DAN KETENTUAN <?php echo $s0['instansi']; ?>
             </h5>
        </div>
        <div id="collapse1" class="panel-collapse collapse">
            <div class="info panel-body">
                <ol style="box-sizing: border-box; margin: 0px; list-style: none; padding: 0px; font-family: digital_sans_ef_medium; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;"><li style="box-sizing: border-box;">- Pendaftar harus berusia 17 tahun keatas.</li><li style="box-sizing: border-box;">- Member wajib memberikan data informasi dengan lengkap dalam formulir yang tersedia( Nomor telepon, Nomor dan Nama Rekening )</li><li style="box-sizing: border-box;">- Proses Transaksi hanya bisa dilakukan pada jam bank online.</li><li style="box-sizing: border-box;">- Proses Deposit dilakukan melalui Mesin ATM, Internet banking, dan sms ( Diluar dari ini, kami menolak untuk melakukan proses deposit ).</li><li style="box-sizing: border-box;">- Kami berhak menolak proses setiap member yang memanipulasi atau mencurigakan.</li><li style="box-sizing: border-box;">- Peringatan keras bagi bonus hunter / player hantu / betting syndicate tidak terima disini. Jika terindikasi adanya keganjilan dalam betlist maka kami berhak menutup akun dan menyita seluruh kredit yang ada</li><li style="box-sizing: border-box;">- Kami melarang keras penggunaan perangkat, software, "bots", program atau metode apapun yang diaplikasikan untuk menghasilkan taruhan yang tidak wajar dan merugikan pihak kami. Penutupan account akan dilakukan tanpa adanya pemberitahuan terlebih dahulu dan semua kemenangan dari taruhan yang dilakukan akan dibatalkan dan sisa saldo akan dihanguskan.</li><li style="box-sizing: border-box;">- Kami tidak menerima komplain atas Void dan Reject dalam permainan, Sebab itu diluar tanggung jawab kami.</li><li style="box-sizing: border-box;">- Kami tidak menerima pendaftaran apabila anda menggunakan IP Address Luar Negri (Malaysia, Singapore, Hongkong, Cambodia, China).</li><li style="box-sizing: border-box;">- Proses Withdraw atau penarikan tidak dapat dilakukan apabila informasi rekening tertuju berbeda seperti informasi rekening pada database kami.</li></ol>
            </div>
        </div>
    </div>
                   <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse2">
             <h5 class="panel-title info" >
                MAKS DEPO &amp; WD
             </h5>
        </div>
        <div id="collapse2" class="panel-collapse collapse">
            <div class="info panel-body">
                <p><span style="background-color: transparent;">- MAKSIMAL DEPOSIT <?php echo $s0['instansi']; ?> DALAM SATU FORMULIR ADALAH 100.000.000 (BANK)<br>- WD KEMENANGAN MAKSIMAL DALAM SETIAP PERMAINAN ADALAH 100.000.000 (PENARIKAN VIA BANK) <br>&nbsp;(PENARIKAN ANTARBANK DIBAWAH 500.000 AKAN DIPOTONG BIAYA TRANSFER SESUAI KETENTUAN BANK BERSANGKUTAN)</span><br></p>
            </div>
        </div>
    </div>
                   <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse3">
             <h5 class="panel-title info" >
                WAJIB BUKTI TRANSFER
             </h5>
        </div>
        <div id="collapse3" class="panel-collapse collapse">
            <div class="info panel-body">
                <ul><li>MINIMAL DEPOSIT <br>EWALLET DAN PULSA : 25k<br>BANK : 25K<br>WAJIB MENCANTUMKAN BUKTI TRF DAN NAMA PENGIRIM YANG JELAS UNTUK MEMUDAHKAN PROSES DEPOSIT!</li><li>UNTUK MELAKUKAN RESET KATA SANDI, <?php echo $s0['instansi']; ?> BERHAK MEMINTA DATA LENGKAP PEMILIK AKUN YANG TERVERIFIKASI UNTUK MEMVALIDASI KEPEMILIKAN REKENING YANG SAH SEPERTI :<br>KTP, FOTO BUKU TABUNGAN, SCREENSHOT AKUN EWALLET ATAU DATA DIRI LAINNYA DENGAN NAMA REKENING YANG TERDAFTAR, DISERTAKAN BUKTI TRANSFER DEPOSIT MENGGUNAKAN BANK TERDAFTAR</li></ul><p><br></p><p><br></p>
            </div>
        </div>
    </div>
          </div>
  </div>
</div>



<script>
  $(function(){
    var pg ="terms_conditions"; 
    var selectedMenu=  $('.navbar-nav .nav-link').filter(function(){ 
          return $(this).data("pg").toLowerCase() == pg.toLowerCase();
        }).text();
      $('#menu-select--info').text(selectedMenu);
    

    $('#navbar-toggler--info').click(function(){
        $('.info .navbar-collapse').toggleClass('show in');

    }) 
  });
</script>
            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>