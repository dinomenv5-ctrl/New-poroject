<?php
$providerCode = isset($_GET['provider']) ? $_GET['provider'] : 'af';
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');
$sid = session_id();

// Ambil data SEO
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error($conn));
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../config/url_helper.php');
}
$urlweb = get_active_base_url();

// Cek Status Maintenance
$sql_m = "SELECT status FROM maintenance WHERE id = 1";
$result_m = $conn->query($sql_m);
if ($result_m->num_rows > 0) {
    $row_m = $result_m->fetch_assoc();
    if ($row_m["status"] == 1) {
        echo "<script>alert('Halaman sedang dalam pemeliharaan. Kembali ke halaman sebelumnya.'); window.history.back();</script>";
        exit();
    }
}

include "../m/header.php";

/**
 * DAFTAR PERMAINAN (ARRAY)
 * Edit bagian ini untuk menambah/mengurangi permainan
 */
$games = [
    ['title' => '12D', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/12D.jpg', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => '24D', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/24D.jpg', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => '36D', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/36D.jpg', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => '48D', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/48D.jpg', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => '60D', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/60D.png', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => 'Sicbo', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/sicbo.png', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => 'Oglok Ball', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/oglokball.png', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => 'Oglok Dice', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/oglokdice.png', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => '6 Colors', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/6colors.png', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => '12 Colors', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/12colors.png', 'type' => 'maintenance', 'icon' => 'live'],
    ['title' => 'ABJAD', 'img' => 'https://files.sitestatic.net/GameImage/LiveProviders/mobile/normal/abjad.png', 'type' => 'maintenance', 'icon' => 'hot'],
    ['title' => 'LV Number', 'img' => 'https://files.sitestatic.net/GameImage/LotteryProviders/mobile/normal/MPO_Number.png', 'type' => 'maintenance', 'icon' => 'none'],
    [
        'title' => 'sv388 Cock fight',
        'img' => 'https://files.sitestatic.net/GameImage/CFProviders/mobile/normal/cock_sv388.jpg?v=1.0',
        'type' => 'link',
        'url' => $urlweb . '/gameplay/opengame/?gamecode=7475&providercode=S6',
        'icon' => 'hot'
    ],
    ['title' => 'WS168', 'img' => 'https://files.sitestatic.net/GameImage/CFProviders/mobile/normal/ws168_cf.jpg', 'type' => 'maintenance', 'icon' => 'hot'],
];
?>

<div class="container pt-1 games-category">
    <h2 class="title">LIVE GAMES</h2>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 image-grid">

            <?php foreach ($games as $game): ?>
                <div class="col-xs-4 col-sm-3 col-md-2 box">
                    <div class="game-wrapper">

                        <?php if ($game['icon'] == 'live'): ?>
                            <div style="position:absolute;right:0;top:0;z-index: 9;">
                                <img src="https://files.sitestatic.net/images/live_icon.gif" ref="live" height="25px">
                            </div>
                        <?php elseif ($game['icon'] == 'hot'): ?>
                            <div class="hot-tag"></div>
                        <?php endif; ?>

                        <?php if ($game['type'] == 'maintenance'): ?>
                            <div class="game maintenance-alert">
                                <img class="img-fluid lazy" alt="<?php echo $game['title']; ?>" data-src="<?php echo $game['img']; ?>" src="" />
                                <div class="loader-b" *ngIf="!showEle"></div>
                                <?php if (!empty($game['title']) && !in_array($game['title'], ['LV NUMBER GAME', 'COD GAMING', 'WS168'])): ?>
                                    <div class="g-title"><?php echo $game['title']; ?></div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo $game['url']; ?>" rel="opener" class="game" target="_blank">
                                <img class="img-fluid lazy" alt="<?php echo $game['title']; ?>" data-src="<?php echo $game['img']; ?>" src="" />
                                <div class="loader-b" *ngIf="!showEle"></div>
                            </a>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endforeach; ?>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>