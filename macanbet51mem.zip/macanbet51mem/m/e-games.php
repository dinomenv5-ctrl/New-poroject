<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');

$sid = session_id();
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error($conn));
$s0 = mysqli_fetch_array($sql_0);

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../config/url_helper.php');
}
$urlweb = get_active_base_url();
$pengguna = $s0['user'];
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d');

// Catat statistik untuk E-Games
mysqli_query($conn, "INSERT INTO `tb_stat` (`ip`, `date`, `hits`, `page`, `user`) VALUES ('$ip', '$date', 1, 'E-Games', '$pengguna')");

include "header.php";
?>

<div class="container pt-1 games-category">
    <h2 class="title">e-games</h2>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 image-grid">
            <?php
            // Query mengambil provider yang memiliki kategori ot, pk, table games, atau video pokers
            $categories = "'ot', 'pk', 'table games', 'video pokers'";
            $result = mysqli_query($conn, "SELECT DISTINCT code, name, status FROM `tb_provider` 
                                   WHERE `game_category` IN ($categories)
                                   ORDER BY FIELD(code, 'PR', 'PG', 'HB') DESC, name ASC");

            if (!$result) {
                die("Query Error: " . mysqli_error($conn));
            }

            while ($rowProvider = mysqli_fetch_assoc($result)) {
                $provider_name = strtolower(str_replace(' ', '-', trim($rowProvider["name"])));
                $provider_code = strtolower($rowProvider["code"]);
                $provider_status = $rowProvider["status"];

                $media_src = $urlweb . '/uploads/prov/' . $provider_name . '.jpg';

                if ($provider_status == 0) {
                    $link = 'javascript:void(0)';
                    $onclick = "onclick=\"alert('Provider sedang dalam maintenance.')\"";
                } else {
                    $link = $urlweb . '/m/e-games/game.php?provider=' . $provider_code;
                    $onclick = '';
                }

                echo '
        <div class="col-xs-4 col-sm-3 col-md-2 box">
            <div class="game-wrapper">
                <a href="' . $link . '" ' . $onclick . ' rel="opener" class="game">
                    <img class="img-fluid" alt="' . strtoupper($rowProvider["name"]) . '" src="' . $media_src . '" />
                    <div class="g-title" style="font-size: smaller;">' . strtoupper($rowProvider["name"]) . '</div>
                </a>
            </div>
        </div>';
            }
            ?>
        </div>
    </div>
</div>
<?php include "footer.php"; ?>