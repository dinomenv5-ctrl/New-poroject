<?php 
include 'session.php';
include 'header.php';?>

<div class="container-wrapper info ">
  <div class="container container-box info-view">
    <div class="info-nav nav-icon">
      <div class="row no-gutters">
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="terms-terms_conditions.php" class="">
            <div>
              <i class="icon-clipboard"></i>
            </div>
            <div>TERMS & CONDITIONS </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-general.php" class="">

            <div> <i class="icon-help-circle"></i></div>

            <div>FAQ</div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                  <a href="how-sportsbook.php" class="">
            <div><i class="icon-list-numbered"></i> </div>
            <div>HOW TO PLAY </div>
          </a>
        </div>
         
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-referral.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>REFERRAL</div>
          </a>
        </div>
                <div>
          <a href="info.php" class="active">
            <div><i class="icon-clipboard1"></i></div>

            <div>Responsible Gaming</div>
          </a>
        </div>

      </div>
    </div>
    <div class="border-box">
        <h3> Tanggung Jawab Bertaruh</h3>
        <p>
            Sebagai Kasino Premium Malaysia, kami menangani Game Online yang Bertanggung Jawab untuk setiap pemain kami. Kami memiliki lisensi dari otoritas terkenal. Ini juga berarti bahwa kami harus sangat ketat dalam mengawasi para pemain dan waktu yang mereka habiskan untuk online.        </p>
        <p>
            Kami di SGPSLOT Referral mengetahui daya tarik dari online dan bertaruh pada game lintas kategori tinggi. Selain itu, kemewahan dan sensasi kemenangan bahkan dapat mendorong penumpang untuk terus menawar secara teratur atau untuk waktu yang lama.        </p>
        <p>
            Di sisi lain, kami menyadari penumpang yang kehilangan semua Bettingan mereka tanpa kendali. Dengan demikian, kami telah memastikan untuk menemukan berbagai metode yang memungkinkan Game Online secara bertanggung jawab.        </p>
        <h4> Langkah-langkah yang diambil oleh SGPSLOT Referral </h4>
        <ol>
            <li>
                <p><b>Batasi Bettingan Secara Otomatis :</b> Kami merasa bahwa untuk membantu Anda mengekang aktivitas Game Online Anda, cara terbaik dan paling praktis adalah dengan membatasi deposit. Ini sudah efektif, dan ditetapkan maksimal 1000 Ringgit. Setelah Anda mencapai batas ini per hari, Anda tidak akan dapat bertaruh atau membelanjakan uang lagi. Karena situs kami hanya mengizinkan satu USER ID per kepala, kami juga tidak akan mengizinkan Anda untuk mencoba dari akun lain mana pun.                </p>
            </li>
            <li>
                <p><b>Tetapkan Batas :</b> Ini adalah metode kedua yang kami gunakan. Sebagai pemain, Anda menetapkan batas pengeluaran harian, mingguan, dan bulanan Anda. Inilah yang harus Anda lakukan sekali di awal bulan. Setelah Anda mencapai level ini, Anda tidak bisa bertaruh lebih banyak. Kami menyarankan metode ini kepada setiap gamer baru atau pemula untuk berlatih.</p>
            </li>
            <li>
                <p><b>Keluhan Masalah Game Online :</b> Di situs kami, kami mendapatkan pemain yang sangat menyukai situs kami dan permainannya. Namun, cinta mereka terkadang melebihi kapasitas pengeluaran mereka. Mereka mungkin akhirnya menjadi masalah bagi seluruh keluarga mereka. Di sinilah layanan hotline 24 jam kami akan berguna.</p>
            </li>
        </ol>
        <p>Manajemen bankroll adalah sesuatu yang perlu dikerjakan semua orang sebelum datang untuk bermain online.</p>

        <h4>Tanda-Tanda Masalah Game</h4>
        <p>Sebagai anggota yang bangga dari Game Online yang Bertanggung Jawab, perusahaan kami memiliki kebijakan yang kuat tentang cara membantu orang berjudi dengan hati-hati. Ini adalah tanda-tanda masalah game yang kami tawarkan bantuan dalam:</p>
        <ul>
            <li>Meminjam atau menjual perhiasan dan barang pribadi untuk berjudi</li>
            <li>Mencuri dan/atau menjual barang yang bukan milik Anda</li>
            <li>Sulit untuk menolak Game Online</li>
            <li>Terus-menerus berpikir tentang Game Online</li>
            <li>Menghabiskan lebih dari yang bisa Anda menangkan</li>
            <li>Berpikir bahwa Anda dapat membayar kembali pinjaman dengan berjudi dan menang</li>
            <li>Dengan asumsi bahwa game online dalam waktu lama dapat membantu dalam menang besar</li>
            <li>Membuat diri Anda terisolasi dari keluarga dan lingkaran sosial</li>
            <li>Mengurangi interaksi dengan orang lain</li>
            <li>Merasa bersalah tentang sikap tidak bertanggung jawab terhadap keluarga atau pekerjaan</li>
        </ul>
        <p>Jika Anda memiliki atau melihat seseorang dengan perubahan perilaku ini, jangan ragu untuk menghubungi kami. Ini adalah beberapa di antara masalah lain seperti yang diposting oleh Dewan Game Online yang Bertanggung Jawab</p>

        <h4>Panggilan untuk Pengecualian Diri</h4>
        <p>Kami menghargainya jika Anda ingin mengecualikan akun Anda sendiri untuk beberapa waktu. Cukup hubungi kami di nomor dukungan pelanggan kami, dan kami akan dengan senang hati membantu.</p>

        <h4>Mencari Bantuan Profesional</h4>
        <br>
        <p><b>BeGambleAware</b></p>

        <p>BeGambleAware is an international NGO that is constantly helping gamblers to reduce or quit any addicted gambling activities. There is a big different between casual playing and hard-core gambling, and this is usually unnoticed by any gambler themselves. The three aspects of BeGambleAware’s mission is, firstly, to instruct the public about the importance and danger of addicted gambling. Second, to enhance the activities to prevent the factors of the issue. Lastly, saving people who are currently facing gambling-related issues by offering professional assist, counsel, and guidance.            <br><br>
            info.Name: BeGambleAware <br>
            info.Contact Number: +44 808 802 0133 <br>
            info.Email: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="aac3c4ccc5eacdcbc7c8c6cfcbddcbd8cf84c5d8cd">[email&#160;protected]</a> <br>
            info.Website: https://about.gambleaware.org/
        </p>

        <p><b>GamCare</b></p>

        <p> One of the leading providers of information, counsel, and help for the people facing any problems related to gambling. GamCare has been offering the sympathetic services to the people since they started operating in 1997. They have been helping people by offering one-to-one counsel, advice, emotional support, and more. People may contact GamCare via phone call, email, forums, or even the 24/7 live chat on their official website.            <br><br>
            info.Name: GamCare <br>
            info.Contact Number: +44 207 801 7000 <br>
            info.Email: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="caa3a4aca58aadaba7a9abb8afe4a5b8ade4bfa1">[email&#160;protected]</a> <br>
            info.Website: https://www.gamcare.org.uk/
        </p>
    </div>
  </div>
</div>



<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
  $(function(){
    var pg =""; 
    var selectedMenu=  $('.navbar-nav .nav-link').filter(function(){ 
          return $(this).data("pg").toLowerCase() == pg.toLowerCase();
        }).text();
      $('#menu-select--info').text(selectedMenu);
    

    $('#navbar-toggler--info').click(function(){
        $('.info .navbar-collapse').toggleClass('show in');

    }) 
  });
</script>
            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>