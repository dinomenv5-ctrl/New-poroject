<?php 
include 'session.php';
include 'header.php';?>

<div class="container-wrapper info ">
  <div class="container container-box info-view">
    <div class="info-nav nav-icon">
      <div class="row no-gutters">
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="terms-terms_conditions.php" class="">
            <div>
              <i class="icon-clipboard"></i>
            </div>
            <div>TERMS & CONDITIONS </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-general.php" class="active">

            <div> <i class="icon-help-circle"></i></div>

            <div>FAQ</div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                  <a href="how-sportsbook.php" class="">
            <div><i class="icon-list-numbered"></i> </div>
            <div>HOW TO PLAY </div>
          </a>
        </div>
         
        <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
          <a href="faq-referral.php" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>REFERRAL</div>
          </a>
        </div>
                <div>
          <a href="responsiblegaming" class="">
            <div><i class="icon-clipboard1"></i></div>

            <div>Responsible Gaming</div>
          </a>
        </div>

      </div>
    </div>
<nav class="navbar navbar-expand-lg navbar-light navbar-default  ">
  <!--<span class="menu-select" id="menu-select">General</span>-->
  <div class="navbar-header d-lg-none clearfix">
    <button class="navbar-toggler" id="navbar-toggler--info"  type="button" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <i class="icon-bars navbar-toggler-icon"></i>
    </button>
    <div class="menu-select d-lg-none" id="menu-select--info"></div>
  </div>

  <div class="collapse navbar-collapse" >
    <ul class="navbar-nav mt-lg-0" style="list-style-type:none;">
      <li class="nav-item" >
        <a class="nav-link" href="faq-general.php" data-pg="general">General</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-deposit.php" data-pg="deposit">Deposits</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq_withdrawal.php" data-pg="faq_withdrawal">Withdrawal</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-games.php" data-pg="games">Gaming</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-technical.php"  data-pg="technical">Technical</a>
      </li>
      <li class="nav-item" >
        <a class="nav-link" href="faq-banking.php" data-pg="banking">Banking</a>
      </li>
    </ul>
  </div>
</nav>


<div class="panel-group" id="info_accordion">
    <!-- First Panel -->
        <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse1">
             <h5 class="panel-title info" >
                1. Bagaimana cara melakukan penarikan dana dari akun <?php echo $s0['instansi']; ?>?              </h5>
        </div>
                    <div id="collapse1" class="panel-collapse collapse">
                <div class="info panel-body">
                    <p>Penarikan dana dapat ditransfer ke rekening/akun Anda melalui kartu debit atau transfer bank.</p>                </div>
            </div>
            </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse2">
             <h5 class="panel-title info" >
                2. Adakah persyaratan untuk rekening bank yang saya gunakan untuk transaksi Withdrawal?              </h5>
        </div>
                    <div id="collapse2" class="panel-collapse collapse">
                <div class="info panel-body">
                    <p>Penting untuk dicatat bahwa nama penerima pembayaran yang dimasukkan untuk penarikan harus sama dengan nama akun yang tercantum di <?php echo $s0['instansi']; ?>. Harap perhatikan bahwa <?php echo $s0['instansi']; ?> memiliki hak untuk menolak segala jenis transaksi yang dilakukan oleh nama pihak ketiga dan permintaan penarikan yang tidak memenuhi kebijakan yang disebutkan akan segera ditolak. </p>                </div>
            </div>
            </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse3">
             <h5 class="panel-title info" >
                3. Mata uang apa yang dapat diterima oleh <?php echo $s0['instansi']; ?>?              </h5>
        </div>
                    <div id="collapse3" class="panel-collapse collapse">
                <div class="info panel-body">
                    <p><?php echo $s0['instansi']; ?> untuk saat ini hanya menerima  Indonesia Baht mata uang Rupiah.</p>                </div>
            </div>
            </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse4">
             <h5 class="panel-title info" >
                4. Berapa lama untuk memproses transaksi penarikan?              </h5>
        </div>
                    <div id="collapse4" class="panel-collapse collapse">
                <div class="info panel-body">
                    <p>Transaksi penarikan akan diproses dalam waktu 5 (lima) menit, namun pemrosesan mungkin memakan waktu lebih lama selama akhir pekan / offline bank / hari libur bank atau jika verifikasi akun diperlukan untuk beberapa kasus.</p>                </div>
            </div>
            </div>
     <div class="panel info panel-default">
        <div class="info panel-heading" data-toggle="collapse" data-parent="#info_accordion" data-target="#collapse5">
             <h5 class="panel-title info" >
                5. Bagaimana cara withdraw?             </h5>
        </div>
                    <div id="collapse5" class="panel-collapse collapse">
                <div class="info panel-body">
                    <ol>
                  <li>Silakan masuk ke situs web <?php echo $s0['instansi']; ?> dan pilih "Transaksi> Penarikan" pada Tab menu.</li>
                  <li>Isi jumlah penarikan tanpa simbol titik / koma. Misalnya: 1000 (seribu Rupiah). </li>
                  <li>Pilih jenis bank penarikan dan pilih opsi bank.</li>
                  <li>Formulir penarikan harus diisi menggunakan data yang benar / benar (nama lengkap, nomor rekening bank, nama bank, dll).</li>
                  <li>Pilih "Kirim" dan harap tunggu sementara penarikan Anda sedang diproses.</li>
                  
                  <br>
                </ol>
                <p>
                  <strong>Harap dicatat bahwa setiap transaksi penarikan (masuk / keluar dari promosi) harus disesuaikan dengan kebijakan yang telah ditentukan. <?php echo $s0['instansi']; ?> memiliki hak untuk menolak segala jenis transaksi jika tidak mematuhi kebijakan. Untuk informasi lebih lanjut silakan hubungi perwakilan layanan pelanggan kami (online 24 jam). </strong>
                </p>                </div>
            </div>
            </div>
 
</div>
  </div>
</div>



<script>
  $(function(){
    var pg ="faq_withdrawal"; 
    var selectedMenu=  $('.navbar-nav .nav-link').filter(function(){ 
          return $(this).data("pg").toLowerCase() == pg.toLowerCase();
        }).text();
      $('#menu-select--info').text(selectedMenu);
    

    $('#navbar-toggler--info').click(function(){
        $('.info .navbar-collapse').toggleClass('show in');

    }) 
  });
</script>
            </tbody>
        </table>
    </div>
</div>


        <?php include 'footer.php';?>