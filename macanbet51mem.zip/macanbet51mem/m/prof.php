<?php
/* =========================
   SESSION & KONEKSI
========================= */
session_start();
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 0);
date_default_timezone_set("Asia/Jakarta");

include(__DIR__ . '/../config/koneksi.php');

if (!$conn) {
    die("Koneksi database gagal.");
}

/* =========================
   CEK LOGIN
========================= */
if (!isset($_SESSION['user'])) {
    header("Location: /");
    exit;
}

$username = mysqli_real_escape_string($conn, $_SESSION['user']);
$query = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$username'");
$user = mysqli_fetch_assoc($query);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <meta name="viewport" content="width-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h4>Profile User</h4>
    <hr>

    <p><b>Username:</b> <?php echo htmlspecialchars($user['username'] ?? ''); ?></p>
    <p><b>Email:</b> <?php echo htmlspecialchars($user['email'] ?? '-'); ?></p>
    <p><b>Saldo:</b> Rp <?php echo isset($user['saldo']) ? number_format($user['saldo']) : '0'; ?></p>

    <hr>
    <a href="change-password.php" class="btn btn-primary btn-block">Ubah Kata Sandi</a>
</div>

</body>
</html>
