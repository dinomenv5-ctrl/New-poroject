<?php
/**
 * Halaman Referral Downline
 * Lokasi: /m/referral-downline.php
 */

include 'session.php';

if (empty($_SESSION['user']) || empty($u['cuid'])) {
    header('Location: /m/index');
    exit;
}

$userID  = (int) $u['cuid'];
$username = isset($u['username']) ? trim((string) $u['username']) : '';

/* Pastikan koneksi tersedia. */
if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Koneksi database tidak tersedia.');
}

/* URL situs: gunakan tb_seo/session bila tersedia, atau bentuk dari domain aktif. */
if (empty($urlweb)) {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'panen377.xyz';
    $urlweb = $scheme . '://' . $host;
}
$urlweb = rtrim((string) $urlweb, '/');

/**
 * Membuat kode referral unik saat akun belum memilikinya.
 * Kolom yang digunakan mengikuti script lama: tb_user.referral_code.
 */
function generateReferralCode(mysqli $conn, int $userID, string $username = ''): string
{
    $cleanUsername = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $username));
    $prefix = substr($cleanUsername, 0, 5);

    if ($prefix === '') {
        $prefix = 'REF';
    }

    for ($attempt = 0; $attempt < 10; $attempt++) {
        try {
            $random = strtoupper(bin2hex(random_bytes(3)));
        } catch (Throwable $e) {
            $random = strtoupper(substr(md5(uniqid((string) mt_rand(), true)), 0, 6));
        }

        $candidate = substr($prefix . $random, 0, 12);

        $check = $conn->prepare(
            "SELECT cuid FROM tb_user WHERE referral_code = ? AND cuid <> ? LIMIT 1"
        );

        if (!$check) {
            return '';
        }

        $check->bind_param('si', $candidate, $userID);
        $check->execute();
        $check->store_result();
        $exists = $check->num_rows > 0;
        $check->close();

        if (!$exists) {
            $update = $conn->prepare(
                "UPDATE tb_user
                 SET referral_code = ?
                 WHERE cuid = ?
                   AND (referral_code IS NULL OR referral_code = '')"
            );

            if (!$update) {
                return '';
            }

            $update->bind_param('si', $candidate, $userID);
            $success = $update->execute();
            $update->close();

            if ($success) {
                return $candidate;
            }
        }
    }

    return '';
}

/* Ambil ulang kode dari database supaya nilainya selalu terbaru. */
$myCode = '';

$getCode = $conn->prepare(
    "SELECT referral_code FROM tb_user WHERE cuid = ? LIMIT 1"
);

if ($getCode) {
    $getCode->bind_param('i', $userID);
    $getCode->execute();
    $getCode->bind_result($dbReferralCode);

    if ($getCode->fetch()) {
        $myCode = trim((string) $dbReferralCode);
    }

    $getCode->close();
}

/* Buat otomatis hanya ketika kode masih kosong. */
if ($myCode === '') {
    $myCode = generateReferralCode($conn, $userID, $username);
}

$myLink = $myCode !== ''
    ? $urlweb . '/m/register/?reff=' . rawurlencode($myCode)
    : '';

include 'header.php';
?>

<style>
.referral-page {
    width: 100%;
    min-height: calc(100vh - 150px);
    padding: 12px 10px 120px;
    box-sizing: border-box;
    overflow-x: hidden;
}

.referral-card {
    width: 100%;
    margin: 0 0 18px;
    padding: 16px;
    border-radius: 12px;
    box-sizing: border-box;
    background: #111;
    color: #fff;
}

.referral-card label {
    display: block;
    margin: 0 0 7px;
    color: #cdbb65;
    font-size: 18px;
    line-height: 1.35;
}

.referral-card input,
.referral-card input[readonly],
.referral-card input:focus,
.referral-card input:active {
    display: block;
    width: 100%;
    height: 46px;
    margin: 0 0 15px;
    padding: 8px 10px;
    border: 1px solid #d7bf55 !important;
    border-radius: 4px;
    box-sizing: border-box;
    background: #161616 !important;
    color: #f1d765 !important;
    -webkit-text-fill-color: #f1d765 !important;
    caret-color: #f1d765 !important;
    opacity: 1 !important;
    font-size: 15px;
    font-weight: 600;
    text-shadow: none !important;
    outline: none !important;
}

.referral-card input::selection {
    background: #f1d765;
    color: #111;
    -webkit-text-fill-color: #111;
}

.referral-card input::-moz-selection {
    background: #f1d765;
    color: #111;
}

.referral-copy {
    min-width: 145px;
    padding: 11px 18px;
    border: 0;
    border-radius: 6px;
    background: #ffc107;
    color: #fff;
    font-weight: 700;
    cursor: pointer;
}

.referral-copy:disabled {
    opacity: .55;
    cursor: not-allowed;
}

.referral-message {
    margin-top: 12px;
    padding: 10px 12px;
    border-radius: 6px;
    background: rgba(255, 193, 7, .12);
    color: #ffdd57;
    line-height: 1.5;
}

.referral-search {
    margin-bottom: 14px;
}

.referral-table-wrap {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    border: 1px solid #555;
    box-sizing: border-box;
}

#referral-table {
    width: 100%;
    min-width: 680px;
    margin: 0;
    border-collapse: collapse;
    background: #111;
    color: #fff;
}

#referral-table th,
#referral-table td {
    padding: 11px 9px;
    border: 1px solid #ddd;
    text-align: left;
    white-space: nowrap;
    vertical-align: middle;
}

#referral-table th {
    background: #050505;
    font-weight: 700;
}

#referral-table td {
    background: #111;
}

.referral-empty {
    text-align: center !important;
    color: #ddd;
}

@media (max-width: 767px) {
    .referral-page {
        padding-right: 0;
        padding-left: 0;
    }

    .referral-card {
        border-radius: 0;
    }

    .referral-search {
        padding: 0 10px;
    }

    .referral-table-wrap {
        border-right: 0;
        border-left: 0;
    }
}
</style>

<div class="tab-pane active referral-page">
    <div class="referral-card">
        <label for="refCode">Kode Referral Anda</label>
        <input
            id="refCode"
            type="text"
            value="<?php echo htmlspecialchars($myCode, ENT_QUOTES, 'UTF-8'); ?>"
            readonly
        >

        <label for="refLink">Link Referral Anda</label>
        <input
            id="refLink"
            type="text"
            value="<?php echo htmlspecialchars($myLink, ENT_QUOTES, 'UTF-8'); ?>"
            readonly
        >

        <button
            type="button"
            class="referral-copy"
            onclick="copyReferralLink()"
            <?php echo $myLink === '' ? 'disabled' : ''; ?>
        >
            Copy Link
        </button>

        <?php if ($myCode === ''): ?>
            <div class="referral-message">
                Kode referral belum dapat dibuat. Pastikan kolom
                <strong>referral_code</strong> tersedia pada tabel <strong>tb_user</strong>.
            </div>
        <?php endif; ?>
    </div>

    <div class="referral-search">
        <button
            type="button"
            class="btn btn-primary"
            onclick="window.location.reload()"
        >
            Cari
        </button>
    </div>

    <div class="referral-table-wrap">
        <table id="referral-table">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Deposit</th>
                    <th>Transaksi Pertama</th>
                    <th>Transaksi Terakhir</th>
                </tr>
            </thead>
            <tbody>
            <?php
            /*
             * Downline dibaca dari:
             * tb_user.referral_user_id = ID pemilik referral.
             *
             * Deposit dibaca dari tb_transaksi:
             * jenis = 1 dan status = 1.
             */
            $sql = "
                SELECT
                    u.username,
                    COUNT(t.cuid) AS jumlah_deposit,
                    MIN(t.date) AS tanggal_pertama,
                    MAX(t.date) AS tanggal_terakhir
                FROM tb_user AS u
                LEFT JOIN tb_transaksi AS t
                    ON t.userID = u.cuid
                   AND t.jenis = 1
                   AND t.status = 1
                WHERE u.referral_user_id = ?
                GROUP BY u.cuid, u.username
                ORDER BY u.cuid DESC
            ";

            $stmt = $conn->prepare($sql);

            if (!$stmt) {
                echo '<tr><td class="referral-empty" colspan="4">'
                    . 'Data referral belum dapat dimuat.'
                    . '</td></tr>';

                error_log('Referral prepare gagal: ' . $conn->error);
            } else {
                $stmt->bind_param('i', $userID);

                if (!$stmt->execute()) {
                    echo '<tr><td class="referral-empty" colspan="4">'
                        . 'Data referral belum dapat dimuat.'
                        . '</td></tr>';

                    error_log('Referral execute gagal: ' . $stmt->error);
                } else {
                    /*
                     * bind_result dipakai agar tetap berjalan di server
                     * yang tidak memiliki mysqlnd/get_result().
                     */
                    $stmt->bind_result(
                        $downlineUsername,
                        $jumlahDeposit,
                        $tanggalPertama,
                        $tanggalTerakhir
                    );

                    $hasRows = false;

                    while ($stmt->fetch()) {
                        $hasRows = true;

                        echo '<tr>';
                        echo '<td>'
                            . htmlspecialchars((string) $downlineUsername, ENT_QUOTES, 'UTF-8')
                            . '</td>';
                        echo '<td>'
                            . ((int) $jumlahDeposit > 0 ? 'Sudah' : 'Belum')
                            . '</td>';
                        echo '<td>'
                            . htmlspecialchars(
                                $tanggalPertama ? (string) $tanggalPertama : '-',
                                ENT_QUOTES,
                                'UTF-8'
                            )
                            . '</td>';
                        echo '<td>'
                            . htmlspecialchars(
                                $tanggalTerakhir ? (string) $tanggalTerakhir : '-',
                                ENT_QUOTES,
                                'UTF-8'
                            )
                            . '</td>';
                        echo '</tr>';
                    }

                    if (!$hasRows) {
                        echo '<tr><td class="referral-empty" colspan="4">'
                            . 'Tidak ada data referral.'
                            . '</td></tr>';
                    }
                }

                $stmt->close();
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function copyReferralLink() {
    var input = document.getElementById('refLink');

    if (!input || !input.value) {
        alert('Link referral belum tersedia.');
        return;
    }

    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(input.value)
            .then(function () {
                alert('Link referral berhasil disalin!');
            })
            .catch(function () {
                fallbackCopyReferral(input);
            });
        return;
    }

    fallbackCopyReferral(input);
}

function fallbackCopyReferral(input) {
    input.removeAttribute('readonly');
    input.focus();
    input.select();
    input.setSelectionRange(0, 99999);

    var copied = false;

    try {
        copied = document.execCommand('copy');
    } catch (error) {
        copied = false;
    }

    input.setAttribute('readonly', 'readonly');

    alert(
        copied
            ? 'Link referral berhasil disalin!'
            : 'Gagal menyalin otomatis. Silakan salin link secara manual.'
    );
}
</script>

<?php include 'footer.php'; ?>
