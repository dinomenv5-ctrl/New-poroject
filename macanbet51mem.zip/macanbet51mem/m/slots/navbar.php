<div style="overflow:hidden;width:100%;" class="scroller">
    <?php
    if (!function_exists('get_active_base_url')) {
        include(__DIR__ . '/../../config/url_helper.php');
    }
    $urlweb = get_active_base_url();

    // Fetch data from the tb_wprovider table dengan type='slot' dan status=1
    $query = "SELECT * FROM tb_wprovider
          WHERE type = 'slot' AND status = 1
          ORDER BY COALESCE(sort_order, 0) ASC, cuid ASC";
    $result = mysqli_query($conn, $query);
    // Check if the query was successful
    if ($result && mysqli_num_rows($result) > 0) {
        echo '<div class="row no-gutters text-center slider-content">';

        // Loop through the rows of the result set
        while ($row = mysqli_fetch_assoc($result)) {
            // Cek apakah provider punya game
            $gameCheckQuery = "SELECT COUNT(*) as count FROM tb_gamelist 
                          WHERE provider_code = '" . mysqli_real_escape_string($conn, $row['code']) . "' 
                          AND game_category = 'slot' AND status = 1";
            $gameCheckResult = mysqli_query($conn, $gameCheckQuery);
            $hasGames = false;
            if ($gameCheckResult) {
                $gameCheckRow = mysqli_fetch_assoc($gameCheckResult);
                $hasGames = (int)$gameCheckRow['count'] > 0;
            }

            // Hanya tampilkan jika punya game
            if ($hasGames) {
                echo '<div class="col">';
                echo '<a class="btn-box" href="' . site_url('m/slots/game/?provider=' . urlencode($row['code'])) . '" rel="opener">';

                // Gunakan image dari database jika ada, jika tidak gunakan fallback
                if (!empty($row['image'])) {
                    echo '<img alt="' . htmlspecialchars($row['name']) . '" src="' . htmlspecialchars($row['image']) . '" data-src="' . htmlspecialchars($row['image']) . '" height="75%" width="70%"/>';
                } else {
                    // Fallback ke uploads/provider jika tidak ada image di database
                    $provider_image = strtolower(str_replace(' ', '-', $row['name'])) . '.png';
                    echo '<img alt="' . htmlspecialchars($row['name']) . '" src="' . $urlweb . '/uploads/provider/' . $provider_image . '" data-src="' . $urlweb . '/uploads/provider/' . $provider_image . '" height="75%" width="70%"/>';
                }
                echo '<div class="text-center fs-sm game-title">' . htmlspecialchars($row['name']) . '</div>';
                echo '</a>';
                echo '</div>';
            }
        }

        echo '</div>';
    } else {
        // Handle database query error atau tidak ada data
        echo '<div class="row no-gutters text-center slider-content">';
        echo '<div class="col"><p class="text-muted">Tidak ada provider tersedia</p></div>';
        echo '</div>';
    }

    ?>

</div>