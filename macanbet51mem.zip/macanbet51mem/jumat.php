<?php
// index.php
include 'config/koneksi.php'; // Path ke file koneksi

// Query untuk mengambil user yang memiliki referral_count > 0 (dianggap Promotor)
$query = "SELECT cuid, username, full_name, referral_count FROM tb_user WHERE referral_count > 0 ORDER BY referral_count DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Promotor & Rujukan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            padding-top: 20px;
        }
        /* Mobile-friendly table view (optional but good practice) */
        @media (max-width: 768px) {
            .table-responsive {
                border: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">Daftar Promotor</h1>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Nama Lengkap</th>
                            <th>Jumlah Rujukan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                <td><span class="badge bg-primary"><?php echo $row['referral_count']; ?></span></td>
                                <td>
                                    <a href="referral_detail.php?promotor_id=<?php echo $row['cuid']; ?>" class="btn btn-sm btn-success">
                                        Lihat User
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info text-center">
                Tidak ada data promotor yang ditemukan.
            </div>
        <?php endif; ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
// Tutup koneksi
mysqli_close($conn);
?>