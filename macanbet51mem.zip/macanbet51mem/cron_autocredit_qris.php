<?php
/**
 * CRON JOB: Auto-Credit Deposit QRIS Pending — LAPIS KE-3
 *
 * ============ TUJUAN ============
 * Safety net terakhir untuk menjamin coin/saldo member MASUK OTOMATIS
 * setelah pembayaran QRIS sukses, walau:
 *   - Webhook AutoGopay (lapis 1) gagal/tidak sampai, atau
 *   - Member menutup halaman payment sehingga polling (lapis 2) berhenti,
 *     atau
 *   - Kredit pernah gagal sementara (DB error, dsb).
 *
 * ============ CARA PAKAI ============
 * MODE 1 — DAEMON 1 DETIK (disarankan untuk auto-credit tercepat):
 *   Jalankan proses sekali lewat systemd/supervisor/crontab @reboot, proses
 *   akan loop selamanya mengecek pending setiap 1 detik:
 *     php /path/ke/package_member/cron_autocredit_qris.php --daemon
 *   Interval loop bisa diatur via env LOOP_SECONDS (default 1 detik):
 *     LOOP_SECONDS=2 php cron_autocredit_qris.php --daemon
 *
 * MODE 2 — CRONTAB BERKALA (fallback bila daemon tidak memungkinkan):
 *   Jalankan lewat crontab (misal tiap 1-2 menit). Entri crontab yang
 *   disarankan (field: menit jam tgl bulan hari):
 *     [tiap 1-2 menit] [tiap jam] [tiap tgl] [tiap bulan] [tiap hari]
 *     php /path/ke/package_member/cron_autocredit_qris.php
 *     >> /path/logs/cron_qris.log 2>&1
 *
 * MODE 3 — via URL (opsional, dilindungi CRON_SECRET bila diisi):
 *   https://situs.com/cron_autocredit_qris.php?key=<CRON_SECRET>
 *   (mode daemon tidak tersedia via URL karena PHP-FPM punya timeout
 *   eksekusi; gunakan CLI untuk daemon)
 *
 * Bisa juga dijalankan manual sekali dari CLI:
 *   php cron_autocredit_qris.php
 *
 * ============ LOGIKA ============
 * 1. Ambil semua transaksi deposit QRIS AutoGopay pending (status=0,
 *    jenis=1, metode=QRIS, note AUTOGOPAY) yang sudah > N menit dari
 *    tanggal dibuat (default 5 menit).
 * 2. Untuk tiap transaksi, tanya status ke AutoGopay API:
 *    - success  -> AUTO-CREDIT via autocredit_helper (idempotent)
 *    - expired/failed -> tandai status=2 lokal
 *    - pending -> skip (tunggu interval berikutnya)
 * 3. Anti-truncation: reference penuh dibaca dari note 'ORDER: ...'
 *    (untuk orderId lama 17-18 char yang ter-truncate ke 16 char).
 * 4. Batasi umur transaksi yang dicheck (default 24 jam) supaya tidak
 *    membebani AutoGopay API dengan transaksi basi.
 */

date_default_timezone_set("Asia/Jakarta");

// Jalankan via CLI atau HTTP (dengan proteksi key bila diakses via web)
$isCli = php_sapi_name() === 'cli';

// ============================================================
// CONFIG
// ============================================================
$CRON_SECRET = ''; // isi jika cron dijalankan via URL agar tidak diakses publik (mis. 'kunci-rahasia-xxx')

$MIN_AGE_MINUTES = 5;   // proses transaksi pending yang sudah berumur >= 5 menit
$MAX_AGE_HOURS   = 24;  // abaikan transaksi lebih tua dari 24 jam (basah/basi)
$BATCH_LIMIT     = 30;  // max transaksi per run (jaga beban API AutoGopay)

// ============================================================
// MODE DAEMON: loop setiap N detik (default 1 detik)
//   php cron_autocredit_qris.php --daemon
//   LOOP_SECONDS=2 php cron_autocredit_qris.php --daemon  (interval custom)
// Saat mode daemon aktif, transaksi BARU (< MIN_AGE_MINUTES) juga langsung
// dicek supaya kredit bisa terjadi ~1 detik setelah pembayaran.
// ============================================================
$DAEMON_MODE  = $isCli && in_array('--daemon', $argv ?? [], true);
$LOOP_SECONDS = (int)(getenv('LOOP_SECONDS') ?: '1');
if ($LOOP_SECONDS < 1) {
    $LOOP_SECONDS = 1; // minimum 1 detik
}
if ($DAEMON_MODE) {
    // Daemon butuh interval kecil -> min age mengecil supaya transaksi baru
    // (< 5 menit) ikut dicek setiap detik.
    $MIN_AGE_MINUTES = 0;
    // Jangan die() di koneksi.php bila DB sempat down — daemon yang retry.
    $GLOBALS['AG_KONEKSI_NO_DIE'] = true;
    // Graceful stop pada SIGTERM/SIGINT (Ctrl+C / systemctl stop)
    if (function_exists('pcntl_signal')) {
        $GLOBALS['AG_CRON_STOP'] = false;
        pcntl_signal(SIGTERM, function () {
            $GLOBALS['AG_CRON_STOP'] = true;
        });
        pcntl_signal(SIGINT, function () {
            $GLOBALS['AG_CRON_STOP'] = true;
        });
        pcntl_async_signals(true);
    }
}

// Variabel runtime daemon (jumlah iterasi, start time)
$DAEMON_ITER     = 0;
$DAEMON_START_TS = time();

if (!$isCli) {
    // Proteksi bila diakses via web
    if (!empty($CRON_SECRET)) {
        $key = isset($_GET['key']) ? (string)$_GET['key'] : '';
        if (!hash_equals($CRON_SECRET, $key)) {
            http_response_code(403);
            die('Forbidden');
        }
    } else {
        // Tanpa secret: masih boleh dijalankan (idempotent & aman), tapi
        // sebaiknya set CRON_SECRET atau jalankan via CLI saja.
        // Catatan: proses ini hanya mengecek status dari AutoGopay API
        // dan credit transaksi yang BENAR-BENAR lunas — tidak bisa dipakai
        // untuk kredit transaksi palsu.
    }
    header('Content-Type: text/plain; charset=utf-8');
}

include(__DIR__ . '/config/koneksi.php');
include(__DIR__ . '/config/class_softgaming.php');
include(__DIR__ . '/config/class.autogopay.php');
include(__DIR__ . '/function/autocredit_helper.php');

// ============================================================
// LOG
// ============================================================
$logFile = __DIR__ . '/logs/autocredit_cron_' . date('Y-m-d') . '.log';
$logDir  = dirname($logFile);
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}

function cronLog($msg)
{
    global $logFile, $isCli;
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $msg;
    @file_put_contents($logFile, $line . "\n", FILE_APPEND);
    if ($isCli) {
        echo $line . "\n";
    }
}

// ============================================================
// Helper: parse status dari response getStatus AutoGopay
// ============================================================
if (!function_exists('ag_parse_status')) {
    function ag_parse_status($resp)
    {
        $status = '';
        if (is_array($resp)) {
            if (isset($resp['data']['status'])) {
                $status = strtolower(trim((string)$resp['data']['status']));
            } elseif (isset($resp['status']) && is_string($resp['status'])) {
                $status = strtolower(trim((string)$resp['status']));
            }
        }
        // Normalisasi variasi istilah gateway
        // [FIX E] diperluas: paid/settlement/complete/capture/done dsb = success
        $paidVariants = ['paid', 'settlement', 'paid settlement', 'setele', 'seteled', 'complete', 'completed', 'finish', 'finished', 'done', 'clear', 'cleared', 'capture', 'captured'];
        if (in_array($status, $paidVariants, true)) {
            $status = 'success';
        }
        $failVariants = ['cancel', 'cancelled', 'canceled', 'void', 'reversed', 'timeout', 'fail'];
        if (in_array($status, $failVariants, true)) {
            $status = 'failed';
        }
        return $status;
    }
}

// ============================================================
// Helper: sleep yang bisa diinterupsi sinyal stop (daemon).
// Return false bila sinyal stop (SIGTERM/SIGINT) diterima.
// ============================================================
if (!function_exists('ag_sleep_interruptible')) {
    function ag_sleep_interruptible($seconds)
    {
        $slept = 0;
        while ($slept < (int)$seconds) {
            if (!empty($GLOBALS['AG_CRON_STOP'])) {
                return false;
            }
            sleep(1);
            $slept++;
            if (function_exists('pcntl_signal_dispatch')) {
                pcntl_signal_dispatch();
            }
        }
        return empty($GLOBALS['AG_CRON_STOP']);
    }
}

// ============================================================
// MAIN (loop daemon bila --daemon, sekali saja bila tidak)
// ============================================================
do {
$DAEMON_ITER++;
if ($DAEMON_MODE && !empty($GLOBALS['AG_CRON_STOP'])) {
    cronLog("DAEMON: sinyal stop diterima — keluar rapi.");
    exit(0);
}
// ============================================================
// DAEMON DB GUARD: koneksi MySQL bisa putus (wait_timeout) saat
// daemon berjalan 24/7 — reconnect otomatis tiap iterasi bila perlu.
// ============================================================
if ($DAEMON_MODE) {
    global $conn;
    $connOk = false;
    if (isset($conn) && $conn) {
        if (function_exists('mysqli_ping')) {
            // ekstensi mysqli asli: ping ringan tanpa query
            $connOk = @mysqli_ping($conn);
        } else {
            // fallback: query trivial (return false bila koneksi mati)
            $connOk = @mysqli_query($conn, "SELECT 1") !== false;
        }
    }
    if (!$connOk) {
        $RECONNECT_SLEEP = 5;
        cronLog("DAEMON: koneksi DB terdeteksi mati — reconnect dalam {$RECONNECT_SLEEP}s...");
        if (!ag_sleep_interruptible($RECONNECT_SLEEP)) { exit(0); }
        // muat ulang koneksi.php (flag AG_KONEKSI_NO_DIE aktif -> tidak die())
        unset($conn);
        $__k = __DIR__ . '/config/koneksi.php';
        include($__k);
        if (isset($conn) && $conn) {
            cronLog('DAEMON: reconnect DB berhasil.');
        } else {
            cronLog('DAEMON: reconnect DB masih gagal — coba lagi iterasi berikutnya.');
            continue;
        }
    }
}
if ($DAEMON_MODE && $DAEMON_ITER % 60 === 1) {
    // Heartbeat log tiap ~menit agar log tidak banjir di mode 1 detik
    cronLog("--- daemon alive (iter #$DAEMON_ITER, loop=${LOOP_SECONDS}s, uptime " . gmdate('H:i:s', time() - $DAEMON_START_TS) . ") ---");
}

cronLog('=== CRON AUTO-CREDIT QRIS START ===');

// Ambil config AutoGopay
$cfgQ = mysqli_query($conn, "SELECT autogopay_apikey, autogopay_apikey2, autogopay_wh_secret, autogopay_wh_secret2, urlweb, urlweb2 FROM tb_seo WHERE cuid = 1 LIMIT 1");
if (!$cfgQ) {
    cronLog('ERROR: gagal query tb_seo — ' . mysqli_error($conn));
    if ($DAEMON_MODE) {
        if (!ag_sleep_interruptible(5)) { exit(0); }
        continue;
    }
    exit(1);
}
$cfg = mysqli_fetch_assoc($cfgQ);
if (!$cfg) {
    cronLog('ERROR: config tb_seo (cuid=1) tidak ditemukan');
    if ($DAEMON_MODE) {
        if (!ag_sleep_interruptible(5)) { exit(0); }
        continue;
    }
    exit(1);
}

$apiKey1 = isset($cfg['autogopay_apikey']) ? $cfg['autogopay_apikey'] : '';
$apiKey2 = isset($cfg['autogopay_apikey2']) ? $cfg['autogopay_apikey2'] : '';

if ($apiKey1 === '' && $apiKey2 === '') {
    cronLog('SKIP: API key AutoGopay belum dikonfigurasi (isi di panel admin -> Setting).');
    if ($DAEMON_MODE) {
        // config mungkin diisi belakangan lewat panel admin -> cek ulang berkala
        $sleepCfg = max(30, $LOOP_SECONDS * 30);
        cronLog("DAEMON: API key kosong — tidur {$sleepCfg}s sebelum cek ulang config...");
        if (!ag_sleep_interruptible($sleepCfg)) { exit(0); }
        continue;
    }
    exit(0);
}

// Buat client site-1 (utama); site-2 dipakai bila API key 2 terisi dan
// transaksi terdeteksi berasal dari site-2 (note ORDER sama saja, keduanya
// dicek berturut untuk status 404).
$ag1 = new AutoGopay($apiKey1, isset($cfg['autogopay_wh_secret']) ? $cfg['autogopay_wh_secret'] : '');
$ag2 = null;
if ($apiKey2 !== '') {
    $ag2 = new AutoGopay($apiKey2, isset($cfg['autogopay_wh_secret2']) ? $cfg['autogopay_wh_secret2'] : '');
}

// ============================================================
// Ambil transaksi pending QRIS AutoGopay (age window)
// ============================================================
$since = date('Y-m-d H:i:s', strtotime("-{$MAX_AGE_HOURS} hours"));
$before = date('Y-m-d H:i:s', strtotime("-{$MIN_AGE_MINUTES} minutes"));

$sql = mysqli_query($conn, "SELECT cuid, userID, status, kd_transaksi, gameid, total, note, date
    FROM tb_transaksi
    WHERE jenis = '1'
      AND (status = 0 OR status IS NULL)
      AND metode = 'QRIS'
      AND note LIKE '%AUTOGOPAY%'
      AND date >= '$since'
      AND date <= '$before'
    ORDER BY cuid ASC
    LIMIT $BATCH_LIMIT");

if (!$sql) {
    cronLog('ERROR: query pending trx gagal — ' . mysqli_error($conn));
    if ($DAEMON_MODE) {
        if (!ag_sleep_interruptible(5)) { exit(0); }
        continue;
    }
    exit(1);
}

$total = mysqli_num_rows($sql);
if ($DAEMON_MODE) {
    // mode 1 detik: jangan banjir log per detik
    if ($total > 0) {
        cronLog("Pending QRIS AutoGopay ditemukan: $total");
    }
} else {
    cronLog("Pending QRIS AutoGopay ditemukan: $total");
}

if ($total == 0) {
    // ============================================================
    // [FIX E] Tidak ada pending -> coba retry deposit game untuk
    // transaksi yang sudah dikredit lokal (status=1) tapi deposit
    // ke API game NexusGGR gagal (note [GAME-API-FAIL).
    // Throttle: hanya tiap ~60 iterasi (± 1 menit) di mode daemon
    // agar tidak membebani DB & game API setiap detik.
    // ============================================================
    if (!$DAEMON_MODE || ($DAEMON_ITER % 60 === 1)) {
        $retryRes = qris_autocredit_retry_game_deposits($conn, null, 0, $BATCH_LIMIT);
        if (!empty($retryRes['retried'])) {
            cronLog("RETRY-GAME-FAIL: retried={$retryRes['retried']} recovered={$retryRes['recovered']} still_failed={$retryRes['still_failed']}");
        } elseif (!empty($retryRes['error'])) {
            cronLog('RETRY-GAME-FAIL error: ' . $retryRes['error']);
        }
    }
    if (!$DAEMON_MODE) {
        cronLog('=== CRON AUTO-CREDIT QRIS END (tidak ada pending) ===');
        exit(0);
    }
    // daemon: tidak ada pending -> tidur dan loop (interruptible)
    if (!ag_sleep_interruptible($LOOP_SECONDS)) { exit(0); }
    continue;
}

$creditedCount = 0;
$failedCount   = 0;
$expiredCount  = 0;
$pendingCount  = 0;
$errorCount    = 0;

// Daemon 1 detik: log per-transaksi hanya tiap ~1 menit supaya log tidak banjir
$verboseLog = !$DAEMON_MODE || ($DAEMON_ITER % 60 === 1);

while ($trx = mysqli_fetch_assoc($sql)) {
    $cuid = (int)$trx['cuid'];
    $kd   = (string)$trx['kd_transaksi'];
    $note = (string)$trx['note'];

    // Reference penuh dari note (ORDER: XXX) — anti-truncation
    $fullRef = $kd;
    if (preg_match('/ORDER:\s*([A-Za-z0-9\-]+)/', $note, $m)) {
        $fullRef = $m[1];
    }

    // Invoice dari note (INVOICE: INV-xxxx)
    $invoice = '';
    if (preg_match('/INVOICE:\s*([A-Za-z0-9\-]+)/', $note, $m2)) {
        $invoice = $m2[1];
    }

    if ($verboseLog) {
        cronLog("Check cuid=$cuid kd=$kd fullRef=$fullRef invoice=$invoice user=" . (int)$trx['userID']);
    }

    // ============================================================
    // Tanya status ke AutoGopay (coba site 1, lalu site 2 jika 404)
    // ============================================================
    $apiStatus = '';
    try {
        $resp = $ag1->getStatus($fullRef);
        $apiStatus = ag_parse_status($resp);
        if ($apiStatus === '' && $ag2 !== null) {
            $resp = $ag2->getStatus($fullRef);
            $apiStatus = ag_parse_status($resp);
        }
    } catch (Exception $e) {
        cronLog("  API exception: " . $e->getMessage());
        $errorCount++;
        continue;
    }

    if ($apiStatus === 'success') {
        // ============================================================
        // AUTO-CREDIT (idempotent via helper)
        // ============================================================
        $WL = new fiver();
        $res = qris_autocredit_process($conn, $trx, [
            'game_api' => true,
            'telegram' => true,
            'log_fn'   => 'cronLog',
            'source'   => 'cron',
            'wl'       => $WL,
        ]);

        if ($res['credited']) {
            $creditedCount++;
            cronLog("  -> CREDITED user #" . (int)$trx['userID'] . " +" . (int)$trx['total'] . " (game_api=" . ($res['game_ok'] ? 'ok' : 'fail(' . $res['game_msg'] . ')') . ")");
        } elseif ($res['already']) {
            cronLog("  -> sudah diproses lapis lain (skip)");
        } else {
            $failedCount++;
            cronLog("  -> GAGAL kredit: " . $res['error']);
        }
    } elseif ($apiStatus === 'failed' || $apiStatus === 'expired') {
        // Tandai gagal lokal (idempotent)
        $kdEsc = mysqli_real_escape_string($conn, $kd);
        mysqli_query($conn, "UPDATE tb_transaksi SET status = 2
            WHERE cuid = '$cuid' AND jenis = '1' AND (status = 0 OR status IS NULL)");
        $expiredCount++;
        cronLog("  -> EXPIRED/FAILED di AutoGopay -> status lokal = 2");
    } else {
        $pendingCount++;
        if ($verboseLog) {
            cronLog("  -> masih pending di AutoGopay (status='$apiStatus')");
        }
    }
}

$summaryLine = "Ringkasan: credited=$creditedCount alreadyFailedCredit=$failedCount expired=$expiredCount pending=$pendingCount apiError=$errorCount";
if (!$DAEMON_MODE || ($creditedCount + $failedCount + $expiredCount + $errorCount) > 0) {
    cronLog($summaryLine);
}

// ============================================================
// [FIX E] Setelah memproses pending, retry deposit game untuk
// transaksi status=1 dengan note [GAME-API-FAIL (saldo lokal sudah
// masuk tapi deposit ke API game gagal). Helper sudah dedup via
// transferStatus sehingga aman (idempotent).
// ============================================================
$retryRes2 = qris_autocredit_retry_game_deposits($conn, null, 0, $BATCH_LIMIT);
if (!empty($retryRes2['retried'])) {
    cronLog("RETRY-GAME-FAIL(after pending): retried={$retryRes2['retried']} recovered={$retryRes2['recovered']} still_failed={$retryRes2['still_failed']}");
} elseif (!empty($retryRes2['error'])) {
    cronLog('RETRY-GAME-FAIL error: ' . $retryRes2['error']);
}

if (!$DAEMON_MODE) {
    cronLog('=== CRON AUTO-CREDIT QRIS END ===');
    exit(0);
}
// daemon: ringkasan sudah dicetak di atas hanya bila ada transaksi yang
// diproses (karena total==0 -> continue lebih awal tanpa summary).

// ============================================================
// DAEMON: tunggu LOOP_SECONDS sebelum iterasi berikutnya.
// Cek sinyal stop (SIGTERM/SIGINT) dengan sleep tersegmentasi 1 detik
// supaya bisa berhenti cepat & rapi.
// ============================================================
if (!ag_sleep_interruptible($LOOP_SECONDS)) {
    cronLog("DAEMON: sinyal stop diterima setelah iter #$DAEMON_ITER — keluar rapi.");
    exit(0);
}
} while ($DAEMON_MODE);

// Mode sekali-jalan (non-daemon) sampai ke sini? Tidak seharusnya —
// semua jalur non-daemon sudah exit di atas. Pengaman ekstra:
exit(0);
