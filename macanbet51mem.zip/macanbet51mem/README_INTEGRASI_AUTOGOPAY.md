# Integrasi Payment Gateway AutoGopay (autogopay.net)

## Ringkasan

Website ini telah diintegrasikan dengan **AutoGopay** (https://autogopay.net) sebagai payment gateway QRIS. RedPay (red-pay.vip) dan JayaPay telah **dihapus sepenuhnya** dan diganti dengan AutoGopay.

AutoGopay menghubungkan sistem ke akun **GoPay Merchant** pribadi dengan **0% fee** per transaksi. Dana langsung masuk ke saldo GoPay Merchant.

---

## Struktur Folder (Sudah Digabung)

Folder ini adalah gabungan **tampilan member** (cgi-bin) dan **admin panel** (assets) dalam satu tree:

```
/ (root - tampilan member)
├── config/
│   ├── class.autogopay.php       ← API client AutoGopay (BARU)
│   ├── class_softgaming.php      ← API game NexusGGR (fiver->deposit)
│   ├── koneksi.php               ← Koneksi DB member (ugrzavpi_firmansyah)
│   ├── class.yere.php            ← Legacy YerePay (tidak terhubung, orphan)
│   └── ...
├── function/
│   ├── generate_qris_autogopay.php  ← Generate QRIS via AutoGopay (BARU)
│   ├── check_qris_status.php        ← Polling status (AutoGopay)
│   └── ...
├── m/account/
│   ├── qris_deposit.php          ← Form deposit member → AutoGopay
│   ├── qris_payment.php          ← Halaman QR Code + polling
│   └── ...
├── callback_autogopay.php        ← Webhook handler AutoGopay (BARU)
│
├── assets/ (admin panel)
│   ├── tools/
│   │   └── setting.php           ← Simpan config AutoGopay (API Key, Webhook Secret)
│   ├── general.php               ← Tab "Payment Gateway" → konfigurasi AutoGopay
│   ├── config/
│   │   └── koneksi.php           ← Koneksi DB admin (cihommcc_onix)
│   └── ...
│
└── database_ugrzavpi_firmansyah.sql  ← Database lengkap (1 file, sudah termasuk kolom autogopay)
```

### Yang Dihapus (RedPay & JayaPay)
- `config/class.redpayvip.php` — dihapus
- `config/class.jayapay.php` — dihapus
- `callback_qris_otomatis.php` — dihapus (diganti callback_autogopay.php)
- `callback_jayapay.php` — dihapus
- `function/generate_qris_otomatis.php` — dihapus (diganti generate_qris_autogopay.php)
- Kolom `qris_uuid`, `qris_uuid2`, `redpay_wh_secret`, `redpay_wh_secret2`, `jayapay_*` dihapus dari tb_seo

---

## Alur Pembayaran QRIS AutoGopay (End-to-End)

```
1. Member buka halaman deposit
   → m/account/qris_deposit.php (form: username, bonus, nominal)

2. Member klik "GENERATE QRIS"
   → POST function/generate_qris_autogopay.php
   → AutoGopay API: POST /api/v1/payment/create
   → Simpan transaksi ke tb_transaksi (status=0/pending)
   → Simpan data QRIS ke session
   → Redirect ke m/account/qris_payment.php

3. Halaman QR Code
   → m/account/qris_payment.php menampilkan QR Code
   → JS polling setiap 5 detik ke function/check_qris_status.php
   → check_qris_status.php cek tb_transaksi.status + polling AutoGopay API

4. Member scan QRIS & bayar via e-wallet/mobile banking

5. AutoGopay mendeteksi pembayaran sukses
   → Kirim webhook ke callback_autogopay.php
   → Verifikasi signature HMAC-SHA256
   → Cari transaksi by reference/invoice
   → Idempotency check (status != 1)
   → fiver->deposit() kredit ke API game (NexusGGR)
   → UPDATE tb_transaksi SET status = 1
   → UPDATE tb_balance SET active = active + amount (SALDO/COIN MEMBER)
   → Proses bonus turnover jika ada
   → Kirim notifikasi Telegram (opsional)
   → Balas HTTP 200

6. Member lihat saldo masuk otomatis
```

---

## Konfigurasi yang Perlu Diisi

### 1. API Key & Webhook Secret AutoGopay
Login ke dashboard AutoGopay (https://autogopay.net/dashboard), ambil:
- **API Key** (format: `iak_xxxxxx`)
- **Webhook Secret Key**

Isi di admin panel → **Setting** → tab **Payment Gateway**:
- API Key — Website 1 (`autogopay_apikey`)
- Webhook Secret — Website 1 (`autogopay_wh_secret`)
- API Key — Website 2 (`autogopay_apikey2`) — opsional
- Webhook Secret — Website 2 (`autogopay_wh_secret2`) — opsional

### 2. URL Webhook Callback
Set di dashboard AutoGopay, URL callback:
```
https://DOMAIN-ANDA/callback_autogopay.php
```

### 3. Notifikasi Telegram (Opsional)
Edit `callback_autogopay.php`, isi:
```php
$TG_BOT_TOKEN = "BOT_TOKEN_ANDA";
$TG_CHAT_ID   = "CHAT_ID_ANDA";
```

### 4. Koneksi Database
- **Member**: `config/koneksi.php` — sesuaikan host, user, password, database
- **Admin**: `assets/config/koneksi.php` — sesuaikan host, user, password, database

> **PENTING**: Agar config AutoGopay yang diisi di admin panel ber efek di sisi member, pastikan admin panel dan member site menggunakan **database yang sama** (atau tabel `tb_seo` yang sama). Jika berbeda database, isi API Key AutoGopay langsung di database member via SQL:
> ```sql
> UPDATE tb_seo SET autogopay_apikey='iak_xxxxxx', autogopay_wh_secret='secret_anda', pga_provider='autogopay' WHERE cuid=1;
> ```

---

## Database

File `database_ugrzavpi_firmansyah.sql` adalah database lengkap (1 file) yang sudah termasuk:

### Tabel `tb_seo` (kolom AutoGopay):
| Kolom | Tipe | Keterangan |
|-------|------|------------|
| `pga_provider` | varchar(20) | Default `'autogopay'` |
| `autogopay_apikey` | varchar(255) | API Key Website 1 |
| `autogopay_apikey2` | varchar(255) | API Key Website 2 (opsional) |
| `autogopay_wh_secret` | varchar(255) | Webhook Secret Website 1 |
| `autogopay_wh_secret2` | varchar(255) | Webhook Secret Website 2 (opsional) |

### Cara Import
```bash
mysql -u USERNAME -p ugrzavpi_firmansyah < database_ugrzavpi_firmansyah.sql
```

Jika database sudah ada dan hanya perlu menambah kolom AutoGopay:
```sql
ALTER TABLE tb_seo ADD COLUMN pga_provider VARCHAR(20) NOT NULL DEFAULT 'autogopay';
ALTER TABLE tb_seo ADD COLUMN autogopay_apikey VARCHAR(255) NULL DEFAULT NULL;
ALTER TABLE tb_seo ADD COLUMN autogopay_apikey2 VARCHAR(255) NULL DEFAULT NULL;
ALTER TABLE tb_seo ADD COLUMN autogopay_wh_secret VARCHAR(255) NULL DEFAULT NULL;
ALTER TABLE tb_seo ADD COLUMN autogopay_wh_secret2 VARCHAR(255) NULL DEFAULT NULL;
```

---

## API AutoGopay

### Create Payment
```
POST https://autogopay.net/api/v1/payment/create
Header: X-API-Key: iak_xxxxxx
Body: { "amount": 50000, "reference": "DEPO123", "callback_url": "https://..." }
Response: { "success": true, "data": { "invoice", "reference", "qris_string", "qr_image", "payment_url", "status", "expired_at" } }
```

### Check Status
```
GET https://autogopay.net/api/v1/payment/status/{reference}
Header: X-API-Key: iak_xxxxxx
Response: { "success": true, "data": { "status": "success|pending|failed|expired" } }
```

### Webhook (callback_autogopay.php)
AutoGopay mengirim POST dengan payload:
```json
{
  "event": "payment.updated",
  "invoice": "INV-xxxx",
  "reference": "DEPO123",
  "amount": 50000,
  "status": "success",
  "payment_method": "qris",
  "paid_at": "2026-06-20 15:32:01",
  "timestamp": "2026-06-20T15:32:01+07:00",
  "signature": "HMAC-SHA256"
}
```

**Signature verification**: `HMAC-SHA256(json_encode(payload tanpa 'signature'), webhookSecret)`

---

## Catatan

1. **YerePay Legacy**: File `m/account/payment.php` dan `config/class.yere.php` adalah legacy YerePay (provider berbeda, api.idryerepay.com). File ini **tidak terhubung** ke alur deposit aktif (orphaned) dan tidak menggunakan RedPay/red-pay.vip. Dibiarkan apa adanya karena tidak cocok dengan integrasi AutoGopay dan tidak mengganggu alur utama.

2. **Multi-site**: Sistem mendukung 2 website (Website 1 & Website 2) dengan API Key dan Webhook Secret terpisah. Deteksi site otomatis berdasarkan HTTP_HOST.

3. **Idempotency**: Webhook handler cek `tb_transaksi.status == 1` sebelum memproses, mencegah double-credit jika AutoGopay mengirim webhook berkali-kali.

4. **Auto-credit**: Saldo/coin member di-credit otomatis di `tb_balance.active += amount` setelah pembayaran QRIS sukses diverifikasi via webhook.
