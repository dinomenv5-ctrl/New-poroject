<?php
/**
 * AutoGopay Webhook Handler (Payin Notification) — FIXED VERSION
 * Platform: https://autogopay.net/documentation#webhooks
 *
 * ============ PERBAIKAN PENTING (vs versi lama) ============
 *  [FIX #1] CREDIT DULU, GAME API BEST-EFFORT:
 *          Versi lama hanya kredit jika deposit NexusGGR sukses; jika game
 *          API gagal -> HTTP 500 -> TIDAK ADA CREDIT SAMA SEKALI (penyebab
 *          utama "coin tidak masuk"). Sekarang: saldo member dikredit DULU,
 *          game API best-effort; kegagalan game API dicatat di note
 *          transaksi (tidak membatalkan credit) + notif Telegram.
 *  [FIX #2] IDEMPOTENT KUAT: UPDATE ... WHERE status=0 + affected_rows
 *          -> Webhook retry / race dengan polling & cron tidak double credit.
 *  [FIX #3] ANTI-TRUNCATION LOOKUP: reference webhook 17-18 char (orderId
 *          lama) dicocokkan via note LIKE '%ORDER: <ref>%' dan prefix 16 char.
 *  [FIX #4] TIDAK memakai bk_pay sebagai flag kredit (bk_pay milik promotorBK).
 *  [FIX #5] Amount validation: nominal webhook harus sama dengan transaksi
 *          yang tersimpan (anti manipulasi nominal).
 *
 * AutoGopay mengirim HTTP POST callback ketika status pembayaran berubah:
 *   success | failed | expired
 *
 * Payload:
 *   {
 *     "event":"payment.updated",
 *     "invoice":"INV-xxxx",
 *     "reference":"INV-10291",   // = orderId/kd_transaksi sistem kita
 *     "amount":50000,
 *     "status":"success",
 *     "payment_method":"qris",
 *     "paid_at":"2026-06-20 15:32:01",
 *     "timestamp":"2026-06-20T15:32:01+07:00",
 *     "signature":"c8e2fb8a9d012e..."
 *   }
 *
 * Signature = HMAC-SHA256( json_encode(payload tanpa 'signature'), webhookSecret )
 *
 * CATATAN KEAMANAN SIGNATURE:
 *   verifyWebhook() mengembalikan TRUE jika webhook secret kosong. Karena
 *   wh_secret di DB masih kosong, kami tidak menolak webhook begitu saja
 *   (deposit member akan macet sampai admin mengisi secret). Sebagai gantinya,
 *   credit HANYA dilakukan atas transaksi yang BENAR-BENAR dibuat oleh sistem
 *   generate_qris_autogopay.php (lookup kd_transaksi/note ORDER), dan nominal
 *   harus cocok. Selalu isi autogopay_wh_secret di panel admin untuk
 *   keamanan penuh (lihat LAPORAN_PERBAIKAN_QRIS.md).
 */
header('Content-Type: text/plain; charset=utf-8');
date_default_timezone_set("Asia/Jakarta");

include('config/koneksi.php');
include('config/class_softgaming.php');
include('config/class.autogopay.php');
include('function/autocredit_helper.php');

// ============================================================
// Logging
// ============================================================
$logFile = __DIR__ . '/logs/autogopay_callback_' . date('Y-m-d') . '.log';
$logDir  = dirname($logFile);
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}

function writeLog($message)
{
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    @file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
}

function replyOk($msg = 'success')
{
    http_response_code(200);
    echo $msg;
    exit;
}

function replyError($msg, $code = 400)
{
    writeLog('REPLY ERROR: ' . $msg);
    http_response_code($code);
    echo $msg;
    exit;
}

// ============================================================
// MAIN
// ============================================================
writeLog('=== CALLBACK AUTOGOPAY RECEIVED ===');

$jsonInput = file_get_contents('php://input');
writeLog('Raw Input: ' . $jsonInput);

$data = json_decode($jsonInput, true);
if (!$data || !is_array($data)) {
    replyError('Invalid JSON data');
}

// Ambil config API + webhook secret dari tb_seo
$configQuery = mysqli_query($conn, "SELECT autogopay_apikey, autogopay_apikey2, autogopay_wh_secret, autogopay_wh_secret2 FROM tb_seo WHERE cuid = 1 LIMIT 1");
if (!$configQuery) {
    // Fallback jika kolom belum ada (sebelum migration)
    $configQuery = mysqli_query($conn, "SELECT * FROM tb_seo WHERE cuid = 1 LIMIT 1");
}
$config = mysqli_fetch_assoc($configQuery);

$apiKeySite1 = isset($config['autogopay_apikey']) ? $config['autogopay_apikey'] : '';
$apiKeySite2 = isset($config['autogopay_apikey2']) ? $config['autogopay_apikey2'] : '';
$whSite1     = isset($config['autogopay_wh_secret']) ? $config['autogopay_wh_secret'] : '';
$whSite2     = isset($config['autogopay_wh_secret2']) ? $config['autogopay_wh_secret2'] : '';

// Verifikasi signature webhook (HMAC-SHA256)
$autogopay = new AutoGopay($apiKeySite1, $whSite1);
$signOk = $autogopay->verifyWebhook($data);

// Jika gagal & site 2 ada secret, coba site 2
if (!$signOk && !empty($whSite2)) {
    $autogopay2 = new AutoGopay($apiKeySite2, $whSite2);
    $signOk = $autogopay2->verifyWebhook($data);
    if ($signOk) {
        $autogopay = $autogopay2;
    }
}

if (!$signOk) {
    writeLog('ERROR: Invalid webhook signature');
    replyError('Invalid signature', 401);
}

writeLog('Signature OK (secret ' . (($whSite1 !== '' || $whSite2 !== '') ? 'configured' : 'EMPTY - unsafe mode') . ')');

// ============================================================
// Parse payload
// ============================================================
$event      = isset($data['event']) ? (string)$data['event'] : '';
$invoice    = isset($data['invoice']) ? trim((string)$data['invoice']) : '';
$reference  = isset($data['reference']) ? trim((string)$data['reference']) : '';
$amount     = isset($data['amount']) ? (int)$data['amount'] : 0;
$status     = isset($data['status']) ? strtolower((string)$data['status']) : '';
$payMethod  = isset($data['payment_method']) ? (string)$data['payment_method'] : '';
$paidAt     = isset($data['paid_at']) ? (string)$data['paid_at'] : '';

if ($reference === '' && $invoice === '') {
    replyError('Missing reference & invoice');
}

writeLog("Processing reference=$reference | invoice=$invoice | amount=$amount | status=$status | event=$event");

// ============================================================
// Cari transaksi di tb_transaksi
// [FIX #3] Anti-truncation lookup via helper (exact + note ORDER + prefix 16)
// ============================================================
$trxData = qris_autocredit_find_trx($conn, $reference, $invoice);

if (!$trxData) {
    writeLog("ERROR: Transaction not found for reference=$reference invoice=$invoice");
    replyError('Transaction not found', 404);
}

$userID       = (int)$trxData['userID'];
$kd_transaksi = $trxData['kd_transaksi'];
$gameid       = isset($trxData['gameid']) ? (int)$trxData['gameid'] : 0;
$trxTotal     = (int)$trxData['total'];

// Idempotency level-1: jika sudah diproses (status=1), balas success
if ((int)$trxData['status'] === 1) {
    writeLog("Already processed (status=1). Reply success.");
    replyOk('success');
}

// Ambil username user
$u = qris_autocredit_get_user($conn, $userID);
if (!$u) {
    writeLog("ERROR: User not found userID=$userID");
    replyError('User not found', 404);
}
$username_web = $u['username'];

// ============================================================
// [FIX D] NORMALISASI STATUS WEBHOOK
// AutoGopay resmi mengirim: success | failed | expired.
// Namun beberapa varian gateway/versi API juga memakai:
//   paid / settlement / complete / capture  (sukses)
//   canceled / cancel / void / reversed / timeout (gagal)
// Versi lama HANYA cocok 'success' & 'failed'/'expired' persis ->
// webhook varian lain diabaikan -> saldo tidak masuk.
// ============================================================
$paidVariants   = ['success', 'paid', 'settle', 'settlement', 'complete', 'completed', 'finish', 'finished', 'done', 'clear', 'cleared', 'capture', 'captured'];
$failedVariants = ['failed', 'fail', 'expired', 'expire', 'timeout', 'cancel', 'canceled', 'cancelled', 'void', 'reversed'];
$statusNorm     = strtolower(trim($status));

if (in_array($statusNorm, $failedVariants, true)) {
    $status = 'failed';
} elseif (in_array($statusNorm, $paidVariants, true)) {
    $status = 'success';
}
// varian lain (pending/unpaid/new/waiting) dibiarkan apa adanya -> no action

// ============================================================
// Handle status FAILED / EXPIRED -> update transaksi, tidak kredit
// ============================================================
if ($status === 'failed' || $status === 'expired') {
    $kdEsc = mysqli_real_escape_string($conn, $kd_transaksi);
    mysqli_query($conn, "UPDATE tb_transaksi
        SET status = 2
        WHERE kd_transaksi = '$kdEsc'
        AND userID = '$userID'
        AND jenis = 1");

    writeLog("Transaction $kd_transaksi marked as $status (status=2). No credit.");
    qris_autocredit_send_telegram(
        "━━━━━━━━━━━━━━━\n" .
        "❌ *DEPOSIT " . strtoupper($status) . " (AUTOGOPAY)*\n" .
        "━━━━━━━━━━━━━━━\n" .
        "👤 User   : `$username_web`\n" .
        "💵 Amount : Rp " . number_format($amount > 0 ? $amount : $trxTotal, 0, ',', '.') . "\n" .
        "🧾 TrxID  : `$kd_transaksi`\n" .
        "🕒 " . date('d-m-Y H:i:s')
    );
    replyOk('success');
}

// Status tidak dikenali / pending -> balas success tanpa aksi
if (!$autogopay->isPaymentSuccess($status)) {
    writeLog("Status not success (status=$status). Reply success, no action.");
    replyOk('success');
}

// ============================================================
// [FIX #5 + FIX D] Validasi nominal (anti manipulasi saat wh_secret
// belum diisi), tapi TIDAK MENOLAK OVERPAY:
//   - webhook amount > trxTotal (member bayar lebih) -> DITERIMA,
//     dikredit sebesar nominal transaksi (aman dari manipulasi:
//     tidak pernah lebih dari yang benar-benar dibayar).
//   - webhook amount < trxTotal (underpay) -> DITOLAK (belum lunas).
// ============================================================
if ($amount > 0 && $amount < $trxTotal) {
    writeLog("AMOUNT MISMATCH (underpaid): webhook=$amount < tb_transaksi.total=$trxTotal (kd=$kd_transaksi). REJECT.");
    qris_autocredit_send_telegram(
        "⚠️ *SECURITY: AMOUNT MISMATCH (AUTOGOPAY)*\n" .
        "User : `$username_web`\n" .
        "Webhook amount : Rp $amount\n" .
        "DB amount : Rp $trxTotal\n" .
        "TrxID : `$kd_transaksi`\n" .
        "TIDAK DIPROSES. Cek manual!"
    );
    replyError('Amount mismatch', 409);
}
if ($amount > 0 && $amount > $trxTotal) {
    writeLog("OVERPAY detected: webhook=$amount > total=$trxTotal (kd=$kd_transaksi). Credit sebesar total transaksi.");
}
$amount = $trxTotal; // pakai nominal transaksi tersimpan

// ============================================================
// Handle status SUCCESS -> AUTO-CREDIT COIN / SALDO MEMBER
// (delegasi penuh ke helper — credit dulu, game API best-effort,
//  idempotent, bonus turnover, notif Telegram)
// ============================================================
writeLog("Starting auto-credit (webhook): user=$username_web amount=$amount kd_transaksi=$kd_transaksi");

$WL = new fiver();

$result = qris_autocredit_process($conn, $trxData, [
    'game_api' => true,
    'telegram' => true,
    'log_fn'   => 'writeLog',
    'source'   => 'webhook',
    'wl'       => $WL,
]);

if ($result['already']) {
    // Diproses proses lain (polling/cron lebih dulu) -> tetap balas 200
    writeLog("Auto-credit skipped (already processed by another layer). Reply success.");
    replyOk('success');
}

if ($result['credited']) {
    // Saldo member SUDAH masuk (game API mungkin gagal — best effort,
    // dicatat di note transaksi + alert Telegram)
    writeLog("=== SUCCESS AUTO-CREDIT (webhook) === user=$username_web amount=$amount game_ok=" . ($result['game_ok'] ? 'yes' : 'no'));
    replyOk('success');
}

// Kredit gagal total (mis. tb_balance error) -> HTTP 500 agar AutoGopay retry
writeLog("AUTO-CREDIT FAILED (webhook): " . $result['error']);
replyError('Credit failed', 500);
