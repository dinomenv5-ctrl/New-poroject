<?php
echo "<h2>Test Config Security & Connectivity</h2>";

echo "<h3>1. Test Include Config Files (Should Work)</h3>";
try {
    include('config/koneksi.php');
    echo "✅ config/koneksi.php: <strong>SUCCESS</strong> - File bisa di-include<br>";
    
    if (isset($conn) && $conn) {
        echo "✅ Database Connection: <strong>CONNECTED</strong><br>";
    } else {
        echo "❌ Database Connection: <strong>FAILED</strong><br>";
    }
} catch (Exception $e) {
    echo "❌ config/koneksi.php: <strong>ERROR</strong> - " . $e->getMessage() . "<br>";
}

try {
    include('config/class_softgaming.php');
    echo "✅ config/class_softgaming.php: <strong>SUCCESS</strong> - File bisa di-include<br>";
    
    if (class_exists('fiver')) {
        echo "✅ Class 'fiver': <strong>FOUND</strong><br>";
        $WL = new fiver();
        echo "✅ NexusGGR API Object: <strong>CREATED</strong><br>";
        echo "   - Agent: " . $WL->agen . "<br>";
        echo "   - URL: " . $WL->url . "<br>";
    } else {
        echo "❌ Class 'fiver': <strong>NOT FOUND</strong><br>";
    }
} catch (Exception $e) {
    echo "❌ config/class_softgaming.php: <strong>ERROR</strong> - " . $e->getMessage() . "<br>";
}

echo "<hr>";
echo "<h3>2. Test Direct URL Access (Should Fail - 403)</h3>";
echo "⚠️ <strong>Manual Test Required:</strong><br>";
echo "Coba akses langsung via browser:<br>";
echo "- <a href='config/class_softgaming.php' target='_blank'>config/class_softgaming.php</a> (Should return 403)<br>";
echo "- <a href='config/koneksi.php' target='_blank'>config/koneksi.php</a> (Should return 403)<br>";
echo "- <a href='config/' target='_blank'>config/</a> (Should return 403 or blank)<br>";

echo "<hr>";
echo "<h3>3. Test Office Panel Path (Multi-Domain)</h3>";
$office_config_path = dirname(__DIR__) . '/config/';
echo "Office Panel Path: <code>" . $office_config_path . "</code><br>";

if (file_exists($office_config_path . 'class_softgaming.php')) {
    echo "✅ Office can access: <strong>YES</strong><br>";
} else {
    echo "❌ Office can access: <strong>NO</strong> - Path mungkin salah<br>";
}

echo "<hr>";
echo "<h3>4. Security Status</h3>";
if (file_exists('config/.htaccess')) {
    echo "✅ .htaccess file: <strong>EXISTS</strong><br>";
    $htaccess_content = file_get_contents('config/.htaccess');
    if (strpos($htaccess_content, 'Deny from all') !== false || strpos($htaccess_content, 'Require all denied') !== false) {
        echo "✅ .htaccess protection: <strong>ACTIVE</strong><br>";
    } else {
        echo "⚠️ .htaccess protection: <strong>CHECK MANUALLY</strong><br>";
    }
} else {
    echo "❌ .htaccess file: <strong>NOT FOUND</strong><br>";
}

echo "<hr>";
echo "<p><strong>✅ Kesimpulan:</strong> Jika semua test di atas SUCCESS, maka config folder sudah aman dan tetap bisa diakses dari aplikasi (include/require).</p>";
?>
