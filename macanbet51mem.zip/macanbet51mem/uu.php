<?php
/**
 * File: sync_provider_manual.php
 * Sinkronisasi tb_provider dengan Nama Manual di dalam Kode
 */

require_once 'config/koneksi.php';

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$message = "";

// Daftar Mapping Nama Provider Manual (Silahkan lengkapi hingga 35 nama)
$provider_names = [
    'AG' => 'PLAYACE',
    'AK' => 'ALLBET',
    'BI' => 'BIG GAMING',
    'BK' => 'ICONIC',
    'BV' => 'BNG',
    'CM' => 'CMD SPORTS',
    'CQ' => 'CQ9',
    'DG' => 'DREAM GAMING',
    'FS' => 'FASTSPIN',
    'GE' => 'EVOLUTION',
    'HB' => 'HABANERO',
    'IB' => 'IBC',
    'JD' => 'JDB',
    'JE' => 'JILI DIRECT',
    'JK' => 'JOKER',
    'KA' => 'KA GAMING',
    'L1' => 'LIVE22',
    'MP' => 'MICRO GAMING',
    'ND' => 'NEX4D',
    'PG' => 'PGSOFT',
    'PN' => 'PLAY N GO',
    'PR' => 'PRAGMATIC PLAY',
    'PS' => 'PLAYSTAR',
    'Q6' => 'PLAYTECH',
    'S3' => 'SBO',
    'S6' => 'AWC68',
    'SA' => 'SAGAMING',
    'SB' => 'SBTECH',
    'SG' => 'SPADE GAMING',
    'UG' => 'UG SPORTS',
    'W4' => 'AWC',
    'WB' => 'WBET',
    'WW' => 'WOW GAMING',
    'XP' => 'XPG',
    'YE' => 'YFG EVOPLAY'
];

if (isset($_POST['start_sync'])) {
    // Ambil kombinasi unik code dan category dari tb_gamelist [cite: 3, 5]
    $sql_source = "SELECT provider_code, game_category FROM tb_gamelist GROUP BY provider_code, game_category";
    $result_source = mysqli_query($conn, $sql_source);
    
    if ($result_source) {
        $count = 0;
        while ($row = mysqli_fetch_assoc($result_source)) {
            $p_code = mysqli_real_escape_string($conn, $row['provider_code']);
            $g_cat  = mysqli_real_escape_string($conn, $row['game_category']);
            
            // Ambil nama dari array manual, jika tidak ada pakai code aslinya
            $p_name = isset($provider_names[$p_code]) ? $provider_names[$p_code] : $p_code;
            $p_name = mysqli_real_escape_string($conn, $p_name);

            // Insert atau Update menggunakan ON DUPLICATE KEY 
            // code_category adalah unique key untuk (code, game_category) 
            $sql_sync = "INSERT INTO tb_provider (code, name, game_category, status, created_at, updated_at) 
                         VALUES ('$p_code', '$p_name', '$g_cat', 1, NOW(), NOW())
                         ON DUPLICATE KEY UPDATE 
                         name = VALUES(name), 
                         updated_at = NOW()";
            
            if (mysqli_query($conn, $sql_sync)) {
                $count++;
            }
        }
        $message = "<div class='alert alert-success'>Sinkronisasi Berhasil! $count data diproses ke tb_provider.</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
    }
}

// Ambil data untuk ditampilkan di tabel [cite: 10]
$report_query = mysqli_query($conn, "SELECT * FROM tb_provider ORDER BY name ASC, game_category ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manual Sync Provider</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="card shadow mb-4">
        <div class="card-body text-center">
            <h3>Update Provider Manual</h3>
            <p class="text-muted">Data akan disinkronkan dari <code>tb_gamelist</code> menggunakan mapping nama di dalam script.</p>
            <form method="POST">
                <button type="submit" name="start_sync" class="btn btn-dark px-5">Jalankan Update Manual</button>
            </form>
            <div class="mt-3"><?php echo $message; ?></div>
        </div>
    </div>

    <div class="card shadow">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Code</th>
                        <th>Manual Name</th>
                        <th>Category</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($report_query)): ?>
                    <tr>
                        <td><code><?php echo $row['code']; ?></code></td>
                        <td class="fw-bold"><?php echo $row['name']; ?></td>
                        <td><span class="badge bg-primary"><?php echo $row['game_category']; ?></span></td>
                        <td><?php echo $row['status'] == 1 ? 'Open' : 'Closed'; ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>