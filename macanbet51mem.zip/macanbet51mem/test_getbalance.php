<?php

/**
 * Test Get Balance Agent - Simple
 */

$postArray = [
    'method' => 'money_info',
    'agent_code' => 'zoro',
    'agent_token' => '50f15fc0bb4142084bfe46b5a2ceffb7'
];
$jsonData = json_encode($postArray);

$headerArray = ['Content-Type: application/json'];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.nexusggr.com');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headerArray);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$res = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

echo "=== TEST GET BALANCE AGENT ===\n\n";
echo "Request:\n";
echo json_encode($postArray, JSON_PRETTY_PRINT) . "\n\n";
echo "HTTP Code: " . $httpCode . "\n";
if ($curlError) {
    echo "CURL Error: " . $curlError . "\n";
}
echo "\nResponse:\n";
echo $res . "\n\n";
echo "Response (JSON Decoded):\n";
$decoded = json_decode($res, true);
if ($decoded) {
    print_r($decoded);
} else {
    echo "Failed to decode JSON\n";
}
