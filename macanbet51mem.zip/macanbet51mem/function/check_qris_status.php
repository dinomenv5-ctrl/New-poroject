<?php
/**
 * Cek Status Pembayaran QRIS (Member polling) - AutoGopay — FIXED VERSION
 *
 * ============ PERBAIKAN PENTING (vs versi lama) ============
 *  [FIX #1] AUTO-CREDIT POLLING: versi lama HANYA return "saldo sedang
 *          diproses" tanpa logic credit — kalau webhook gagal/telat,
 *          saldo member TIDAK PERNAH masuk walau sudah bayar. Sekarang:
 *          jika API AutoGopay bilang SUCCESS dan transaksi lokal masih
 *          pending (status=0), LANGSUNG auto-credit via autocredit_helper
 *          (idempotent — aman walau webhook datang bersamaan).
 *  [FIX #2] SESSION + OWNERSHIP CHECK: hanya user pemilik transaksi yang
 *          boleh cek status transaksinya (versi lama bisa dipakai siapa
 *          saja tanpa login untuk memantau status transaksi orang lain).
 *  [FIX #3] Mark failed/expired lokal saat API AutoGopay bilang gagal,
 *          supaya transaksi pending tidak menumpuk.
 *
 * Dipanggil dari halaman m/account/qris_payment.php via fetch() setiap 1 detik.
 * Auto-credit berlapis: webhook (lapis 1) -> polling ini (lapis 2) -> cron (lapis 3).
 */
session_start();
date_default_timezone_set("Asia/Jakarta");
include('../config/koneksi.php');
include('../config/class_softgaming.php');
include('../config/class.autogopay.php');
include('autocredit_helper.php');

header('Content-Type: application/json');

function jsonResponse($success, $status, $message = '', $data = null)
{
    echo json_encode([
        'success'   => $success,
        'status'    => $status,
        'message'   => $message,
        'data'      => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);
    exit;
}

// ============================================================
// [FIX #2] Harus login
// ============================================================
if (!isset($_SESSION['user']) || $_SESSION['user'] === '') {
    jsonResponse(false, 'error', 'Sesi berakhir, silakan login ulang', null);
}
$sessionUser = (string)$_SESSION['user'];

$trx_id   = isset($_GET['trx_id']) ? trim($_GET['trx_id']) : '';
$order_id = isset($_GET['order_id']) ? trim($_GET['order_id']) : '';

if ($trx_id === '' && $order_id === '') {
    jsonResponse(false, 'error', 'Transaction ID tidak ditemukan', null);
}

// ============================================================
// 1. Cari transaksi di tb_transaksi (anti-truncation lookup via helper)
// ============================================================
$trxData = qris_autocredit_find_trx($conn, $order_id !== '' ? $order_id : $trx_id, $trx_id);

if (!$trxData) {
    jsonResponse(false, 'error', 'Transaksi tidak ditemukan', null);
}

// [FIX #2] Ownership: transaksi harus milik user yang sedang login
$userRow = qris_autocredit_get_user($conn, (int)$trxData['userID']);
if (!$userRow || strcasecmp($userRow['username'], $sessionUser) !== 0) {
    jsonResponse(false, 'error', 'Transaksi tidak ditemukan', null);
}

$kd_transaksi = $trxData['kd_transaksi'];

// ============================================================
// 2. Jika status transaksi sudah final -> balas langsung
// ============================================================
if ((int)$trxData['status'] === 1) {
    jsonResponse(true, 'success', 'Pembayaran berhasil, saldo telah ditambahkan', [
        'kd_transaksi' => $kd_transaksi,
        'status'       => 'success'
    ]);
}

if ((int)$trxData['status'] === 2) {
    jsonResponse(true, 'failed', 'Pembayaran dibatalkan/gagal', [
        'kd_transaksi' => $kd_transaksi,
        'status'       => 'failed'
    ]);
}

// ============================================================
// 3. Status masih pending -> polling AutoGopay API
// ============================================================
$cfgQ = mysqli_query($conn, "SELECT autogopay_apikey, autogopay_apikey2, urlweb, urlweb2 FROM tb_seo WHERE cuid = 1 LIMIT 1");
$cfg  = $cfgQ ? mysqli_fetch_assoc($cfgQ) : null;

if ($cfg) {
    // Deteksi site aktif
    $currentHost = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $host2 = !empty($cfg['urlweb2']) ? parse_url(rtrim($cfg['urlweb2'], '/'), PHP_URL_HOST) : '';
    $isSite2 = (!empty($host2) && $currentHost === $host2);

    $apiKey = $isSite2 ? (isset($cfg['autogopay_apikey2']) ? $cfg['autogopay_apikey2'] : '') : (isset($cfg['autogopay_apikey']) ? $cfg['autogopay_apikey'] : '');

    if (!empty($apiKey)) {
        try {
            $autogopay = new AutoGopay($apiKey);
            // Poll by kd_transaksi (reference). Jika API 404 untuk orderId lama
            // yang ter-truncate, coba reference penuh dari note (ORDER: ...)
            $statusResp = $autogopay->getStatus($kd_transaksi);

            $apiStatus = '';
            if (isset($statusResp['success']) && $statusResp['success'] === true) {
                $apiStatus = isset($statusResp['data']['status']) ? strtolower((string)$statusResp['data']['status']) : '';
            } elseif (isset($statusResp['data']['status']) && !empty($statusResp['data']['status'])) {
                // beberapa gateway membalas status langsung di data walau success flag beda
                $apiStatus = strtolower((string)$statusResp['data']['status']);
            }

            if ($apiStatus === '') {
                // fallback: coba lookup reference penuh dari note transaksi
                if (preg_match('/ORDER:\s*([A-Za-z0-9\-]+)/', (string)$trxData['note'], $m)) {
                    $fullRef = $m[1];
                    if ($fullRef !== '' && $fullRef !== $kd_transaksi) {
                        $statusResp2 = $autogopay->getStatus($fullRef);
                        if (isset($statusResp2['data']['status'])) {
                            $apiStatus = strtolower((string)$statusResp2['data']['status']);
                        }
                    }
                }
            }

            // ============================================================
            // [FIX C] NORMALISASI STATUS - gateway bisa mengembalikan
            // varian status: success / paid / settlement / complete dsb.
            // Versi lama HANYA cocok dengan 'success' persis -> jika
            // gateway membalas 'PAID', saldo tidak pernah dikredit.
            // ============================================================
            $apiStatusNorm = strtolower(trim((string)$apiStatus));
            $paidVariants   = ['success', 'paid', 'settle', 'settlement', 'seteled', 'complete', 'completed', 'finish', 'finished', 'done', 'clear', 'cleared', 'capture', 'captured'];
            $failedVariants = ['failed', 'fail', 'expired', 'expire', 'timeout', 'cancel', 'canceled', 'cancelled', 'canceled_by_user', 'void', 'reversed'];

            if (in_array($apiStatusNorm, $paidVariants, true)) {
                $apiStatusClass = 'success';
            } elseif (in_array($apiStatusNorm, $failedVariants, true)) {
                $apiStatusClass = 'failed';
            } else {
                // unknown / pending / unpaid / new / waiting
                $apiStatusClass = ($apiStatusNorm === '' ? 'unknown' : 'pending');
            }

            if ($apiStatusClass === 'success') {
                // ============================================================
                // [FIX #1] AUTO-CREDIT via polling (lapis 2)
                // API AutoGopay bilang SUCCESS dan lokal masih pending ->
                // kredit sekarang (idempotent; aman race dengan webhook/cron)
                // ============================================================
                $WL = new fiver();
                $creditResult = qris_autocredit_process($conn, $trxData, [
                    'game_api' => true,
                    'telegram' => true,
                    'source'   => 'polling',
                    'wl'       => $WL,
                ]);

                if ($creditResult['credited'] || $creditResult['already']) {
                    jsonResponse(true, 'success', 'Pembayaran berhasil, saldo telah ditambahkan', [
                        'kd_transaksi' => $kd_transaksi,
                        'status'       => 'success'
                    ]);
                }
                // kredit gagal -> tetap balas pending (cron lapis 3 akan retry)
                jsonResponse(true, 'pending', 'Pembayaran terdeteksi, saldo sedang diproses', [
                    'kd_transaksi' => $kd_transaksi,
                    'status'       => 'pending'
                ]);
            }

            if ($apiStatusClass === 'failed') {
                // [FIX #3] Sinkronkan status gagal ke lokal
                $kdEsc = mysqli_real_escape_string($conn, $kd_transaksi);
                mysqli_query($conn, "UPDATE tb_transaksi SET status = 2
                    WHERE kd_transaksi = '$kdEsc' AND jenis = 1 AND (status = 0 OR status IS NULL)");
                jsonResponse(true, 'failed', 'Pembayaran gagal/kadaluarsa', [
                    'kd_transaksi' => $kd_transaksi,
                    'status'       => $apiStatusNorm
                ]);
            }
        } catch (Exception $e) {
            // [FIX C] catat error polling agar tidak silent-fail (debug cepat)
            @file_put_contents(__DIR__ . '/../api_polling.log',
                '[' . date('Y-m-d H:i:s') . '] POLL-ERR ' . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
        } catch (Throwable $e) {
            @file_put_contents(__DIR__ . '/../api_polling.log',
                '[' . date('Y-m-d H:i:s') . '] POLL-FATAL ' . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
        }
    }
}

// ============================================================
// 4. Fallback: status masih pending
// ============================================================
jsonResponse(true, 'pending', 'Menunggu pembayaran', [
    'kd_transaksi' => $kd_transaksi,
    'status'       => 'pending'
]);
