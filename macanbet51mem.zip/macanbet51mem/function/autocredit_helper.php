<?php
/**
 * ============================================================
 *  HELPER AUTO-CREDIT COIN/SALDO MEMBER (REUSABLE)
 * ============================================================
 *  Dipakai oleh 3 lapis auto-credit + admin approve:
 *    1. Webhook   : callback_autogopay.php         (lapis 1)
 *    2. Polling   : function/check_qris_status.php (lapis 2)
 *    3. Cron      : cron_autocredit_qris.php       (lapis 3)
 *    4. Admin     : tools/approve_qris.php         (manual backup)
 *
 *  Prinsip utama (FIX dari versi lama):
 *  - Saldo member DIKREDIT PERTAMA (tb_balance.active += amount),
 *    deposit ke API game NexusGGR hanya best-effort (tidak memblokir kredit).
 *    -> Member tetap dapat coin walau API game sedang down.
 *  - IDEMPOTENT kuat: UPDATE ... WHERE status=0 + mysqli_affected_rows()
 *    -> Double webhook / race polling vs webhook = hanya 1x kredit.
 *  - TIDAK memakai kolom bk_pay sebagai flag kredit (bk_pay milik
 *    promotorBK CRM untuk status payout referral, jangan dikorbankan).
 *  - Anti-truncation lookup: cari transaksi by kd_transaksi exact,
 *    atau by note LIKE '%ORDER: <ref>%' (untuk orderId lama yang
 *    ter-truncate ke 16 char oleh varchar(16)).
 *  - Agent sign game API DETERMINISTIK per transaksi
 *    (DEPO_<kd_transaksi>, tanpa time()) -> transferStatus() bisa
 *    dipakai untuk cek apakah deposit ke game sudah pernah masuk,
 *    sehingga retry aman tanpa double-deposit di sisi game API.
 *
 *  Dependensi: koneksi.php sudah ter-include ($conn tersedia),
 *              class_softgaming.php sudah ter-include (fiver).
 * ============================================================
 */

if (!function_exists('qris_autocredit_find_trx')) {

    /**
     * Cari transaksi deposit QRIS AutoGopay berdasarkan reference/orderId.
     *
     * Lookup 3 lapis anti-truncation:
     *   1. kd_transaksi = reference (exact)
     *   2. note LIKE '%ORDER: <reference>%'
     *   3. kd_transaksi = prefix 16-char dari reference (kasus kolom varchar(16) truncate)
     *
     * @param mysqli $conn
     * @param string $reference orderId/reference dari AutoGopay
     * @param string $invoice   invoice AutoGopay (INV-xxxx), optional
     * @return array|null row tb_transaksi atau null
     */
    function qris_autocredit_find_trx($conn, $reference, $invoice = '')
    {
        $reference = trim((string)$reference);
        $invoice   = trim((string)$invoice);

        if ($reference === '' && $invoice === '') {
            return null;
        }

        $cond = '';
        if ($reference !== '') {
            $refEsc = mysqli_real_escape_string($conn, $reference);
            $cond .= "(kd_transaksi = '$refEsc' OR note LIKE '%ORDER: $refEsc%')";
            // Anti-truncation: reference 17 char ter-truncate jadi 16 char di DB
            if (strlen($reference) > 16) {
                $ref16 = mysqli_real_escape_string($conn, substr($reference, 0, 16));
                $cond .= " OR (kd_transaksi = '$ref16' AND note LIKE '%ORDER: $refEsc%')";
            }
        }
        if ($invoice !== '') {
            $invEsc = mysqli_real_escape_string($conn, $invoice);
            $cond .= ($cond !== '' ? ' OR ' : '') . "note LIKE '%$invEsc%'";
        }

        $sql = mysqli_query($conn, "SELECT cuid, userID, status, kd_transaksi, gameid, total, note
            FROM tb_transaksi
            WHERE ($cond) AND jenis = '1'
            ORDER BY cuid ASC
            LIMIT 1");
        if (!$sql) {
            return null;
        }
        return mysqli_fetch_assoc($sql);
    }

    /**
     * Temukan username + buat game API user jika belum ada.
     * FIX: user NexusGGR dibuat saat register via proses_register.php, tapi
     * untuk user lama / gagal create, deposit() akan gagal terus.
     * Kita coba create() sekali secara best-effort bila deposit gagal
     * karena user tidak ada.
     *
     * @param mysqli $conn
     * @param int    $userID
     * @return array{username:string}|null
     */
    function qris_autocredit_get_user($conn, $userID)
    {
        $userID = (int)$userID;
        if ($userID <= 0) {
            return null;
        }
        $q = mysqli_query($conn, "SELECT cuid, username FROM tb_user WHERE cuid = '$userID' LIMIT 1");
        if (!$q) {
            return null;
        }
        $u = mysqli_fetch_assoc($q);
        if (!$u) {
            return null;
        }
        return ['username' => (string)$u['username']];
    }

    /**
     * Kredit saldo lokal (tb_balance.active) — pastikan baris ada dulu.
     * FIX dari versi lama: dulu UPDATE dulu baru cek baris (urutan salah),
     * sehingga user tanpa baris tb_balance tidak pernah ter-kredit.
     *
     * @param mysqli $conn
     * @param int    $userID
     * @param int    $amount
     * @return bool
     */
    function qris_autocredit_credit_balance($conn, $userID, $amount)
    {
        $userID = (int)$userID;
        $amount = (int)$amount;
        if ($userID <= 0 || $amount <= 0) {
            return false;
        }

        // 1. Pastikan baris tb_balance ADA (insert dulu jika belum)
        $balCheck = mysqli_query($conn, "SELECT cuid FROM tb_balance WHERE userID = '$userID' LIMIT 1");
        if (!$balCheck) {
            return false;
        }
        if (mysqli_num_rows($balCheck) == 0) {
            mysqli_query($conn, "INSERT INTO tb_balance (userID, active, pending, transfer, payout, created_date)
                VALUES ('$userID', '0', '0', '0', '0', NOW())");
        }

        // 2. Baru kredit
        $up = mysqli_query($conn, "UPDATE tb_balance SET active = active + $amount WHERE userID = '$userID'");
        return $up ? true : false;
    }

    /**
     * Deposit ke API game NexusGGR (BEST-EFFORT, tidak memblokir kredit saldo).
     *
     * Agent sign DETERMINISTIK: 'DEPO_<kd_transaksi>' (tanpa time()).
     * -> Kalau request timeout/gagal ambigu, transferStatus() bisa dipanggil
     *    untuk cek apakah deposit sudah masuk sebelum retry, sehingga aman
     *    dari double-deposit di sisi game API.
     *
     * @param fiver  $WL
     * @param string $username
     * @param int    $amount
     * @param string $kd_transaksi
     * @return array {ok:bool, msg:string, retried_create:bool}
     */
    function qris_autocredit_game_deposit($WL, $username, $amount, $kd_transaksi)
    {
        $username    = (string)$username;
        $amount      = (int)$amount;
        $kd_transaksi = (string)$kd_transaksi;
        $agentSign   = 'DEPO_' . $kd_transaksi;

        // ============================================================
        // FIX B: DEDUP - cek transferStatus SEBELUM deposit.
        // Mencegah double-deposit saat retry (cron / getBal / manual),
        // karena agent_sign deterministik 'DEPO_<kd_transaksi>'.
        // Jika game API sudah mencatat transfer dengan sign sama,
        // anggap SUKSES dan JANGAN deposit lagi.
        // ============================================================
        try {
            $ts = $WL->transferStatus($username, $agentSign);
            if (is_array($ts) && isset($ts['status']) && (int)$ts['status'] === 1) {
                return ['ok' => true, 'msg' => 'ALREADY_TRANSFERRED', 'retried_create' => false];
            }
        } catch (Exception $e) {
            // transferStatus gagal -> lanjut deposit normal (server game mungkin down)
        } catch (Throwable $e) {
            // PHP 7+ catch fatal juga
        }

        $res = $WL->deposit($username, $amount, $agentSign);

        if (isset($res['status']) && $res['status'] == 1) {
            return ['ok' => true, 'msg' => 'OK', 'retried_create' => false];
        }

        $errMsg = isset($res['msg']) ? (string)$res['msg'] : 'Unknown game API error';

        // Best-effort: mungkin user game belum dibuat (user lama / register gagal API).
        // Coba create() sekali, lalu retry deposit.
        try {
            $created = $WL->create($username);
            if (isset($created['status']) && $created['status'] == 1) {
                $res2 = $WL->deposit($username, $amount, $agentSign);
                if (isset($res2['status']) && $res2['status'] == 1) {
                    return ['ok' => true, 'msg' => 'OK', 'retried_create' => true];
                }
                $errMsg = isset($res2['msg']) ? (string)$res2['msg'] : $errMsg;
            }
        } catch (Exception $e) {
            // abaikan, laporkan error awal
        }

        return ['ok' => false, 'msg' => $errMsg, 'retried_create' => false];
    }

    /**
     * ============================================================
     * FIX B (baru): RETRY deposit game untuk transaksi yang sudah
     * dikredit saldo lokalnya (status=1) tapi deposit ke API game
     * gagal (note mengandung [GAME-API-FAIL).
     *
     * Dipanggil oleh:
     *   - getBal.php / getbalance.php (saat member buka halaman)
     *   - cron_autocredit_qris.php (lapis 3)
     *
     * Aman (idempotent):
     *   - qris_autocredit_game_deposit() sudah dedup via transferStatus
     *   - note [GAME-API-FAIL -> [GAME-API-RECOVERED setelah sukses
     *
     * @param mysqli $conn
     * @param fiver  $WL   (object game API) atau null -> buat sendiri via include class_softgaming
     * @param int    $userID  0 = semua user, >0 = hanya user tsb
     * @param int    $limit   max transaksi per pemanggilan
     * @return array {retried:int, recovered:int, still_failed:int, already:bool, error:string}
     */
    function qris_autocredit_retry_game_deposits($conn, $WL = null, $userID = 0, $limit = 10)
    {
        $out = ['retried' => 0, 'recovered' => 0, 'still_failed' => 0, 'already' => false, 'error' => ''];

        $userID = (int)$userID;
        $limit  = max(1, (int)$limit);

        // Cari transaksi deposit sukses (status=1) yang deposit game-nya gagal
        $sql = "SELECT t.cuid, t.kd_transaksi, t.userID, t.total, t.note
                FROM tb_transaksi t
                WHERE t.jenis = 1
                  AND t.status = 1
                  AND t.note LIKE '%[GAME-API-FAIL%'
                " . ($userID > 0 ? " AND t.userID = " . $userID . " " : "") . "
                ORDER BY t.cuid DESC
                LIMIT " . $limit;
        $res = mysqli_query($conn, $sql);
        if (!$res) {
            $out['error'] = 'DB: ' . mysqli_error($conn);
            return $out;
        }

        if (mysqli_num_rows($res) == 0) {
            $out['already'] = true;
            return $out;
        }

        // Muat class game API jika belum ada
        if (!is_object($WL)) {
            if (!class_exists('fiver')) {
                $sgPath = dirname(__DIR__) . '/config/class_softgaming.php';
                if (file_exists($sgPath)) {
                    include_once $sgPath;
                }
            }
            if (class_exists('fiver')) {
                $WL = new fiver();
            } else {
                $out['error'] = 'fiver class not found';
                return $out;
            }
        }

        $rows = [];
        while ($r = mysqli_fetch_assoc($res)) {
            $rows[] = $r;
        }

        foreach ($rows as $row) {
            $kd       = (string)$row['kd_transaksi'];
            $uName    = '';
            // Ambil username dari tb_user via helper
            $uRow = qris_autocredit_get_user($conn, (int)$row['userID']);
            if (is_array($uRow) && isset($uRow['username'])) {
                $uName = (string)$uRow['username'];
            }
            if ($uName === '') {
                $out['still_failed']++;
                continue;
            }

            $amount = (int)$row['total'];
            $out['retried']++;

            $depRes = qris_autocredit_game_deposit($WL, $uName, $amount, $kd);
            if (!empty($depRes['ok'])) {
                // Sukses (termasuk ALREADY_TRANSFERRED) -> tandai RECOVERED
                $tag = ($depRes['msg'] === 'ALREADY_TRANSFERRED')
                    ? '[GAME-API-RECOVERED(already): ' . date('Ymd-His') . ']'
                    : '[GAME-API-RECOVERED: ' . date('Ymd-His') . ']';
                $newNote = str_replace('[GAME-API-FAIL', $tag, (string)$row['note']);
                $newNoteEsc = mysqli_real_escape_string($conn, $newNote);
                mysqli_query($conn, "UPDATE tb_transaksi SET note = '" . $newNoteEsc . "'
                                     WHERE cuid = " . (int)$row['cuid'] . " LIMIT 1");
                $out['recovered']++;
            } else {
                $out['still_failed']++;
            }
        }

        return $out;
    }

    /**
     * Proses bonus turnover (promo) bila deposit pakai promo (gameid > 0).
     * Idempotent: hanya proses bila tb_turnover.status masih 0.
     *
     * @param mysqli $conn
     * @param fiver  $WL
     * @param int    $userID
     * @param string $username
     * @param int    $gameid
     * @param string $kd_transaksi
     * @param int    $amount
     * @return int jumlah bonus yang dikredit (0 jika tidak ada)
     */
    function qris_autocredit_process_turnover($conn, $WL, $userID, $username, $gameid, $kd_transaksi, $amount)
    {
        $userID       = (int)$userID;
        $gameid       = (int)$gameid;
        $kd_transaksi = (string)$kd_transaksi;
        $kdEsc        = mysqli_real_escape_string($conn, $kd_transaksi);
        $credited     = 0;

        if ($gameid <= 0 || $userID <= 0) {
            return 0;
        }

        $getTO = mysqli_query($conn, "SELECT cuid, bonus, status FROM tb_turnover WHERE trxID = '$kdEsc' LIMIT 1");
        if (!$getTO || mysqli_num_rows($getTO) == 0) {
            return 0;
        }
        $to = mysqli_fetch_assoc($getTO);

        // Idempotent: hanya proses turnover yang masih pending
        if ((int)$to['status'] !== 0) {
            return 0;
        }

        $bonus = (int)$to['bonus'];
        if ($bonus > 0) {
            // Kredit bonus ke saldo lokal
            qris_autocredit_credit_balance($conn, $userID, $bonus);
            $credited = $bonus;

            // Deposit bonus ke API game - best effort
            try {
                $WL->deposit($username, $bonus, 'BONUS_' . $kd_transaksi);
            } catch (Exception $e) {
                // best effort saja
            }
        }

        // Tandai turnover selesai (idempotent via WHERE status=0)
        mysqli_query($conn, "UPDATE tb_turnover SET status = 1 WHERE trxID = '$kdEsc' AND status = 0");
        // Tandai transaksi promosi (jenis=7) selesai
        mysqli_query($conn, "UPDATE tb_transaksi SET status = 1 WHERE userID = '$userID' AND jenis = '7' AND kd_transaksi = '$kdEsc'");

        return $credited;
    }

    /**
     * ============================================================
     *  MAIN ROUTINE: qris_autocredit_process()
     * ============================================================
     *  Auto-credit 1 transaksi deposit QRIS yang SUDAH LUNAS di AutoGopay.
     *
     *  Dipanggil oleh:
     *   - webhook callback_autogopay.php  (status sukses dari AutoGopay)
     *   - polling check_qris_status.php   (API AutoGopay bilang sukses, lokal masih 0)
     *   - cron cron_autocredit_qris.php   (pending > N menit, API bilang sukses)
     *   - admin approve (referensi implementasi yang sama)
     *
     *  @param mysqli $conn
     *  @param array  $trx        row tb_transaksi (harus punya: cuid, userID, status,
     *                            kd_transaksi, gameid, total)
     *  @param array  $options    [
     *                              'game_api' => bool,  // default true: deposit ke NexusGGR
     *                              'telegram' => bool,  // default true: kirim notif TG
     *                              'log_fn'   => callable|null,
     *                              'source'   => string, // 'webhook'|'polling'|'cron'|'admin'
     *                            ]
     *  @return array {
     *      credited: bool,          // saldo berhasil dikredit (atau sudah pernah)
     *      already:  bool,          // transaksi sudah diproses sebelumnya
     *      amount:   int,
     *      bonus:    int,
     *      game_ok:  bool,
     *      game_msg: string,
     *      error:    string
     *  }
     */
    function qris_autocredit_process($conn, $trx, $options = [])
    {
        $doGameApi = isset($options['game_api']) ? (bool)$options['game_api'] : true;
        $doTelegram = isset($options['telegram']) ? (bool)$options['telegram'] : true;
        $logFn     = isset($options['log_fn']) && is_callable($options['log_fn']) ? $options['log_fn'] : null;
        $source    = isset($options['source']) ? (string)$options['source'] : 'unknown';

        $result = [
            'credited' => false,
            'already'  => false,
            'amount'   => 0,
            'bonus'    => 0,
            'game_ok'  => false,
            'game_msg' => '',
            'error'    => '',
        ];

        $cuid    = (int)$trx['cuid'];
        $userID  = (int)$trx['userID'];
        $kdEsc   = mysqli_real_escape_string($conn, (string)$trx['kd_transaksi']);
        $kd_transaksi = (string)$trx['kd_transaksi'];
        $gameid  = isset($trx['gameid']) ? (int)$trx['gameid'] : 0;
        $amount  = isset($trx['total']) ? (int)$trx['total'] : 0;

        if ($cuid <= 0 || $userID <= 0) {
            $result['error'] = 'Invalid transaction row';
            return $result;
        }

        $log = function ($msg) use ($logFn, $source) {
            if ($logFn) {
                call_user_func($logFn, '[' . $source . '] ' . $msg);
            }
        };

        // ============================================================
        // 1. IDEMPOTENCY LOCK: tandai status=1 HANYA JIKA masih 0.
        //    mysqli_affected_rows()==0 -> sudah diproses proses lain
        //    (webhook lain / polling / cron / admin) -> jangan kredit 2x.
        // ============================================================
        $lock = mysqli_query($conn, "UPDATE tb_transaksi
            SET status = 1
            WHERE cuid = '$cuid' AND jenis = '1' AND (status = 0 OR status IS NULL)");

        if (!$lock || mysqli_affected_rows($conn) == 0) {
            $result['already'] = true;
            $log("Already processed (cuid=$cuid kd=$kdEsc). Skip double credit.");
            return $result;
        }

        // ============================================================
        // 2. Ambil username user
        // ============================================================
        $u = qris_autocredit_get_user($conn, $userID);
        if (!$u) {
            $result['error'] = 'User not found (userID=' . $userID . ')';
            $log("ERROR user not found userID=$userID");
            return $result;
        }
        $username = $u['username'];
        $result['amount'] = $amount;
        $log("Start auto-credit cuid=$cuid user=$username amount=$amount kd=$kdEsc");

        // ============================================================
        // 3. KREDIT SALDO MEMBER DULU (FIX URUTAN + FIX BARIS TB_BALANCE)
        //    tb_balance dipastikan ada, baru active += amount.
        //    Ini lapis utama: member LANGSUNG dapat coin walau game API down.
        // ============================================================
        $credited = qris_autocredit_credit_balance($conn, $userID, $amount);
        if (!$credited) {
            $result['error'] = 'Failed to update tb_balance';
            $log("ERROR credit balance failed userID=$userID amount=$amount");
            return $result;
        }
        $result['credited'] = true;
        $log("Balance credited: userID=$userID +$amount");

        // ============================================================
        // 4. DEPOSIT KE API GAME (BEST-EFFORT, tidak memblokir kredit)
        //    FIX dari versi lama: dulu jika game API gagal -> tidak ada
        //    credit sama sekali. Sekarang saldo tetap masuk; kegagalan
        //    game API dicatat di note untuk di-retry cron berikutnya.
        // ============================================================
        $gameOk  = false;
        $gameMsg = '';
        if ($doGameApi && $amount > 0) {
            try {
                $gameObj = qris_autocredit_get_wl($options);
                $gameRes = qris_autocredit_game_deposit($gameObj, $username, $amount, $kd_transaksi);
                $gameOk  = $gameRes['ok'];
                $gameMsg = $gameRes['msg'];
            } catch (Throwable $e) {
                $gameMsg = $e->getMessage();
            }

            if ($gameOk) {
                $log("Game API deposit OK (user=$username +$amount sign=DEPO_$kdEsc)");
            } else {
                // Catat kegagalan di note transaksi untuk audit & retry manual
                $errNote = ' [GAME-API-FAIL: ' . mysqli_real_escape_string($conn, substr($gameMsg, 0, 150)) . ']';
                mysqli_query($conn, "UPDATE tb_transaksi SET note = CONCAT(note, '$errNote') WHERE cuid = '$cuid'");
                $log("Game API deposit FAILED (user=$username): $gameMsg -> saldo lokal tetap dikredit, dicatat di note");
            }
        }
        $result['game_ok']  = $gameOk;
        $result['game_msg'] = $gameMsg;

        // ============================================================
        // 5. BONUS TURNOVER (jika deposit pakai promo)
        // ============================================================
        if ($gameid > 0) {
            try {
                $gameObj2 = qris_autocredit_get_wl($options);
                $bonusCredited = qris_autocredit_process_turnover($conn, $gameObj2, $userID, $username, $gameid, $kd_transaksi, $amount);
                $result['bonus'] = $bonusCredited;
                if ($bonusCredited > 0) {
                    $log("Bonus turnover credited: +$bonusCredited (gameid=$gameid)");
                }
            } catch (Throwable $e) {
                $log("Bonus turnover error: " . $cuid . " " . $e->getMessage());
            }
        }

        // ============================================================
        // 6. NOTIFIKASI TELEGRAM (best-effort)
        // ============================================================
        if ($doTelegram) {
            try {
                $status = $gameOk ? 'OK' : 'FAIL(' . substr($gameMsg, 0, 80) . ')';
                $msg =
                    "━━━━━━━━━━━━━━━\n" .
                    "💰 *DEPOSIT SUCCESS (AUTOCREDIT - " . strtoupper($source) . ")*\n" .
                    "━━━━━━━━━━━━━━━\n" .
                    "👤 User : `$username`\n" .
                    "💵 Amount : *Rp " . number_format($amount, 0, ',', '.') . "*\n" .
                    ($result['bonus'] > 0 ? "🎁 Bonus : Rp " . number_format($result['bonus'], 0, ',', '.') . "\n" : "") .
                    "🧾 TrxID : `$kd_transaksi`\n" .
                    "🎮 GameAPI : $status\n" .
                    "🕒 " . date('d-m-Y H:i:s');
                qris_autocredit_send_telegram($msg);
            } catch (Exception $e) {
                // abaikan
            }
        }

        $log("=== AUTO-CREDIT SUCCESS cuid=$cuid user=$username amount=$amount ===");

        return $result;
    }

    /**
     * Ambil instance fiver (game API) dari options / global / buat baru.
     *
     * @param array $options
     * @return fiver
     */
    function qris_autocredit_get_wl($options)
    {
        if (isset($options['wl']) && $options['wl'] instanceof fiver) {
            return $options['wl'];
        }
        if (isset($GLOBALS['WL']) && $GLOBALS['WL'] instanceof fiver) {
            return $GLOBALS['WL'];
        }
        return new fiver();
    }

    /**
     * Kirim notifikasi Telegram (best-effort).
     * Token/chat_id sama dengan yang dipakai file lain di sistem.
     *
     * @param string $message
     * @return bool
     */
    function qris_autocredit_send_telegram($message)
    {
        $token   = "8252193112:AAFaFAz4wDXi2Ofa84xCpPZw6ZCPnJZ31GY";
        $chat_id = "-1003763327869";
        if ($token === '' || $chat_id === '') {
            return false;
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . $token . "/sendMessage");
        curl_setopt($ch, CURLOPT_POST, 1);
        $data = [
            'chat_id'    => $chat_id,
            'text'       => $message,
            'parse_mode' => 'Markdown',
        ];
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res !== false;
    }
}
