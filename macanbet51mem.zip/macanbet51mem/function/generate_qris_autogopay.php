<?php
/**
 * Generate QRIS Dinamis via AutoGopay (Member Deposit) — FIXED VERSION
 * Platform: https://autogopay.net
 *
 * ============ PERBAIKAN PENTING (vs versi lama) ============
 *  [FIX #1] FORMAT orderId: 'DEPO' . time() . rand(10,99) = 16 karakter
 *           -> PAS dengan kolom tb_transaksi.kd_transaksi varchar(16).
 *           Versi lama: 'DEPO' . time() . $userID = 17-18 karakter yang
 *           TER-TRUNCATE diam-diam menjadi 16 char di MySQL, sehingga
 *           reference webhook AutoGopay (17-18 char) TIDAK PERNAH cocok
 *           dengan kd_transaksi di DB -> "Transaction not found" ->
 *           coin/saldo TIDAK PERNAH masuk otomatis. (BUG FATAL UTAMA)
 *  [FIX #2] VALIDASI KEPEMILIKAN: username diambil dari $_SESSION['user'],
 *           bukan dari POST. Versi lama percaya POST username sehingga
 *           user login manapun bisa membuat deposit atas nama user lain.
 *  [FIX #3] Cek duplikasi kd_transaksi sebelum INSERT (loop max 3x).
 *  [FIX #4] Error mysqli tidak di-die() (bocor struktur DB ke member),
 *           diganti response JSON + log.
 *
 * Alur:
 *  1. Member input nominal deposit di halaman deposit
 *  2. File ini memanggil AutoGopay API /api/v1/payment/create
 *  3. AutoGopay mengembalikan qris_string + qr_image
 *  4. Simpan transaksi ke tb_transaksi (status=0/pending)
 *  5. Simpan data QRIS ke session, redirect ke halaman QRIS payment
 *  6. Member scan QRIS & bayar -> AutoGopay webhook -> callback_autogopay.php
 *     (lapis 1) / polling check_qris_status.php (lapis 2) / cron (lapis 3)
 *  7. Semua lapis memanggil autocredit_helper.php -> saldo otomatis masuk
 */
session_start();
date_default_timezone_set("Asia/Jakarta");

include('../config/koneksi.php');
include('../config/class_softgaming.php');
include('../config/class.autogopay.php');

header('Content-Type: application/json');

/**
 * Helper response JSON
 */
function jsonResponse($success, $message, $data = null, $code = 200)
{
    http_response_code($code);
    echo json_encode([
        'success'   => $success,
        'message'   => $message,
        'data'      => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);
    exit;
}

/**
 * Log error ke file (tanpa mengekspos ke member)
 */
function writeGenLog($message)
{
    $logFile = __DIR__ . '/../logs/autogopay_generate_' . date('Y-m-d') . '.log';
    $logDir  = dirname($logFile);
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    @file_put_contents($logFile, '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n", FILE_APPEND);
}

/**
 * Ambil konfigurasi dari tb_seo
 */
function loadSeoConfig($conn)
{
    $sql = "SELECT * FROM tb_seo WHERE cuid = 1 LIMIT 1";
    $q = mysqli_query($conn, $sql);
    return $q ? mysqli_fetch_assoc($q) : null;
}

/**
 * Deteksi website aktif (site 1 / site 2) berdasarkan host saat ini
 */
function resolveActiveSite($config)
{
    $currentHost  = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $protocol     = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $currentFull  = rtrim($protocol . $currentHost, '/');

    $urlweb2 = isset($config['urlweb2']) ? rtrim($config['urlweb2'], '/') : '';
    $host2   = $urlweb2 !== '' ? parse_url($urlweb2, PHP_URL_HOST) : '';

    if (!empty($host2) && (strpos($currentFull, $host2) !== false || $currentFull === $urlweb2)) {
        return [
            'urlweb' => $config['urlweb2'],
            'site'   => 2,
        ];
    }

    return [
        'urlweb' => $config['urlweb'],
        'site'   => 1,
    ];
}

/**
 * [FIX #1] Generate orderId unik yang PAS 16 karakter (varchar(16)).
 * 'DEPO'(4) + time()(10) + rand(10..99)(2) = 16 char — tidak ter-truncate.
 * Ada pengecekan duplikasi ke DB (loop max 3x) untuk jaga keunikan.
 */
function generateOrderId16($conn)
{
    for ($i = 0; $i < 3; $i++) {
        $orderId = 'DEPO' . time() . rand(10, 99);
        $orderId = preg_replace('/[^a-zA-Z0-9]/', '', $orderId);
        if (strlen($orderId) > 16) {
            $orderId = substr($orderId, 0, 16);
        }
        $esc = mysqli_real_escape_string($conn, $orderId);
        $cek = mysqli_query($conn, "SELECT cuid FROM tb_transaksi WHERE kd_transaksi = '$esc' LIMIT 1");
        if ($cek && mysqli_num_rows($cek) == 0) {
            return $orderId; // unik, siap dipakai
        }
    }
    // Fallback ekstra-unik (masih 16 char): waktu acak mikrodetik
    $orderId = 'DEPO' . substr((string)(time() . mt_rand(100, 999)), 0, 12);
    return substr($orderId, 0, 16);
}

/**
 * Simpan bonus turnover jika deposit pakai promo (gameid)
 */
function saveBonusTurnover($conn, $gameid, $userID, $kd_transaksi, $amount)
{
    if ($gameid <= 0) {
        return;
    }
    $sql_transaksi = mysqli_query($conn, "SELECT * FROM `tb_post` WHERE cuid = '$gameid'");
    if (!$sql_transaksi) {
        return;
    }
    $st = mysqli_fetch_array($sql_transaksi);
    if (!$st) {
        return;
    }

    $jml_to   = $st['min_to'];
    $persen   = $st['persen'] / 100;
    $bonuse   = round($amount * $persen);
    $bonusDepo = ($bonuse > 200000) ? 200000 : $bonuse;
    $totalTO  = ($amount + $bonusDepo) * $jml_to;
    $sisaTO   = $totalTO;
    $expiredAt = date('Y-m-d H:i:s', strtotime('+1 day'));

    mysqli_query($conn, "INSERT INTO `tb_turnover`
        (`userID`, `trxID`, `depo`, `bonus`, `jmlh_to`, `total_to`, `sisa_to`, `status`, `created_at`, `expired_at`)
        VALUES
        ('$userID', '$kd_transaksi', '$amount', '$bonusDepo', '$jml_to', '$totalTO', '$sisaTO', 0, NOW(), '$expiredAt')");
}

// ============================================================
// MAIN
// ============================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed. Gunakan POST.', null, 405);
}

if (!isset($_SESSION['user']) || $_SESSION['user'] === '') {
    jsonResponse(false, 'Anda harus login terlebih dahulu.', null, 401);
}

try {
    // [FIX #2] Username HANYA dari session — tidak lagi percaya POST.
    // POST username tetap dibaca hanya untuk validasi konsistensi form.
    $username   = trim((string)$_SESSION['user']);
    $postUser   = isset($_POST['username']) ? trim((string)$_POST['username']) : '';
    $amount     = intval($_POST['amount'] ?? 0);
    $gameid     = isset($_POST['gameid']) ? intval($_POST['gameid']) : 0;

    if ($postUser !== '' && strcasecmp($postUser, $username) !== 0) {
        // Form mengirim username berbeda dari session -> tolak (anti spoofing)
        writeGenLog("REJECT: post username ('$postUser') != session user ('$username')");
        jsonResponse(false, 'Username tidak sesuai dengan sesi login.', null, 403);
    }

    if ($username === '') {
        jsonResponse(false, 'Username tidak boleh kosong', null, 400);
    }

    $config = loadSeoConfig($conn);
    if (!$config) {
        jsonResponse(false, 'Konfigurasi tidak ditemukan', null, 500);
    }

    // Validasi minimum deposit dari tb_seo
    $minDeposit = isset($config['mindepo']) ? (int)str_replace(',', '', $config['mindepo']) : 10000;
    if ($amount < $minDeposit) {
        jsonResponse(false, 'Minimum deposit adalah Rp ' . number_format($minDeposit, 0, ',', '.'), [
            'min'      => $minDeposit,
            'provided' => $amount
        ], 400);
    }
    $maxDeposit = isset($config['maxdepo']) ? (int)str_replace(',', '', $config['maxdepo']) : 100000000;
    if ($amount > $maxDeposit) {
        jsonResponse(false, 'Maximum deposit adalah Rp ' . number_format($maxDeposit, 0, ',', '.'), [
            'max'      => $maxDeposit,
            'provided' => $amount
        ], 400);
    }
    // AutoGopay minimum 1000, jaga-jaga
    if ($amount < 1000) {
        jsonResponse(false, 'Nominal minimal Rp 1.000', null, 400);
    }

    // Ambil data user
    $user = mysqli_query($conn, "SELECT * FROM `tb_user` WHERE username = '" . mysqli_real_escape_string($conn, $username) . "'");
    if (!$user) {
        writeGenLog('DB error saat cari user: ' . mysqli_error($conn));
        jsonResponse(false, 'Terjadi kesalahan sistem. Silakan coba lagi.', null, 500);
    }
    $u = mysqli_fetch_array($user);
    if (!$u) {
        jsonResponse(false, 'User tidak ditemukan', null, 404);
    }
    $userID = $u['cuid'];

    // Deteksi site aktif
    $site    = resolveActiveSite($config);
    $urlweb  = $site['urlweb'];
    $siteNo  = $site['site'];

    // Provider: AutoGopay
    $provider = 'autogopay';

    // [FIX #1] orderId 16 char — PAS varchar(16), tidak ter-truncate
    $orderId = generateOrderId16($conn);

    // Pilih API key & webhook secret sesuai site aktif
    if ($siteNo === 2) {
        $apiKey        = isset($config['autogopay_apikey2']) ? $config['autogopay_apikey2'] : '';
        $webhookSecret = isset($config['autogopay_wh_secret2']) ? $config['autogopay_wh_secret2'] : '';
    } else {
        $apiKey        = isset($config['autogopay_apikey']) ? $config['autogopay_apikey'] : '';
        $webhookSecret = isset($config['autogopay_wh_secret']) ? $config['autogopay_wh_secret'] : '';
    }

    if (empty($apiKey)) {
        jsonResponse(false, 'API Key AutoGopay belum dikonfigurasi. Silakan hubungi administrator.', null, 500);
    }

    // URL callback webhook AutoGopay
    $callbackUrl = rtrim($urlweb, '/') . '/callback_autogopay.php';

    $customerName = !empty($u['full_name']) ? $u['full_name'] : $username;

    // Panggil API AutoGopay untuk create payment
    $autogopay = new AutoGopay($apiKey, $webhookSecret);
    $apiResponse = $autogopay->createPayment([
        'amount'        => $amount,
        'reference'     => $orderId,
        'description'   => 'Deposit QRIS ' . $username,
        'customer_name' => $customerName,
        'callback_url'  => $callbackUrl,
    ]);

    if (!isset($apiResponse['success']) || $apiResponse['success'] !== true) {
        $errorMsg = isset($apiResponse['message']) ? $apiResponse['message'] : 'Gagal membuat pembayaran AutoGopay';
        writeGenLog("Create payment GAGAL user=$username amount=$amount ref=$orderId : $errorMsg");
        jsonResponse(false, $errorMsg, null, 500);
    }

    $data = $apiResponse['data'];

    $qrisContent = isset($data['qris_string']) ? $data['qris_string'] : '';
    $qrImageUrl   = isset($data['qr_image']) ? $data['qr_image'] : '';
    $paymentUrl   = isset($data['payment_url']) ? $data['payment_url'] : '';
    $invoiceId    = isset($data['invoice']) ? $data['invoice'] : '';
    $expiredAt    = isset($data['expired_at']) ? $data['expired_at'] : '';

    if (empty($qrisContent)) {
        writeGenLog("Response AutoGopay tanpa qris_string user=$username ref=$orderId");
        jsonResponse(false, 'qris_string tidak ditemukan dalam response AutoGopay', null, 500);
    }

    // Fallback QR image jika API tidak memberikan
    if (empty($qrImageUrl)) {
        $qrImageUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($qrisContent);
    }

    $providerLabel = 'AUTOGOPAY';
    $kd_transaksi  = $orderId; // 16 char, TIDAK ter-truncate — reference webhook akan cocok exact
    $created_date  = date('Y-m-d H:i:s');
    // Simpan invoice & expired di note agar mudah ditemukan saat webhook / cron
    $note = mysqli_real_escape_string($conn, $providerLabel . ' - INVOICE: ' . $invoiceId . ' | ORDER: ' . $orderId . ' | EXP: ' . $expiredAt);

    // [FIX #4] Tanpa die(mysqli_error) — log + response rapi
    $insert = mysqli_query($conn, "INSERT INTO `tb_transaksi`
        (`kd_transaksi`, `date`, `transaksi`, `total`, `saldo`, `note`, `gameid`, `providerID`, `jenis`, `metode`, `pay_from`, `userID`, `status`)
        VALUES
        ('$kd_transaksi', '$created_date', 'Top Up QRIS', '$amount', 0, '$note', '$gameid', '0', '1', 'QRIS', '0', '$userID', 0)");

    if (!$insert) {
        writeGenLog('DB error INSERT tb_transaksi: ' . mysqli_error($conn) . " | ref=$orderId user=$username");
        jsonResponse(false, 'Gagal menyimpan transaksi. Silakan coba lagi.', null, 500);
    }

    // Simpan ke session untuk halaman QRIS payment
    $_SESSION['qris_payment'] = [
        'kd_transaksi' => $kd_transaksi,
        'trx_id'       => $invoiceId,        // invoice AutoGopay
        'order_id'     => $orderId,          // reference sistem (16 char)
        'qris_data'    => $qrisContent,
        'payment_url'  => $paymentUrl,
        'qr_image_url' => $qrImageUrl,
        'provider'     => $provider,
        'amount'       => $amount,
        'username'     => $username,
        'created_at'   => time()
    ];

    // Bonus turnover jika ada promo
    saveBonusTurnover($conn, $gameid, $userID, $kd_transaksi, $amount);

    writeGenLog("QRIS generated: user=$username userID=$userID amount=$amount ref=$orderId invoice=$invoiceId");

    jsonResponse(true, 'QRIS berhasil digenerate via ' . $providerLabel, [
        'redirect'      => rtrim($urlweb, '/') . '/m/account/qris_payment',
        'kd_transaksi'  => $kd_transaksi,
        'trx_id'        => $invoiceId,
        'order_id'      => $orderId,
        'qr_image'      => $qrImageUrl,
        'payment_url'   => $paymentUrl,
        'provider'      => $provider
    ], 200);

} catch (Exception $e) {
    writeGenLog('Exception: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    jsonResponse(false, 'Terjadi kesalahan sistem. Silakan coba lagi.', null, 500);
}
