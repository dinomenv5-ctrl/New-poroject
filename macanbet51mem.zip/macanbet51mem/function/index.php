<?php
header('location:../');
?>