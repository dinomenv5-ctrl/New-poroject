<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('session.php');

if (!function_exists('get_active_base_url')) {
    include(__DIR__ . '/../config/url_helper.php');
}
$urlweb = get_active_base_url();

/* ===============================
   AMBIL MINIMUM DEPOSIT
=================================*/
$result = mysqli_query($conn, "SELECT mindepo FROM tb_seo LIMIT 1");
$seo = mysqli_fetch_assoc($result);
$minDeposit = (int)str_replace(',', '', $seo['mindepo']);

/* ===============================
   VALIDASI SUBMIT
=================================*/
if(!isset($_POST['submit'])){
    header('Location: '.$urlweb.'/m/account/deposit/?notif=6');
    exit();
}

/* ===============================
   AMBIL DATA POST
=================================*/
$metode     = $_POST['metode'] ?? '';
$nominalRaw = $_POST['nominal'] ?? '0';
$pay_from   = $_POST['pay_from'] ?? '';
$catatan    = $_POST['catatan'] ?? '';
$postID     = $_POST['postID'] ?? '';

$nominal = preg_replace('/[^0-9]/','', $nominalRaw);
$nominal = (float)$nominal;

if($nominal < $minDeposit){
    header('Location: '.$urlweb.'/m/account/deposit/?notif=6&msg=Nominal kurang dari minimum');
    exit();
}

if(empty($pay_from) || empty($postID)){
    header('Location: '.$urlweb.'/m/account/deposit/?notif=6');
    exit();
}

/* ===============================
   GENERATE DATA TRANSAKSI
=================================*/
$kd_transaksi = date('YmdHis') . rand(10,99);
$created_date = date('Y-m-d H:i:s');

$metode_escaped   = mysqli_real_escape_string($conn, $metode);
$pay_from_escaped = mysqli_real_escape_string($conn, $pay_from);
$catatan_escaped  = mysqli_real_escape_string($conn, $catatan);
$postID           = (int)$postID;

/* ===============================
   INSERT TRANSAKSI
=================================*/
$insert = mysqli_query($conn,"INSERT INTO tb_transaksi
(kd_transaksi,date,transaksi,total,saldo,note,gameid,providerID,jenis,metode,pay_from,userID,status)
VALUES
('$kd_transaksi','$created_date','Top Up','$nominal',0,'$catatan_escaped','0','0','1','$metode_escaped','$pay_from_escaped','$postID',0)
");

if(!$insert){
    header('Location: '.$urlweb.'/m/account/deposit/?notif=6');
    exit();
}

/* ===============================
   TELEGRAM NOTIF DEPOSIT MANUAL
=================================*/
$bot_token = "8252193112:AAFaFAz4wDXi2Ofa84xCpPZw6ZCPnJZ31GY";
$chat_id   = "-1003763327869";

$getUser = mysqli_query($conn,"SELECT username FROM tb_user WHERE cuid='$postID'");
$user = mysqli_fetch_array($getUser);
$usernameMember = $user['username'];

$pesan  = "📝 REQUEST DEPOSIT MANUAL\n\n";
$pesan .= "👤 User : $usernameMember\n";
$pesan .= "💰 Nominal : Rp ".number_format($nominal,0,',','.')."\n";
$pesan .= "🏦 Dari : $pay_from\n";
$pesan .= "🆔 KD : $kd_transaksi\n";
$pesan .= "⏰ $created_date\n";
$pesan .= "🔔 Status : PENDING";

$url = "https://api.telegram.org/bot".$bot_token."/sendMessage";

$data = [
    'chat_id' => $chat_id,
    'text' => $pesan
];

$options = [
    'http' => [
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($data),
    ]
];

$context = stream_context_create($options);
file_get_contents($url, false, $context);

/* ===============================
   REDIRECT SUCCESS
=================================*/
header('Location: '.$urlweb.'/m/?notif=8');
exit();
?>