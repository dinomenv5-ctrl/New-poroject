<?php
// Fetch data from the tb_wprovider table
$query = "SELECT * FROM tb_prov_sgx where provider_type ='LC' and provider_status =1";
$result = mysqli_query($conn, $query);
// Check if the query was successful
if ($result) {
    echo '<div class="row no-gutters text-center slider-content">';

    // Loop through the rows of the result set
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="col">';
        echo '<a class="btn-box" href="?provider=' . $row['provider_code'] . '" rel="opener">';
        $provider_image = strtolower(str_replace(' ', '-', $row['provider_name'])) . '.png';
        echo '<img alt="" src="'.$urlweb.'/uploads/provider/'.$provider_image.'" data-src="'.$urlweb.'/uploads/provider/'.$provider_image.'" height="50%" width="50%"/>';
        echo '<div class="text-center fs-sm game-title">' . $row['provider_name'] . '</div>';
        echo '</a>';
        echo '</div>';
    }

    echo '</div>';
} else {
    // Handle database query error
    echo 'Error executing query: ' . mysqli_error($conn, $query);
}

?>