<?php
// Halaman metode

ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
require_once(__DIR__ . '/../../config/koneksi.php');
require_once(__DIR__ . '/../../config/class_softgaming.php');
$autopayment_path = __DIR__ . '/../../config/autopayment.php';
if (file_exists($autopayment_path)) {
    include $autopayment_path;
}
$AP = isset($AP) ? $AP : null;

$data = $AP ? json_decode($AP->channel(), true) : [];
$sid = session_id();
$sql_0 = mysqli_query($conn, "SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);
$urlweb = $s0['urlweb'];

$sql_1 = mysqli_query($conn, "SELECT * FROM `tb_user` WHERE cuid = 1") or die(mysqli_error());
$s1b = mysqli_fetch_array($sql_1);

if (empty($_SESSION['user']) && empty($_SESSION['pass'])) {
    header('location:' . $urlweb . '/index');
    exit;
}

$user = mysqli_query($conn, "SELECT * FROM `tb_user` WHERE username = '" . $_SESSION['user'] . "'") or die(mysqli_error());
$u = mysqli_fetch_array($user);
$users = $u['username'];
$id_user = $u['cuid'];
$userID = $u['cuid'];

$sql_3 = mysqli_query($conn, "SELECT * FROM `tb_balance` WHERE userID = '$userID'") or die(mysqli_error());
$s3 = mysqli_fetch_array($sql_3);

$sql_banks = mysqli_query($conn, "SELECT * FROM `tb_bank` WHERE userID = '$userID'") or die(mysqli_error());
$sbs = mysqli_fetch_array($sql_banks);

include "../header.php"; ?>
<style>
/* Styles for .content */
.content {
    /*background-color: #b8860b; /* Dark golden background color */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.content h1 {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #fff; /* White text color */
}

/* Form Styles */
form#depositForm {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

form#depositForm .form-group {
    margin-bottom: 20px;
}

form#depositForm label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #333;
}

form#depositForm input, form#depositForm select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
    color: #000; /* Black text color */
    background-color: #fff; /* White background color */
}

form#depositForm input[type="number"] {
    -moz-appearance: textfield;
}

form#depositForm input[type="number"]::-webkit-outer-spin-button,
form#depositForm input[type="number"]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

form#depositForm button {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

form#depositForm button:hover {
    background-color: #0056b3;
}

/* Alert Styles */
.alert {
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 5px;
}

.alert-danger {
    background-color: #f8d7da;
    border-color: #f5c6cb;
    color: #721c24;
}

.alert-dismissible .close {
    position: relative;
    top: -2px;
    right: -21px;
    color: inherit;
}

/* Payment Details Styles */
#paymentDetails .form-group label,
#paymentDetails .form-group span {
    display: inline-block;
    margin-right: 10px;
    font-weight: bold;
    color: #333;
}

/* Status Indicator Styles */
.status-indicator {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 5px;
    color: #fff;
    font-weight: bold;
}

.status-on {
    background-color: #28a745; /* Green */
}

.status-off {
    background-color: #dc3545; /* Red */
}

/* Responsive Styles */
@media (max-width: 768px) {
    .content {
        padding: 15px;
    }
    
    form#depositForm {
        padding: 15px;
    }
}

</style>
<div class="content my01">
    <script type="text/javascript" src="https://cdn.sitestatic.net/assets/jquery/jquery.price_format.min.js?v=2"></script>
    <div class="container-wrapper acc">
        <div class="container container-box">
            <div class="row">
                <div class="col-md-8">
                    <div class="box-wrapper">
                        <div class="title" style="padding: 5px 0">
                            <div class="d-inline-block" style="padding-left:15px" i18n>Keamanan Akun: Normal</div>
                            <div class="d-inline-block text-right" style="float:right;padding-right:15px">Anda memiliki
                                <span class="txt_mail_cnt">0</span> pesan baru yang belum dibaca dari kami.</div>
                        </div>

                        <div class="mdc-wrapper">
                            <a href="<?php echo $urlweb; ?>/desktop/account/deposit" class="mdc-items active">Deposit</a>
                            <a href="<?php echo $urlweb; ?>/desktop/account/withdrawal" class="mdc-items">Withdraw</a>
                            <a href="<?php echo $urlweb; ?>/desktop/account/lastDirectTransfer" class="mdc-items">5 Transaksi Terakhir</a>
                            <a href="<?php echo $urlweb; ?>/desktop/account/history" class="mdc-items">Pernyataan</a>
                        </div> 
                    </div>

                    <?php
                    error_reporting(0);
                    $useridnya = $u['cuid'];
                    $cekTransaksi = mysqli_query($conn,"SELECT * FROM `tb_transaksi` WHERE userID = '$useridnya' AND jenis = 1 AND status = 0") or die(mysqli_error());
                    $ct = mysqli_num_rows($cekTransaksi);
                    $jumlahdeposit = $row['total'];
                    if($ct > 0){
                    echo '
                    <div class="alert alert-danger alert-dismissible mb-2" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <div class="alert-message text-justify">
                    <span>Anda masih memiliki Permintaan Deposit yang Belum Diproses. Silahkan Tunggu Hingga Proses Penarikan Sebelumnya Selesai.</span>
                    </div>
                    </div>
                    ';
                ?>
        <?php } else { ?>
            <div class="content">
<h1>Pilih Metode Pembayaran</h1>
<form id="depositForm" action="<?php echo $urlweb; ?>/function2/autopay.php" method="post">
    <input type="hidden" name="postID" class="form-control" value="<?php echo $u['cuid']; ?>">
    <div class="form-group">
        <label for="paymentMethod">Metode Pembayaran</label>
        <select name="paymentMethod" id="paymentMethod" onchange="showPaymentDetails()">
            <option value="">Pilih Metode Pembayaran</option>
<?php
if (isset($data['channel'])) {
    foreach ($data['channel'] as $option) {
        // Cek apakah payment_name adalah QRIS Softgaming
        if ($option['payment_name'] === 'QRIS Softgaming') {
            continue; // Lewati opsi ini
        }
        
        // Tampilkan opsi lain tanpa data-image
        echo '<option value="' . $option['payment_code'] . '" 
                     data-type="' . $option['payment_type'] . '"
                     data-min="' . $option['payment_min'] . '"
                     data-max="' . $option['payment_max'] . '"
                     data-status="' . $option['payment_status'] . '">'
                     . $option['payment_name'] . 
              '</option>';
    }
} else {
    echo '<option value="">Tidak ada metode pembayaran tersedia</option>';
}
?>


        </select>
    </div>

    <div id="paymentDetails" style="display: none;">
        <div class="form-group">
            <label>Min Deposit:</label>
            <?php
$minDeposit = 25000;
echo '<span id="minDeposit">' . number_format($minDeposit, 2, '.', ',') . '</span>';
?>

        </div>
        <div class="form-group">
            <label>Max Deposit:</label>
            <span id="maxDeposit"></span>
        </div>
        <div class="form-group">
            <label>Status:</label>
            <span id="paymentStatus" class="status-indicator"></span>
        </div>
    </div>

    <div class="form-group" id="ewalletField" style="display: none;">
        <label for="phoneNumber">Nomor HP</label>
        <input type="text" name="phoneNumber" id="phoneNumber" placeholder="Masukkan nomor HP">
    </div>

    <div class="form-group">
        <label for="amount">Nominal Deposit</label>
        <input type="number" name="amount" id="amount" placeholder="Masukkan nominal deposit" required>
    </div>

    <div class="form-group">
        <button type="submit">Kirim</button>
    </div>
</form>

<script>
    function formatIDR(value) {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(value).replace(/(\.|,)00$/g, '');
    }

    function showPaymentDetails() {
        var paymentMethod = document.getElementById('paymentMethod');
        var selectedOption = paymentMethod.options[paymentMethod.selectedIndex];
        var paymentType = selectedOption.getAttribute('data-type');
        var ewalletField = document.getElementById('ewalletField');
        var paymentDetails = document.getElementById('paymentDetails');
        //var minDeposit = document.getElementById('minDeposit');
        var maxDeposit = document.getElementById('maxDeposit');
        var paymentStatus = document.getElementById('paymentStatus');

        // Set nilai mindeposit menjadi 25000
        var minDeposit = document.getElementById('minDeposit');
// Gantikan bagian ini untuk mengambil nilai langsung dari 25000
minDeposit.innerText = formatIDR(25000);

        

        
        if (selectedOption.value !== "") {
            paymentDetails.style.display = 'block';
            
            // Tampilkan nilai mindeposit
            var selectedMinDeposit = parseInt(selectedOption.getAttribute('data-min')) || mindeposit;
            //minDeposit.innerText = formatIDR(selectedMinDeposit);
            
            maxDeposit.innerText = formatIDR(selectedOption.getAttribute('data-max'));
            
            var status = selectedOption.getAttribute('data-status').toUpperCase();
            if (status === 'ON') {
                paymentStatus.className = 'status-indicator status-on';
                paymentStatus.innerText = 'ON';
            } else {
                paymentStatus.className = 'status-indicator status-off';
                paymentStatus.innerText = 'OFF';
            }
        } else {
            paymentDetails.style.display = 'none';
        }
    }
</script>

                </div>
            </div>
        </div>
    </div>
    <?php }?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "../footer.php"; ?>
<script>
    function tutup_bank() {
        window.location.href = '/desktop/account/deposit';
    }
</script>
