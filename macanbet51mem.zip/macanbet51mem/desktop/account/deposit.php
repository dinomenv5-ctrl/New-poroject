<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
require_once('../../config/koneksi.php');
require_once('../../config/class_softgaming.php');

$sid = session_id();
$sql_0 = mysqli_query($conn,"SELECT * FROM `tb_seo` WHERE cuid = 1") or die(mysqli_error());
$s0 = mysqli_fetch_array($sql_0);
$urlweb = $s0['urlweb'];
$urlwebs = $s0['urlweb'];

$sql_1 = mysqli_query($conn,"SELECT * FROM `tb_user` WHERE cuid = 1") or die(mysqli_error());
$s1b = mysqli_fetch_array($sql_1);

if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  header('location:'.$urlwebs.'/index');
  exit;
}

$user =mysqli_query($conn,"SELECT * FROM `tb_user` WHERE username = '".$_SESSION['user']."'") or die (mysqli_error());
$u = mysqli_fetch_array($user);
$users = $u['username'];
$id_user = $u['cuid'];
$userID = $u['cuid'];

$sql_3 = mysqli_query($conn,"SELECT * FROM `tb_balance` WHERE userID = '$userID'") or die(mysqli_error());
$s3 = mysqli_fetch_array($sql_3);

$sql_banks = mysqli_query($conn,"SELECT * FROM `tb_bank` WHERE userID = '$userID'") or die(mysqli_error());
$sbs = mysqli_fetch_array($sql_banks);
include "../header.php";?>

<div class="content my01">
    <script type="text/javascript" src="https://cdn.sitestatic.net/assets/jquery/jquery.price_format.min.js?v=2">
    </script>
    <div class="container-wrapper acc">
        <div class="container container-box">
            <div class="row">
                <div class="col-md-8">
                    <div class="box-wrapper">
                        <div class="title" style="padding: 5px 0">
                            <div class="d-inline-block" style="padding-left:15px" i18n>Keamanan Akun: Normal</div>
                            <div class="d-inline-block text-right" style="float:right;padding-right:15px">Anda memiliki
                                <span class="txt_mail_cnt">0</span> pesan baru yang belum dibaca dari kami.</div>
                        </div>

                        <div class="mdc-wrapper">
                            <a href="<?php echo $urlweb; ?>/desktop/account/deposit"
                                class="mdc-items active">Deposit</a>
                            <a href="<?php echo $urlweb; ?>/desktop/account/withdrawal" class="mdc-items ">Withdraw</a>
                            <a href="<?php echo $urlweb; ?>/desktop/account/lastDirectTransfer" class="mdc-items ">5
                                Transaksi
                                Terakhir </a>
                            <a href="<?php echo $urlweb; ?>/desktop/account/history" class="mdc-items">Pernyataan</a>

                        </div> 
                    </div>
                    <?php
if (isset($_GET['notif']) && $_GET['notif'] == 1) {
    $msg = $_GET['msg'];
    echo '<div class="alert alert-danger" role="alert">';
    echo $msg;
    echo '</div>';
}
?>

                    <?php
                    error_reporting(0);
                    $useridnya = $u['cuid'];
                    $cekTransaksi = mysqli_query($conn,"SELECT * FROM `tb_transaksi` WHERE userID = '$useridnya' AND jenis = 1 AND status = 0") or die(mysqli_error());
                    $ct = mysqli_num_rows($cekTransaksi);
                    $jumlahdeposit = $row['total'];
                    if($ct > 0){
                    echo '
                    <div class="alert alert-danger alert-dismissible mb-2" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <div class="alert-message text-justify">
                    <span>Anda masih memiliki Permintaan Deposit yang Belum Diproses. Silahkan Tunggu Hingga Proses Penarikan Sebelumnya Selesai.</span>
                    </div>
                    </div>
                    ';
                ?>
                    <?php } else { ?>
                        <div class="content">
                        <div class="deposit">
        <div class="container container-box">
            <div class="row">
                <!-- Konfirmasi Transfer Bank -->
                <div class="col-xs-12 col-md-8 content-form">
                    <div class="methods_form" id="metode">
                        <div class="box-wrapper plr-15">
                            <div class="row align-items-center">
                                <div class="col-md-3 col-xs-12 text-center pay-title">
                                    <div>
                                        Konfirmasi Transfer Bank / E Wallet (Manual Cek)
                                    </div>
                                </div>
                                <div class="col-md-9 col-xs-12 d-flex flex-wrap">
                                <?php
                                $userID = 1; // Ganti dengan nilai userID yang sesuai
                                // Fetch bank data for a specific user from the database (assuming $conn is your database connection)
                                $stmt = mysqli_prepare($conn, "SELECT * FROM `tb_bank` WHERE userID = ?");
                                mysqli_stmt_bind_param($stmt, "i", $userID);
                                mysqli_stmt_execute($stmt);
                                $bankData = mysqli_stmt_get_result($stmt);
                                // Loop through the bank data and generate buttons
                                foreach ($bankData as $bank) {  
                                    // Convert the 'status' value from the database to either 'online' or 'offline'
                                    $status = $bank['status'] == 1 ? 'online' : 'offline';
                                    
                                    echo '<a class="payment-methods payment-methods-items ' . $status . '" href="/desktop/account/metode/?bank=' . base64_encode($bank['cuid']) . '">';
                                    echo '<div class="verti ' . $status . '">';
                                    
                                    // Tambahkan gaya CSS untuk menentukan lebar dan tinggi maksimum
                                    echo '<img class="img-fluid" style="max-width: 70px; max-height: 50px;" src="' . $bank['image'] . '">';
                                    
                                    echo '</div>';
                                    echo '</a>';
                                }                                
                                ?>
                                </div>
                            </div>
                        </div> 
                        <!-- QRIS -->
                        <div class="box-wrapper plr-15">
                            <div class="row align-items-center">
                                <div class="col-md-3 col-xs-12 text-center pay-title">
                                    <div>
                                        QRIS (Manual Cek)
                                    </div>
                                </div>
                                <div class="col-md-9 col-xs-12 d-flex flex-wrap">
                                    <!-- QRIS Button -->
                                    <button id="btn_qris" class="payment-methods payment-methods-items online" onclick="window.location.href='qris.php';">
                                        <div class="verti online">
                                            <img class="img-fluid" src="https://seeklogo.com/images/Q/quick-response-code-indonesia-standard-qris-logo-F300D5EB32-seeklogo.com.png" width="78" height="31">
                                        </div>
                                    </button>

                                    <input type="hidden" id="preload" value="1">
                                </div>
                            </div>
                        </div>
                        <!-- Pulsa -->
                         <div class="box-wrapper plr-15">
                            <div class="row align-items-center">
                                <div class="col-md-3 col-xs-12 text-center pay-title">
                                    <div>
                                        AutoPay (Otomatis Cek)
                                    </div>
                                </div>
                                <div class="col-md-9 col-xs-12 d-flex flex-wrap">
                                    <!-- QRIS Button -->
                                    <button id="btn_qris" class="payment-methods payment-methods-items online" onclick="window.location.href='auto.php';">
                                        <div class="verti online">
                                            <img class="img-fluid" src="https://www.parking.net/Upload/Industry/00-New-HD-Logos/autopay-company-logo-480px_main.jpg" width="78" height="31">
                                        </div>
                                    </button>

                                    <input type="hidden" id="preload" value="1">
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php include "../footer.php";?>