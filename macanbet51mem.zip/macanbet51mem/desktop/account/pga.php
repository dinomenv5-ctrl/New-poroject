<?php
ob_start();
session_start();
date_default_timezone_set("Asia/Jakarta");
require_once('../../config/koneksi.php');

$user = mysqli_query($conn, "SELECT * FROM `tb_user` WHERE username = '" . $_SESSION['user'] . "'") or die(mysqli_error());
$u = mysqli_fetch_array($user);
$user_login = $u['username'];
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit QRIS Otomatis</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 100%;
            max-width: 450px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .form-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-header h1 {
            color: #333;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .form-header p {
            color: #666;
            font-size: 16px;
        }

        .qris-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .input-wrapper {
            position: relative;
        }

        .form-control {
            width: 100%;
            padding: 15px 20px;
            padding-left: 50px;
            border: 2px solid #e1e5e9;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #fff;
            color: #333;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }

        .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 16px;
            z-index: 1;
        }

        .form-control:focus+.input-icon {
            color: #667eea;
        }

        .btn-submit {
            width: 100%;
            padding: 16px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .btn-submit::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .btn-submit:hover::before {
            left: 100%;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .amount-suggestions {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-top: 10px;
        }

        .amount-btn {
            padding: 8px 12px;
            border: 1px solid #ddd;
            background: #f8f9fa;
            border-radius: 8px;
            cursor: pointer;
            text-align: center;
            font-size: 12px;
            transition: all 0.2s ease;
        }

        .amount-btn:hover {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }

        .user-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
                margin: 10px;
            }

            .form-header h1 {
                font-size: 24px;
            }

            .amount-suggestions {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 10px;
            }

            .container {
                padding: 25px 15px;
            }

            .form-control {
                padding: 12px 15px;
                padding-left: 45px;
                font-size: 14px;
            }

            .btn-submit {
                padding: 14px;
                font-size: 14px;
            }

            .amount-suggestions {
                grid-template-columns: 1fr;
            }
        }

        /* Animation */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .container {
            animation: fadeInUp 0.6s ease-out;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-header">
            <div class="qris-icon">
                <i class="fas fa-qrcode"></i>
            </div>
            <h1>Deposit QRIS</h1>
            <p>Proses deposit otomatis & cepat</p>
        </div>

        <!-- User Info -->
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($user_login, 0, 1)); ?>
            </div>
            <div>
                <div style="font-weight: 600; color: #333;">Selamat datang!</div>
                <div style="font-size: 14px; color: #666;"><?php echo htmlspecialchars($user_login); ?></div>
            </div>
        </div>

        <!-- Alert Messages would go here if needed -->

        <!-- Deposit Form -->
        <form method="POST" action="../../function/deposit_qris.php" id="depositForm">
            <div class="form-group">
                <label for="username">Username</label>
                <div class="input-wrapper">
                    <input type="text"
                        id="username"
                        name="username"
                        class="form-control"
                        value="<?php echo htmlspecialchars($user_login); ?>"
                        readonly
                        required>
                    <i class="fas fa-user input-icon"></i>
                </div>
            </div>

            <div class="form-group">
                <label for="amount">Jumlah Deposit (Rp)</label>
                <div class="input-wrapper">
                    <input type="number"
                        id="amount"
                        name="amount"
                        class="form-control"
                        placeholder="Masukkan jumlah deposit"
                        min="10000"
                        step="10000"
                        required>
                    <i class="fas fa-money-bill input-icon"></i>
                </div>

                <!-- Quick Amount Selection -->
                <div class="amount-suggestions">
                    <div class="amount-btn" onclick="setAmount(50000)">Rp 50.000</div>
                    <div class="amount-btn" onclick="setAmount(100000)">Rp 100.000</div>
                    <div class="amount-btn" onclick="setAmount(200000)">Rp 200.000</div>
                    <div class="amount-btn" onclick="setAmount(500000)">Rp 500.000</div>
                    <div class="amount-btn" onclick="setAmount(1000000)">Rp 1.000.000</div>
                    <div class="amount-btn" onclick="setAmount(2000000)">Rp 2.000.000</div>
                </div>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fas fa-credit-card" style="margin-right: 8px;"></i>
                Proses Deposit
            </button>
        </form>
    </div>

    <script>
        // Set amount from quick selection
        function setAmount(amount) {
            document.getElementById('amount').value = amount;
        }

        // Format number input
        document.getElementById('amount').addEventListener('input', function(e) {
            let value = e.target.value;
            if (value < 0) {
                e.target.value = 0;
            }
        });

        // Form validation
        document.getElementById('depositForm').addEventListener('submit', function(e) {
            const amount = document.getElementById('amount').value;

            if (!amount || amount < 1000) {
                e.preventDefault();
                alert('Minimum deposit adalah Rp 10.000');
                return false;
            }

            if (amount > 10000000) {
                e.preventDefault();
                alert('Maximum deposit adalah Rp 10.000.000');
                return false;
            }

            // Confirm before submit
            if (!confirm(`Konfirmasi deposit sebesar Rp ${parseInt(amount).toLocaleString('id-ID')}?`)) {
                e.preventDefault();
                return false;
            }
        });

        // Add loading state on form submit
        document.getElementById('depositForm').addEventListener('submit', function() {
            const submitBtn = document.querySelector('.btn-submit');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
            submitBtn.disabled = true;
        });
    </script>
</body>

</html>