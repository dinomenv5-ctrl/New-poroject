<?php
require_once 'config/class.hgi.php';

$hgi = new HypergateAPI();
$response = null;
$action = $_POST['action'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action) {
    try {
        switch ($action) {
            case 'provider_list':
                $response = $hgi->provider_list();
                break;
            case 'game_list':
                $response = $hgi->game_list(
                    $_POST['provider_code'] ?: null, 
                    $_POST['game_type'] ?: null, 
                    (int)$_POST['page'], 
                    (int)$_POST['limit']
                );
                break;
            case 'launch_game':
                $response = $hgi->launch_game(
                    $_POST['provider_code'], 
                    $_POST['username'], 
                    $_POST['game_id'], 
                    $_POST['lang'] ?: 'en-US', 
                    isset($_POST['demo'])
                );
                break;
            case 'get_balance':
                $response = $hgi->get_balance($_POST['username'] ?: null);
                break;
            case 'create_user':
                $response = $hgi->create_user($_POST['username']);
                break;
            case 'deposit':
                $response = $hgi->deposit($_POST['username'], $_POST['amount']);
                break;
            case 'withdraw':
                $response = $hgi->withdraw($_POST['username'], $_POST['amount']);
                break;
        }
    } catch (Exception $e) {
        $response = ['status' => 0, 'msg' => $e->getMessage()];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hypergate API Tester</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --hgi-primary: #007bff; --hgi-dark: #121212; --hgi-card: #1e1e1e; }
        body { background-color: var(--hgi-dark); color: #e0e0e0; font-family: 'Inter', sans-serif; }
        .navbar { background-color: #000; border-bottom: 2px solid var(--hgi-primary); }
        .card { background-color: var(--hgi-card); border: none; border-radius: 12px; color: #fff; margin-bottom: 20px; }
        .form-control, .form-select { background-color: #2d2d2d; border: 1px solid #444; color: #fff; }
        .form-control::placeholder { color: #888; }
        .form-control:focus { background-color: #333; color: #fff; border-color: var(--hgi-primary); box-shadow: none; }
        .btn-primary { background-color: var(--hgi-primary); border: none; }
        pre { background-color: #000; padding: 15px; border-radius: 8px; color: #a6e22e; border: 1px solid #333; font-size: 0.85rem; overflow-x: auto; }
        .nav-tabs .nav-link { color: #aaa; border: none; }
        .nav-tabs .nav-link.active { background: none; color: var(--hgi-primary); border-bottom: 3px solid var(--hgi-primary); }
    </style>
</head>
<body>

<nav class="navbar navbar-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fa-solid fa-bolt"></i> HYPERGATE <strong>TESTER</strong></a>
        <span class="navbar-text text-uppercase small fw-bold">API Version 1.0</span>
    </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-lg-7">
            <ul class="nav nav-tabs mb-4" id="apiTabs" role="tablist">
                <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-user">User & Balance</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-game">Game & Provider</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-transaksi">Transaction</button></li>
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade show active" id="tab-user">
                    <div class="card p-4">
                        <h5 class="mb-3 text-primary"><i class="fa-solid fa-user-plus"></i> Create User / Check Balance</h5>
                        <form method="POST" class="row g-2">
                            <div class="col-md-8"><input type="text" name="username" class="form-control" placeholder="Username (3-12 alphanumeric)"></div>
                            <div class="col-md-4 d-grid gap-2">
                                <button type="submit" name="action" value="create_user" class="btn btn-primary btn-sm">Create User</button>
                                <button type="submit" name="action" value="get_balance" class="btn btn-outline-light btn-sm">Check Balance</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="tab-pane fade" id="tab-game">
                    <div class="card p-4 mb-3">
                        <h5 class="mb-3 text-info"><i class="fa-solid fa-gamepad"></i> Launch Game</h5>
                        <form method="POST">
                            <input type="hidden" name="action" value="launch_game">
                            <div class="row g-2">
                                <div class="col-md-6"><input type="text" name="provider_code" class="form-control mb-2" placeholder="Provider Code (e.g PG)" required></div>
                                <div class="col-md-6"><input type="text" name="username" class="form-control mb-2" placeholder="Username" required></div>
                                <div class="col-md-6"><input type="text" name="game_id" class="form-control mb-2" placeholder="Game ID (0 for lobby)" value="0"></div>
                                <div class="col-md-6">
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" name="demo" id="demoMode">
                                        <label class="form-check-label" for="demoMode">Demo Mode</label>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-info w-100 text-white">Launch Game</button>
                            </div>
                        </form>
                    </div>
                    <div class="d-flex gap-2">
                        <form method="POST" class="flex-grow-1">
                            <input type="hidden" name="action" value="provider_list">
                            <button type="submit" class="btn btn-secondary w-100">Get Provider List</button>
                        </form>
                        <form method="POST" class="flex-grow-1">
                            <input type="hidden" name="action" value="game_list">
                            <input type="hidden" name="page" value="1">
                            <input type="hidden" name="limit" value="10">
                            <button type="submit" class="btn btn-secondary w-100">Get Game List (Top 10)</button>
                        </form>
                    </div>
                </div>

                <div class="tab-pane fade" id="tab-transaksi">
                    <div class="card p-4">
                        <h5 class="mb-3"><i class="fa-solid fa-money-bill-transfer"></i> Wallet Adjustment</h5>
                        <form method="POST">
                            <div class="row g-2">
                                <div class="col-md-6"><input type="text" name="username" class="form-control mb-2" placeholder="Username" required></div>
                                <div class="col-md-6"><input type="number" name="amount" class="form-control mb-2" placeholder="Amount" required></div>
                                <div class="col-md-6">
                                    <button type="submit" name="action" value="deposit" class="btn btn-success w-100">Deposit</button>
                                </div>
                                <div class="col-md-6">
                                    <button type="submit" name="action" value="withdraw" class="btn btn-danger w-100">Withdraw</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-5 mt-4 mt-lg-0">
            <h5 class="mb-3"><i class="fa-solid fa-terminal"></i> Response Output</h5>
            <div class="card p-3 shadow-lg" style="min-height: 400px; border: 1px solid #333;">
                <?php if ($response): ?>
                    <pre><?php echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES); ?></pre>
                    
                    <?php if (isset($response['game_url'])): ?>
                        <div class="text-center mt-3">
                            <a href="<?php echo $response['game_url']; ?>" target="_blank" class="btn btn-primary">Open Game Session <i class="fa-solid fa-external-link"></i></a>
                        </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="text-center text-secondary py-5">
                        <i class="fa-solid fa-code fa-3x mb-3"></i>
                        <p>No request sent yet.<br>Select a method and fill the form.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>