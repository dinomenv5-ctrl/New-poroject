# LAPORAN PERBAIKAN — QRIS AUTO-CREDIT (FIXED v4)
Tanggal: 9 September 2025
Masalah yang dilaporkan: "Saya sudah bayar tagihan QRIS payment gateway sudah selesai, tapi saldo tidak masuk ke saya. Tolong dibuat otomatis langsung masuk setelah pembayaran QRIS selesai."

---

## 1. RINGKASAN MASALAH

Setelah member menyelesaikan pembayaran QRIS via AutoGopay (scan QR, dana terpotong, status di dashboard AutoGopay menjadi LUNAS), saldo/coin di website TIDAK masuk secara otomatis. Member harus menunggu admin memproses manual, atau lebih buruk: transaksi menggantung berstatus pending selamanya dan saldo tidak pernah masuk.

Hasil investigasi menemukan 5 akar masalah (root cause) yang saling memperparah. Semuanya sudah diperbaiki pada versi ini (v4), dan alur auto-credit kini berjalan lewat 3 lapis pengaman (webhook + polling + cron) sehingga saldo masuk otomatis maksimal dalam hitungan detik setelah pembayaran selesai — tanpa campur tangan admin.

---

## 2. AKAR MASALAH (ROOT CAUSE)

### Bug #1 — getBal.php / getbalance.php MENIMPA saldo lokal dengan nilai lama dari server game
Halaman member memanggil `getBal.php` setiap beberapa detik. Kode lama selalu menimpa (overwrite) kolom `tb_balance.active` dengan hasil `userbalance()` dari server game NexusGGR. Ketika member baru membayar QRIS (saldo lokal naik menjadi 100.000) tetapi server game belum/belum berhasil menerima deposit, pemanggilan getBal berikutnya MENIMPA saldo lokal kembali ke nilai lama (misal 0). Efeknya: saldo yang barusan masuk "hilang" seperti tidak pernah dikredit. Ini penyebab utama komplain "sudah bayar tapi saldo tidak masuk" padahal transaksi sebenarnya sudah diproses.

### Bug #2 — Deposit ke server game TANPA dedup & TANPA retry
Proses kredit terdiri dari 2 langkah: (a) naikkan saldo lokal di DB, (b) kirim deposit ke NexusGGR supaya saldo masuk ke akun game member. Kode lama tidak punya proteksi jika langkah (b) gagal (server game down/timeout): transaksi tetap ditandai sukses, saldo lokal masuk, tetapi saldo di server game TIDAK masuk — lalu Bug #1 menimpanya kembali karena getBal selalu memakai nilai server game. Tidak ada penandaan kegagalan, tidak ada retry, dan tidak ada dedup sehingga retry manual berisiko deposit ganda (double credit).

### Bug #3 — Polling status QRIS hanya mengenali status 'success' persis
`function/check_qris_status.php` (dipolling tiap 1 detik dari halaman qris_payment) hanya menganggap lunas jika AutoGopay mengirim string `'success'` persis. AutoGopay pada praktiknya dapat mengirim varian lain seperti `'paid'`, `'PAID'`, `'settlement'`, `'complete'`, atau `'capture'` tergantung channel QRIS/akun. Varian tersebut diabaikan → polling tidak pernah memicu kredit → member menatap halaman pembayaran yang "tidak beres" padahal sisi AutoGopay sudah lunas. Selain itu, error PHP Exception/Throwable pada polling ditelan diam-diam tanpa log, sehingga kegagalan tidak pernah terlihat saat audit.

### Bug #4 — Webhook callback_autogopay.php terlalu ketat & tidak toleran varian
Webhook AutoGopay (lapis tercepat) mengalami masalah serupa: hanya status `'success'` yang diproses, varian lain diabaikan atau salah diklasifikasi. Validasi nominal juga kaku: nominal yang dikirim AutoGopay harus SAMA PERSIS dengan total transaksi; jika AutoGopay mengirim nominal dengan pembulatan/format berbeda (misal 25.001 vs 25.000 karena fee/rounding), webhook menolak atau salah perilaku → saldo tidak masuk meski pembayaran sah.

### Bug #5 — Halaman QRIS hanya hidup di session; refresh/reload = transaksi "hilang"
Halaman `m/account/qris_payment.php` menyimpan data pembayaran (nomor order, QR, nominal) hanya di `$_SESSION['qris_payment']`. Jika member refresh halaman, pindah tab lalu balik, atau session habis — QR dan tombol status hilang, member tidak bisa melanjutkan/mengecek pembayaran yang sebenarnya masih pending. Tidak ada tombol "Lanjutkan Pembayaran" di halaman deposit untuk transaksi QRIS yang masih pending. (Catatan: `kd_transaksi` varchar(16) juga memotong referensi order 17 karakter — memperumit pencocokan.)

### Bug #6 (admin) — Approve manual admin memakai agent_sign NON-DETERMINISTIK
Tool admin `tools/approve_qris.php` lama membuat `agent_sign` dengan pola `DEPO_<random/time>` yang berbeda tiap eksekusi. Jika retry diperlukan, sign berubah → server game menganggap transfer BARU → risiko double deposit. Approve manual admin juga tidak memakai helper yang sama dengan webhook/polling sehingga perilaku bisa menyimpang (misal: melewatkan bonus/turnover/notifikasi yang seharusnya konsisten).

---

## 3. ARSITEKTUR SOLUSI — AUTO-CREDIT 3 LAPIS

Saldo kini dikredit otomatis lewat 3 lapis yang saling menjaga (defense in depth). Semua lapis memakai SATU helper yang sama (`function/autocredit_helper.php`) sehingga logika kredit 100% konsisten dan idempoten (aman dipanggil berulang — tidak akan pernah double credit):

LAPIS 1 — WEBHOOK ( tercepat, 0-5 detik)
`callback_autogopay.php` di server menerima notifikasi pembayaran dari AutoGopay. Verifikasi signature HMAC-SHA256 dengan webhook secret dari pengaturan (tb_seo). Jika valid & status lunas → langsung kredit.

LAPIS 2 — POLLING (detik ke detik, dari browser member)
`function/check_qris_status.php` dipanggil tiap 1 detik oleh halaman qris_payment selama member masih membuka halaman. Mengecek status via API `getStatus` AutoGopay; jika lunas → kredit (idempoten, aman tumpang tindih dengan webhook).

LAPIS 3 — CRON (penjaga terakhir, jalan terus)
`cron_autocredit_qris.php` berjalan sebagai daemon (tiap 1 detik) atau via crontab (misal tiap menit). Memproses semua deposit QRIS pending yang belum dikredit walau member sudah menutup browser, mengecek ulang ke AutoGopay, mengkredit yang lunas, menandai gagal yang kedaluwarsa, DAN me-retry otomatis transfer ke server game yang sempat gagal (dengan dedup transferStatus agar tidak ganda).

LAPIS ADMIN — fallback manual
`tools/approve_qris.php` kini mendelegasikan penuh ke helper yang sama; approve manual jadi 100% konsisten dengan otomatis (agent_sign deterministik `DEPO_<kd_transaksi>`, bonus/turnover/notifikasi sama).

Semua lapis terhubung ke satu rutin inti `qris_autocredit_process()` yang:
1. Kunci transaksi secara atomik (`UPDATE ... SET status=1 WHERE cuid=X AND jenis=1 AND (status=0 OR status IS NULL)` + cek affected_rows) — hanya SATU lapis yang boleh memproses satu transaksi.
2. Kredit saldo lokal (tb_balance.active) + catat bonus & turnover bila ada.
3. Transfer ke server game NexusGGR dengan dedup: sebelum kirim, cek `transferStatus(username, 'DEPO_<kd>')`; jika server game bilang sudah pernah → lewati (mengembalikan ALREADY_TRANSFERRED, tidak ganda).
4. Jika transfer game gagal → transaksi tetap sukses (saldo lokal tetap masuk, member tidak dirugikan), tetapi note ditandai `[GAME-API-FAIL: pesan]` untuk di-retry otomatis oleh cron/getBal.
5. Kirim notifikasi Telegram (bila dikonfigurasi) + tulis log.

---

## 4. DAFTAR PERBAIKAN (FIX A-G)

### FIX A — getBal.php & getbalance.php (anti penimpaan saldo)
File: `getBal.php`, `getbalance.php`
Sekarang LOCAL-FIRST: saldo DB lokal adalah sumber utama yang ditampilkan. Nilai server game hanya dipakai untuk sinkronisasi ketika memang aman (tidak ada deposit pending/berhasil yang belum tersinkron). Bila terdeteksi ada deposit sukses yang belum masuk ke server game `[GAME-API-FAIL]`, getBal memicu retry deposit otomatis (dengan dedup) — jadi sekali member buka halaman, saldo game ikut menyusul tanpa admin turun tangan. Tidak ada lagi skenario saldo lokal "dihilangkan" oleh nilai lama server game.

### FIX B — function/autocredit_helper.php (dedup + retry engine)
File: `function/autocredit_helper.php` (sudah ada dari v3, kali ini diperkuat)
Ditambahkan dedup `transferStatus` di awal `qris_autocredit_game_deposit()`: jika server game sudah mencatat transfer dengan agent_sign yang sama, deposit tidak dikirim ulang (mengembalikan ALREADY_TRANSFERRED). Ditambahkan fungsi baru `qris_autocredit_retry_game_deposits()` yang mencari semua transaksi sukses bertanda `[GAME-API-FAIL]` lalu me-retry transfer ke server game; sukses → note diganti `[GAME-API-RECOVERED: <waktu>]`. Fungsi ini dipakai oleh cron (lapis 3) dan getBal (FIX A).

### FIX C — function/check_qris_status.php (polling, normalisasi status)
File: `function/check_qris_status.php`
Status dari AutoGopay dinormalisasi dulu: `paid/settle/settlement/seteled/complete/completed/finish/finished/done/clear/cleared/capture/captured/success` (case-insensitive) → dianggap LUNAS; `failed/fail/expired/expire/timeout/cancel/canceled/cancelled/void/reversed` → GAGAL. Error Exception maupun Throwable kini ditangkap dan dicatat ke `api_polling.log` sehingga kegagalan polling tidak pernah lagi "diam-diam".

### FIX D — callback_autogopay.php (webhook, normalisasi + toleransi nominal)
File: `callback_autogopay.php`
Normalisasi varian status yang sama dengan FIX C diterapkan di webhook (lapis tercepat). Validasi nominal kini adil: bayar KURANG dari total transaksi → DITOLAK (409, transaksi tetap pending, tidak dikredit — mencegah kredit sebagian); bayar LEBIH (misal kena pembulatan QRIS) → DITERIMA dan dikredit sebesar TOTAL transaksi (kelebihan dicatat di log, tidak dikredit ganda). Signature HMAC-SHA256 tetap diverifikasi ketat (401 jika salah).

### FIX E — cron_autocredit_qris.php (penjaga terakhir + auto-retry)
File: `cron_autocredit_qris.php`
Parser status diperluas dengan varian yang sama (FIX C/D). Cron kini juga memanggil `qris_autocredit_retry_game_deposits()` untuk menyembuhkan transfer game yang pernah gagal: di mode daemon dijalankan throttled (tiap ~60 iterasi / ±1 menit) agar hemat, di mode crontab dijalankan tiap eksekusi. Jadi walau server game sempat down saat member membayar, saldo game member tetap menyusul otomatis.

### FIX F — m/account/qris_payment.php + m/account/deposit.php (halaman tahan reload)
File: `m/account/qris_payment.php`, `m/account/deposit.php`
Halaman pembayaran QRIS sekarang menerima parameter `?kd=<kd_transaksi>`: bila session hilang/refresh, halaman mencari transaksi milik member tersebut di DB, dan bila masih pending, MEMBANGUN ULANG data QR lengkap (nominal, QR image, payment_url, batas waktu) dengan memanggil `getStatus` AutoGopay pakai nomor order yang tersimpan di note transaksi (`ORDER: ...`) — tidak lagi bergantung session. Jika status ternyata sudah lunas/gagal saat reload, member langsung diarahkan ke halaman deposit dengan notifikasi yang sesuai. Di halaman deposit, setiap transaksi QRIS pending kini menampilkan tombol "Lanjutkan Pembayaran QRIS" yang membuka halaman pembayaran dengan `?kd=` tersebut — member tidak pernah kehilangan akses ke pembayarannya. Anti-truncation: pencocokan reference 17 karakter tetap ketemu lewat lookup prefix `ORDER:` di note.

### FIX G — tools/approve_qris.php + deposit_qris.php (admin panel konsisten)
File (admin panel): `tools/approve_qris.php`, `deposit_qris.php`, `function/autocredit_helper.php` (helper disalin ke admin supaya admin panel standalone)
Approve manual kini MENDelegasikan penuh ke `qris_autocredit_process()` — helper yang sama persis dengan webhook/polling/cron. Akibatnya: agent_sign deterministik `DEPO_<kd_transaksi>` (stabil, aman retry, tidak mungkin double), bonus/turnover/telegram/log semua konsisten dengan jalur otomatis. Halaman deposit_qris menampilkan SweetAlert yang jelas untuk hasil approve: notif=1 sukses dikredit, notif=2 transaksi sudah pernah diproses (tidak diproses ulang), notif=3 gagal proses (transaksi sengaja dibiarkan pending agar cron otomatis me-retry; petunjuk log ditampilkan).

---

## 5. HASIL PENGUJIAN

Diuji dengan MariaDB lokal + mock server game NexusGGR (kelas fiver) — TIDAK ada panggilan ke server game/telegram asli:

Unit test (test/run_tests.php): 37/37 PASS — mencakup: idempotensi webhook (webhook datang 2x tidak double credit), normalisasi semua varian status, dedup transferStatus (ALREADY_TRANSFERRED), retry GAME-API-FAIL + pemulihan (RECOVERED), cron retry helper, reject underpay, webhook failed → status=2, approve admin mendelegasikan helper, anti-truncation 17 karakter.

End-to-end test (test/e2e_webhook_test.php): 20/20 PASS — menjalankan file `callback_autogopay.php` ASLI via HTTP server dengan signature HMAC-SHA256 asli dan mock game API, memverifikasi saldo benar-benar masuk di DB: skenario sukses → 200 + saldo +100.000 + deposit game 1x; retry webhook yang sama → saldo TETAP 100.000 (idempoten); varian 'paid' → dikredit; bayar kurang → 409 ditolak; bayar lebih → 200 dikredit sesuai total; signature salah → 401; status failed → transaksi berstatus 2; reference ter-truncate 17 karakter → tetap ketemu via ORDER lookup.

Syntax check: seluruh 11 file PHP yang dimodifikasi lolos `php -l` tanpa error.

---

## 6. FILE YANG DIMODIFIKASI (member)

config/koneksi.php (daemon-safe reconnect flag)
callback_autogopay.php (FIX D)
cron_autocredit_qris.php (FIX E)
getBal.php, getbalance.php (FIX A)
function/autocredit_helper.php (FIX B + inti semua lapis)
function/check_qris_status.php (FIX C)
m/account/qris_payment.php (FIX F)
m/account/deposit.php (FIX F tombol lanjutkan)

## FILE YANG DIMODIFIKASI (admin panel)

tools/approve_qris.php (FIX G)
deposit_qris.php (FIX G notifikasi)
function/autocredit_helper.php (baru — disalin agar admin standalone)

---

## 7. PANDUAN DEPLOYMENT

1. Upload file-file di atas ke server sesuai path-nya (backup dulu file lama).
2. Tidak ada perubahan skema database — kolom/kunci yang dipakai sudah ada di DB produksi (tb_transaksi.kd_transaksi, tb_transaksi.note, tb_seo.autogopay_*, tb_balance.active). TIDAK PERLU migrasi SQL.
3. Pastikan di pengaturan admin (tb_seo / halaman setting): `autogopay_apikey` terisi (iak_...), `autogopay_wh_secret` terisi sesuai dashboard AutoGopay, `urlweb` sesuai domain member.
4. Di dashboard AutoGopay, arahkan Webhook URL ke: `https://<domain-member>/callback_autogopay.php` (lapis tercepat).
5. Aktifkan lapis 3 cron — pilih salah satu:
   Mode daemon (disarankan, interval 1 detik):
   ```
   nohup php /path/ke/member/cron_autocredit_qris.php --daemon >/dev/null 2>&1 &
   ```
   Mode crontab (interval 1 menit):
   ```
   * * * * * php /path/ke/member/cron_autocredit_qris.php >/dev/null 2>&1
   ```
6. Verifikasi: buat deposit QRIS kecil di staging, scan & bayar, pastikan saldo masuk otomatis < 1 menit tanpa sentuhan admin.

## 8. LOG UNTUK AUDIT / TROUBLESHOOTING

logs/autogopay_callback_YYYY-MM-DD.log — masuknya webhook, hasil verifikasi signature/status/nominal, hasil kredit
logs/cron_autocredit_YYYY-MM-DD.log — aktivitas cron/daemon, retry transfer game, pemulihan
api_polling.log — error polling status (jika ada)
logs/admin_approve_qris_YYYY-MM-DD.log (di admin panel) — jejak approve manual admin
mock/test tidak ada di paket produksi.

## 9. CATATAN PENTING

Idempotensi total: webhook, polling, cron, dan approve admin boleh dipanggil SERENTAK untuk transaksi yang sama — hanya satu yang menang kunci DB, sisanya mendeteksi "sudah diproses" dan diam (tidak pernah double credit).
Dedup server game: sebelum tiap kirim deposit ke NexusGGR dicek dulu transferStatus dengan agent_sign deterministik DEPO_<kd_transaksi> — server game tidak akan pernah menerima transfer ganda untuk transaksi yang sama.
Member tidak pernah dirugikan: jika server game down saat pembayaran, saldo lokal tetap masuk, transaksi tetap sukses, transfer game di-retry otomatis sampai berhasil.
Underpay ditolak (409) dan transaksi tetap pending — sebutkan ke member agar menghubungi CS untuk penyelesaian manual jika memang bayar kurang.
