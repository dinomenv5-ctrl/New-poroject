<?php
// URL API
$url = "https://api.nexusggr.com";

// Data yang akan dikirim melalui POST
$postData = [
    "method" => "game_list",
    "agent_code" => "paygame",
    "agent_token" => "23fbdc1d04848892cdc2279ebc47546b",
    "provider_code" => "REELKINGDOM"
];

// Inisialisasi cURL
$ch = curl_init($url);

// Set opsi cURL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

// Eksekusi permintaan
$response = curl_exec($ch);

// Cek apakah ada kesalahan saat eksekusi
if (curl_errno($ch)) {
    echo 'Error: ' . curl_error($ch);
} else {
    // Decode respons JSON
    $responseData = json_decode($response, true);
    
    // Cek apakah status API berhasil
    if ($responseData['status'] == 1) {
        // Koneksi ke database
        include 'config/koneksi.php'; // Pastikan Anda sudah memiliki koneksi database

        // Looping data game yang diterima
        foreach ($responseData['games'] as $game) {
            $game_code = $game['game_code'];
            $game_name = $game['game_name'];
            $banner = $game['banner'];
            $status = $game['status'];

            // Masukkan data ke dalam tabel tb_gamelist
            $query = "INSERT INTO tb_gamelist (game_code, game_name, banner, status) 
                      VALUES (?, ?, ?, ?) 
                      ON DUPLICATE KEY UPDATE 
                      game_name = VALUES(game_name), 
                      banner = VALUES(banner), 
                      status = VALUES(status)";

            // Siapkan statement
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssi", $game_code, $game_name, $banner, $status);
            $stmt->execute();
        }

        echo "Data berhasil dimasukkan ke tb_gamelist.";
    } else {
        echo "Error: " . $responseData['msg'];
    }
}

// Tutup sesi cURL
curl_close($ch);
